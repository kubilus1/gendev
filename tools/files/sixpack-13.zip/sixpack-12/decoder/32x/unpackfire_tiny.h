#ifndef _UNPACKFIRE_TINY_
#define _UNPACKFIRE_TINY_

extern void unpackfire_tiny(char *, volatile unsigned short *);

#endif
