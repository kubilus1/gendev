#ifndef _LZSS_DECODE_
#define _LZSS_DECODE_

extern void lzss_decode(char *, int, volatile unsigned short *);

#endif
