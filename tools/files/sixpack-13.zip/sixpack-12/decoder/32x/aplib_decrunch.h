#ifndef _APLIB_DECRUNCH_
#define _APLIB_DECRUNCH_

extern void aplib_decrunch(char *, volatile unsigned short *);

#endif

