/*	Copyright  (c)	Günter Woigk 1994 - 2007
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.
*/

#ifndef AssZ80_h
#define AssZ80_h

#include "Ass.h"


class AssZ80 : public Ass
{
	bool		head;			// sna/z80:	true while #head

// object code storing
	void 		store_XYCB_op	( int pfx, int n, int dis );
	void		store_XY_byte_op( int pfx, int n, int dis );

// AssDirect()
virtual bool	AssDirect		( cstr dir );		// z80 specific #directives

	void		HandleHeadSna	( );
	void		HandleHeadZ80	( );

	void		HandleCodeSna	( );
	void		HandleCodeZ80	( );
	void		HandleCodeTap	( );
	void		HandleCodeZX80	( );
	void		HandleCodeZX81	( );

	void		WriteTapeBlock	( );
	void		HandlePageZ80	( );

	void		HandleEndTap	( );
	void		HandleEndZ80	( );
	void		HandleEndSna	( );
	void		HandleEndZX80	( );
	void		HandleEndZX81	( );


// compiling
	int			Condition 		( cstr w );
	int			Register 		( cstr w );
virtual bool	AssInstr		( cstr opc );		// z80 specific opcodes

public:
//virtual void	Reset			( );			// no own data members -> no need to reimplement Reset()
//virtual void	Pass2			( );			// no own data members -> no need to reimplement Pass2()
};


#endif
