//	utf-8

/*	Copyright  (c)	Günter Woigk  1994-2004
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission. The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.


	Load / Save snapshots
	---------------------

	01.aug.94	kio		started work on Mac Spectacle version
	01.jan.99	kio		port of .sna and .z80 loader to X Windows
	02.may.99	kio		port of .sna and .z80 saver
	29.jan.2000	kio		started back port to MacOS
	31.jan.2002	kio		adopted for zasm
*/


#include	"kio/kio.h"


struct snahead
{ 
	uint8
		i,
		l2,h2,e2,d2,c2,b2,f2,a2,
		l,h,e,d,c,b,
		yl,yh,xl,xh,
		iff,r,f,a,spl,sph,im,
		brdr; 
};


struct z80head
{
	// ----- Z80 Version 1.45 Header

	uint8
		a,f,c,b,l,h,pcl,pch,spl,sph,
		i,r,data,e,d,c2,b2,e2,d2,l2,h2,a2,f2,
		yl,yh,xl,xh,iff1,iff2,im,

	// ----- Z80 version 2.01 enhanced header (if PC=0)

		h2lenl,h2lenh,	// size of header extension: 23 for version 2.01 files
		npcl,npch,		// PC (instead of pcl+pch, which is set to 0)
		model,			// 	Value:	Meaning in v2.01	Meaning in v3.0
						//	0		48k					48k
						//	1		48k + If.1			48k + If.1
						//	2		SamRam				48k + M.G.T.
						//	3		128k				SamRam
						//	4		128k + If.1			128k
						//	5		-					128k + If.1
						//	6		-					128k + M.G.T.
		port_7ffd,		// If in SamRam mode, bitwise state of 74ls259.
						// For example, bit 6=1 after an OUT 31,13 (=2*6+1)
						// If in 128 mode, contains last OUT to 7ffd (paging control)
		if1paged,		// !=0 means: interface1 rom is paged in
		rldiremu,		// Bit 0: 1 if R register emulation on
						// Bit 1: 1 if LDIR emulation on
		port_fffd,		// Last OUT to fffd (soundchip register number)
		soundreg[16],	// Contents of the sound chip registers

	// ----- Z80 version 3.0 enhanced header (if PC=0 & h2len=54)

		t_l,t_m,t_h,			// T state counter
		spectator,				// Flag byte used by Spectator (QL spec. emulator)
								// Ignored by Z80 when loading, zero when saving
		MGT_ROM,				// 0xFF if MGT Rom paged
		Multiface_ROM,			// 0fFF if Multiface Rom paged. Should always be 0.
		RAM0,RAM1,				// 0xFF if 0-8191 / 8192-16383 is RAM
		joy[10],				// 5* ascii word: keys for user defined joystick
		stick[10],				// 5* keyboard mappings corresponding to keys above
       	MGT_type,				// MGT type: 0=Disciple+Epson,1=Disciple+HP,16=Plus D
		disciple_inhibit_button_status,	// 0=out, 0ff=in
		disciple_inhibit_flag,	// Disciple inhibit flag: 0=rom pageable, 0ff=not
		
	// ----	xzx extension
	
		port_1ffd;				// last out to $1ffd
};


// length of headers:
	#define z80v1len 30
	#define z80v2len 55
	#define z80v3len 86





