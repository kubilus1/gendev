/*	Copyright  (c)	Günter Woigk 1994 - 2009
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.

	2002-01-20 kio	port to unix started
	2005-03-23 kio	#code: also set physical address base for intel hex files
	2010-09-08 kio	HexDump(): folding repetitions of 8++ identical bytes
	
*/

#define	LOG 	0
#define	SAFE	3

#include	"config.h"

#if HAVE_UNISTD_H
#include	<unistd.h>
#endif

#if HAVE_TIME_H
#include	<time.h>
#endif

#include	"unix/FILE.h"
#include	"Ass.h"
#include	"unix/file_utilities.h"
INIT_MSG




/* ---- struct to store labels ------------------------------
*/
struct	Lbl
{
	#define	MAXLBLLEN	40		//	max. length for label names
	long	value;
	char	name[MAXLBLLEN];
};



/* ==================================================================
			ERRORS
================================================================== */

void Ass::SetError ( cstr text, bool isfatal )
{
	errors |= isfatal*0x1000;
	errors++;
	error = error ? CatStr(error,"\n",text) : text;
	::ClearError();
}

void Ass::SetError ( OSStatus error,  bool isfatal )
{
	if(error) SetError(::ErrorStr(error),isfatal);
}

void Ass::CheckErrno ( )
{
	if(errno) SetError(errno);
}



/* ==================================================================
			UTILITIES
================================================================== */


static void StripQuotes ( cstr& s )
{
	if(s&&*s)
		if(s[0]=='"'||s[0]=='\'')
			if(s[0]==LastChar(s))
				s = MidStr(s,1,strlen(s)-2);
}


static void GetDateTime( char* bu26 )
{	time_t t;
	char* s;

	time(&t);
	s=ctime(&t);

	XXXTRAP(strlen(s)!=25);			// format: "Sun Jan 27 18:31:16 2002\n"
	strncpy(bu26,s,26);
}

cstr Ass::GetDate()
{									// format: "27.Jan.2002"
	return CatStr(MidStr(datetime,8,2),".",MidStr(datetime,4,3),".",MidStr(datetime,20,4));
}

cstr Ass::GetTime()
{									// format: "23:55:30"
	return MidStr(datetime,11,8);
}


/* ----	write hexdump to file ------------------------------
		intended for inclusion of object code in list file
		prints address and up to 4 bytes per line
		last line is not terminated with "\n"  =>  possible to append source line
		dumps code from destPtr0 to destPtr
		pointers are not moved
		address is calculated from org and (destPtr0-destBu)

		printed width is 16 characters (2 norm tabs)
*/
void Ass::HexDump ( FILE* f )
{
	int   a = org + (destPtr0-destBu);
	char* p = destPtr0;
	int   n = destPtr-destPtr0;

	while(n>4)
	{
		fprintf( f, "%04X: %08X\n", a,(uint)Peek4X(p) );			// 4 bytes
		
		int m; for(m=1;m<n&&p[m]==*p;m++){}
		if(m>8)
		{
			fprintf( f, "      ...\n" );
			p+=m; a+=m; n-=m;
		}
		else
		{
			p+=4; a+=4; n-=4;
		}
	}

	fprintf( f, "%04X: ", a );								// address
	for( int i=0;i<n;i++ ) fprintf( f, "%02hhX", p[i] );	// 1..4 bytes
	fprintf( f, "%s","          "+(n*2) );

	CheckErrno();
}


/* ----	write intel hexdump to file ------------------------------
		intended for writing of object code to target file
		prints address, len, up to 16 data bytes and checksum per line
		address is calculated from addr == "binary file pointer"
*/
OSStatus IntelHexDump ( FILE* f, ulong& addr, ptr bu, ulong sz )
{	int z;

// ----	test if we exceed a 16 bit boundary:

	while ( (ushort)addr + sz > 0x10000ul )
	{
		ushort n = /*0x10000ul*/-addr;		// bytes left in current 16-bit address block

		OSStatus e = IntelHexDump( f, addr, bu, n );
		if (e) return e;

	//	addr += n;		--> passed by ident => already updated
		bu   += n;
		sz   -= n;

		// write extended address record
		uchar sum = 0x02 + 0 + 0 + 0x04 + (addr>>24) + (addr>>16);
		z = fprintf( f, ":02000004%04X%02X\r\n", (uint)(addr>>16), (uint)(uchar)(-sum) );
		if(z!=17) goto e;
	}

// ----	store data:

	while ( sz )
	{
		uint n = Min(sz,32ul);										// bytes dumped in this line

		z = fprintf( f, ":%02X%04X00", n, (uint)(ushort)(addr) );	// ":", len, address, type
		if (z!=9) goto e;
		uchar sum = n + addr + (addr>>8) + 0;						// check sum

		addr += n;
		bu   += n;
		sz   -= n;

		for ( ; n; n-- )
		{
			z = fprintf ( f, "%02X", (uint)(uchar)bu[-n] );
			if (z!=2) goto e;
			sum += bu[-n];
		}

		z = fprintf ( f, "%02X\r\n", (uint)(uchar)(-sum) );
		if (z!=4) goto e;
	}

	return ok;		// ok

e:	return ferror(f);
}


void Ass::DeleteDestBu ( )		// kio 2002-09-17
{
	delete[] destBu;
	org += destPtr-destBu;		// => list code position in #end
	destBu=destPtr0=destPtr=destEnd=NULL;
}


void Ass::NewDestBu ( size_t n, int fillbyte )		// kio 2002-09-17
{
	delete[] destBu;
	destBu=destPtr=destPtr0=destEnd = new char[n];
	if (!destBu) { SetError("out of memory",fatal); return; }
	destEnd += n;
	memset(destBu,fillbyte,n);
}


void Ass::WriteSegment ( )
{
	if (pass2&&destBu&&!error)
	{
		OSStatus err = ok;
		XXTRAP(!targetfile);

		if (targetstyle=='x')
		{
			err = IntelHexDump ( targetfile, targetfilepointer, destBu, destEnd-destBu );
		}
		else
		{
			targetfilepointer += destEnd-destBu;
			if ( fwrite(destBu,destEnd-destBu,1,targetfile) != 1 ) err = ferror(targetfile);
		}
		if (err!=ok) SetError( CatStr(targetname?targetname:"stdout",": ",ErrorStr/*2007-05-08*/(err)) );
	}

	DeleteDestBu();
}


/* ==========================================================
				Initializing et al
========================================================== */


/* ----	initialize data members -----------------------------
		setup data members to reset condition
		allocate buffers
*/
void Ass::init ( )
{
	listf			 = false;
	listv			 = false;

	maxerrors 	 	 = 50;
	errors			 = 0;
	error			 = NULL;
	targetstyle		 = ' ';					// ' '/'b'/'x' == default/binary/intel hex
	target			 = 0;

	cond_off		= 0;
	memset(cond,no_cond,sizeof(cond));

	sourcename		 = NULL;
	listname		 = NULL;
	targetname		 = NULL;
	sourcefile		 = NULL;
	targetfile		 = NULL;
//	targetfilepointer= 0;
	listfile		 = NULL;

	GetDateTime(datetime);
	pass2			 = false;
	lines			 = 0;
	line			 = 0;

	lblBu = lblPtr	 = new Lbl[100];
	lblEnd			 = lblBu ? lblBu+100 : NULL;

	locBu = locPtr   = new Lbl*[20];
	locEnd 			 = locBu ? locBu+20 : NULL;

	destBu = destPtr = destPtr0 = destEnd = NULL;
	org 			 = 0;

	dataPtr = dataEnd = 0;
}



/* ----	set pass 2 -------------------------------------------
	this method is virtual!
*/
void Ass::Pass2 ( )
{
	target  = 0;
	pass2 	= true;
	lines	= 0;
	line	= 0;
	locPtr	= locBu;
	destPtr	= destPtr0 = destBu;
	org		= 0;
//	targetfilepointer = 0;
	dataPtr	= dataEnd = 0;
}



/* ----	purge all buffers -----------------------------------
*/
void Ass::kill ( )
{
	delete[] lblBu;
	delete[] locBu;
	delete[] destBu;

	if (sourcefile&&fileno(sourcefile)>2) fclose(sourcefile);
	if (targetfile&&fileno(targetfile)>2) fclose(targetfile);
	if (listfile  &&fileno(listfile)>2)   fclose(listfile);

	delete[] sourcename;
	delete[] targetname;
	delete[] listname;
}



/* ---- re-initialize ----------------------------------------
		this method is virtual!
*/
void Ass::Reset ( )
{
	kill();
	init();
}



/* ==========================================================
				Handle labels
========================================================== */


/* ----	store label -----------------------------------------
*/
void Ass::AddLabel ( cstr name, long value )
{
	if ( value!=(short)value && value!=(ushort)value ) { SetError("number too big"); return; }
	long len = StrLen(name);
	if (len>=MAXLBLLEN) { SetError("name too long"); return; }

	if (lblPtr>=lblEnd)		// buffer needs growing?
	{
		const int more = 200;
		long n = lblEnd-lblBu;
		Lbl* z = new Lbl[n+more];
		if (!z) { SetError("out of memory"); return; }
		memcpy ( z, lblBu, n*sizeof(Lbl) );
		delete[] lblBu;
		lblBu  = z;
		lblPtr = lblBu+n;
		lblEnd = lblPtr+more;
	}

	lblPtr->value = value;
	memcpy(lblPtr->name,name,len+1);
	lblPtr++;
}



/* ----	find label -------------------------------------
*/
Lbl* Ass::FindLabel ( cstr name )
{
	for ( Lbl* p=lblPtr-1; p>=lblBu; p-- )
	{
		if (SameStr(name,p->name)) return p;
	}
	return NULL;
}



Lbl* Ass::FindLocLbl ( cstr name )
{
	Lbl* p0 = locPtr>locBu ? locPtr[-1] : lblBu;

	for ( Lbl* p=lblPtr-1; p>=p0; p-- )
	{
		if (SameStr(name,p->name)) return p;
	}
	return NULL;
}



long Ass::Labels ( )
{
	return lblPtr-lblBu;
}



void Ass::ListLabels ( FILE* f )
{
	if (!f) f=listfile;
	if (!f) f=stdout;
	fprintf( f, "\n; +++ defined symbols +++\n" );

	for( Lbl*l=lblBu; ::NoError()&&l<lblPtr; l++ )
	{
		if (strlen(l->name)>=8)
			fprintf( f, "\t%s\tequ\t$%04lX\t; = %6li\n", l->name, l->value, l->value );
		else
			fprintf( f, "\t%s\t\tequ\t$%04lX\t; = %6li\n", l->name, l->value, l->value );
	}

	fputc('\n',f);
	CheckErrno();
}



/* ==========================================================
				Handle local labels
========================================================== */


/* ----	save current label state ----------------------------
*/
void Ass::BeginLocal ( )
{
	if (locPtr<locEnd) *locPtr++ = lblPtr;
	else SetError("nesting error");
}



/* ----	restore previous label state ------------------------
*/
void Ass::EndLocal ( )
{
	if (locPtr>locBu) lblPtr = *--locPtr;
	else SetError("nesting error");
}



/* ==========================================================
				Handling the source
========================================================== */

inline char lc       ( char c ) { return c|0x20; }

inline bool is_eol   ( char c )	{ return c==0; }
inline bool is_space ( char c )	{ return c>0 && c<=' '; }

inline bool is_upper ( char c ) { return c>='A' && c<='Z'; }
inline bool is_lower ( char c ) { return c>='a' && c<='z'; }
inline bool is_alpha ( char c ) { return lc(c)>='a' && lc(c)<='z'; }

inline bool is_bin   ( char c ) { return c>='0' && c<='1'; }
inline bool is_num   ( char c ) { return c>='0' && c<='9'; }
static bool is_hex	 ( char c ) { return is_num(c) || (lc(c)>='a' && lc(c)<='f'); }

static bool is_idf	 ( char c ) { return is_alpha(c) || is_num(c) || c=='_'; }



/* ----	peek next char --------------------------------------
		skip white space
		and peek next char
		returns 0 at end of line
*/
char Ass::PeekChar ( )
{
	char c = *srcPtr;
	while ( is_space(c) ) c = *++srcPtr;
	return c;
}



/* ----	test for and skip char ------------------------------
		skip white space
		test for and skip next char
*/
bool Ass::TestChar ( char c )
{
	if (PeekChar()==c) { srcPtr++; return true; }
	return false;
}

bool Ass::TestComma ( )
{
	if (PeekChar()==',') { srcPtr++; return true; }
	return false;
}



/* ----	test for and skip char ------------------------------
		skip white space
		test for and skip next char
		raise error if wrong
*/
bool Ass::Expect ( char c )
{
	if (PeekChar()==c) { srcPtr++; return true; }
	if(!error) SetError(CatStr("'",CharStr(c),"' expected"));
	return false;
}

bool Ass::ExpectComma ( )
{
	if (PeekChar()==',') { srcPtr++; return true; }
	if(!error) SetError( "',' expected" );
	return false;
}

bool Ass::ExpectClose ( )
{
	if (PeekChar()==')') { srcPtr++; return true; }
	if(!error) SetError( "')' expected" );
	return false;
}



/* ----	test for end of line --------------------------------
*/
bool Ass::TestEol ( )
{
	char c = PeekChar();
	return c==';' || is_eol(c);
}



/* ----	test for end of line --------------------------------
		raise error if wrong
*/
bool Ass::ExpectEol ( )
{
	if (error||TestEol()) return true;
	SetError("end of line expected");
	return false;
}



/* ----	get next word from source line ---------------
		returned word is either const
		or allocated from the quick string pool
*/
cstr Ass::NextWord ( )
{
	if (TestEol()) return "";

	cstr word = srcPtr++;
	char c    = *word;

	switch ( c )
	{
	case '+':	return "+";
	case '-':	return "-";
	case '*':	return "*";
	case '/':	return "/";
	case '\\':	return "\\";
	case '~':	return "~";
	case '=':	return "=";
	case '(':	return "(";
	case ')':	return ")";
	case '&':	return "&";
	case '|':	return "|";
	case ',':	return ",";

	case '"':								// "abcd"
	case '\'':								// 'abcd'
		while ( *srcPtr!=c && !is_eol(*srcPtr) ) srcPtr++;
		if (*srcPtr==c) srcPtr++;
		break;

	case '$':								// pc or hex number
		while (is_hex(*srcPtr)) srcPtr++;
		break;

	case '%':								// binary number
		while ( is_bin(*srcPtr) ) srcPtr++;
		break;

	case '<':
		c = *srcPtr++;
		if (c=='>') return "<>";
		if (c=='=') return "<=";
		if (c=='<') return "<<";
		srcPtr--;   return "<";

	case '>':
		c = *srcPtr++;
		if (c=='>') return ">>";
		if (c=='=') return ">=";
		srcPtr--;   return "<";

	default:			 		// name, decimal number, garbage
		if (is_idf(c)) while (is_idf(*srcPtr)) srcPtr++;
		break;
	}

	return SubStr ( word, srcPtr );
}



/* ==========================================================
				store object code
========================================================== */


bool Ass::CheckFree ( int n )
{
	destPtr += n;
	if (destPtr<=destEnd) return true;
	if (destBu) { SetError( "code segment overflow", fatal ); return false; }
	if (target!=0&&target!=' rom'&&target!=' bin') { SetError( "no code segment defined", fatal ); return false; }

// kio 2005-04-08: "#code" now optional for .rom and .bin
// if no #code segment defined yet, define it here, to maximum, will be auto-truncated

	AssembleLine("#code\t0,$10000\t; ((inserted by zasm))"); if(error) { /* FatalError(); */ return false; } 

	destPtr += n;
	return destPtr<=destEnd;
}



/* ----	store 1,2,3,4 bytes -------------------------------
*/
inline void Ass::store_1 ( int n )
{	if (CheckFree(1)) destPtr[-1]=n;
}
void Ass::store_2 ( int n, int m )
{	if (CheckFree(2)) destPtr[-2]=n, destPtr[-1]=m;
}
void Ass::store_3 ( int n, int m, int u )
{	if (CheckFree(3)) destPtr[-3]=n, destPtr[-2]=m, destPtr[-1]=u;
}
void Ass::store_4 ( int n, int m, int u, int v )
{	if (CheckFree(4)) destPtr[-4]=n, destPtr[-3]=m, destPtr[-2]=u, destPtr[-1]=v;
}



/* ----	store 1 byte opcode ------------------------------
*/
void Ass::store_opcode ( int n )
{
	store_1(n);
}



/* ----	store 1 byte -------------------------------------
		store byte and check value
*/
void Ass::store_byte ( int n )
{
	if (pass2 && (n>255||n<-128)) SetError ( "byte value out of range" );
	store_1(n);
}



/* ----	store 1 byte -------------------------------------
 		store byte offset and check range
*/
void Ass::store_offset ( int n )
{
	if (pass2 && n!=(char)n) SetError("offset out of range");
	store_1(n);
}



/* ----	store 2 bytes (lsb first) -------------------------
*/
void Ass::store_word ( int n )
{
	store_2(n,n>>8);
}



/* ----	store multiple bytes ------------------------------
*/
void Ass::store_block ( cstr blk, int n )
{
	if (CheckFree(n)) memcpy ( destPtr-n, blk, n );
}



/* ---- store space ---------------------------------------
*/
void Ass::store_space ( int c, int n )
{
	if (!error&&CheckFree(n)) memset (destPtr-n, c, n);
}



/* ----	store multiple bytes ------------------------------
		source bytes are stuffed as hex
		n = bytes to stuff   ( <=> 2*n hex digits )
*/
void Ass::store_hexbytes ( cstr blk, int n )
{
	if (CheckFree(n))
	{
		char* dest = destPtr-n;
		while (n--)
		{
			char c = *blk++;  c = c>'9' ? lc(c)-('a'-10) : c-'0';
			char d = *blk++;  d = d>'9' ? lc(d)-('a'-10) : d-'0';
			*dest++ = (c<<4)+d;
		}
	}
}



/* ==========================================================
				Assemble source
========================================================== */


/* ----	evaluate expression --------------------------------------------
		stops if end of expression reached or
		stops if operator with priority equal or less is encountered
		if !pass2  missing labels are ignored and the returned value may be wrong
		if  pass2  missing labels rise an error
*/
long Ass::Value ( int prio )
{
	if (error) return 0;

	char c;				// scratch
	long n = 0;			// value of expression

	bool force = (prio&pForce) || pass2;

	prio &= ~pForce;


// ---- expect term ----
	cstr w = NextWord();		// get next word

// empty word ?
	if (w[0]==0) goto qq;

// 1 char word ?
	if (w[1]==0)
	{
		switch(w[0])
		{
		case ';':	SetError("value expected");  return 0;		// comment  =>  unexpected end of line
		case '+':	n = +Value(pUna); goto op;					// plus sign
		case '-':	n = -Value(pUna); goto op;					// minus sign
		case '~':	n = ~Value(pUna); goto op;					// complement
		case '(':	n =  Value(pAny); Expect(')'); goto op;		// brackets
		case '$':	n = org + destPtr0-destBu;     goto opi;	// pc
		}
	}
	else
	{
		c = 0;

		if (w[0]=='$')						// hex number
		{	w++;
	hn:		while ( is_hex(*w) ) { n = (n<<4)+(*w&0x0f); if (*w>'9') n+=9; w++; }
			if (w[c!=0]==0) goto opi; else goto qq;
		}
		else if (w[0]=='%')					// binary number
		{	w++;
	bn:		while ( is_bin(*w) ) { n += n + (*w&1); w++; }
			if (w[c!=0]==0) goto opi; else goto qq;
		}
		else if (w[0]=='\'')				// ascii number
		{
			if (w[2]==0) goto qq;
			while (w[2]) { w++; n = (n<<8) + *w; }
			if (w[1]=='\'') goto opi; else goto qq;
		}
		else if (is_num(w[0]))
		{
			c = w[StrLen(w)-1];
			if ( tolower(c)=='h' ) goto hn;	// hex number    indicated by suffix
			if ( tolower(c)=='b' ) goto bn;	// binary number indicated by suffix
		}
	}

	if (is_num(w[0]))						// number
	{
		while ( is_num(*w) ) { n = n*10 + *w-'0'; w++; }
		if (*w==0) goto opi; goto qq;
	}

	if (is_idf(w[0]))						// name
	{
		Lbl* l = FindLabel(w);
		if (l) n = l->value;
		else if (force) SetError("label not found");
	}
	else
	{
qq:		SetError("syntax error");
	}

// ---- expect operator ----
op:	if (error) return 0;

opi:
	if (TestEol()) return n;		// end of line

	switch (PeekChar())				// peek next character
	{
	case ';':	  return n;			// comment  =>  end of line
	case '+':	  if (pAdd<=prio) return n; srcPtr++;  n = n +	Value(pAdd); goto op;	// add
	case '-':	  if (pAdd<=prio) return n; srcPtr++;  n = n -	Value(pAdd); goto op;	// subtract
	case '*':	  if (pMul<=prio) return n; srcPtr++;  n = n *	Value(pMul); goto op;	// multiply
	case '/':	  if (pMul<=prio) return n; srcPtr++;  n = n /  Value(pMul); goto op;	// divide
	case '%':		// added % for remainder too ... kio 6.feb.2002
	case '\\':	  if (pMul<=prio) return n; srcPtr++;  n = n %	Value(pMul); goto op;	// remainder (same prio as '*')
	case '&':	  if (pBoo<=prio) return n; srcPtr++;  n = n &  Value(pBoo); goto op;	// boolean and
	case '|':	  if (pBoo<=prio) return n; srcPtr++;  n = n |  Value(pBoo); goto op;	// boolean or
	case '^':	  if (pBoo<=prio) return n; srcPtr++;  n = n ^  Value(pBoo); goto op;	// boolean xor

	case '=':	  if (pCmp<=prio) return n; srcPtr+=1; 
													   if(srcPtr[0]=='=') { srcPtr++; } // allow '==' too 2006-09-09 kio
													   n = -(n==Value(pCmp)); goto op;	// equal

	case '!':																			// allow '!=' too 2006-09-09 kio
	  c = srcPtr[1];	
	  if(c=='='){ if (pCmp<=prio) return n; srcPtr+=2; n = n != Value(pCmp); goto op; }	// not equal
	  break;
	  
	case '<':
	  c = srcPtr[1];
	  if(c=='<'){ if (pRot<=prio) return n; srcPtr+=2; n = n << Value(pRot); goto op; }	// shift left
	              if (pCmp<=prio) return n;		// korr. 2006-09-09 kio
	  if(c=='>'){                           srcPtr+=2; n = -(n!=Value(pCmp)); goto op; }// not equal
	  if(c=='='){                           srcPtr+=2; n = -(n<=Value(pCmp)); goto op; }// equal or less
	                                        srcPtr+=1; n = -(n< Value(pCmp)); goto op;	// less than
	case '>':
	  c = srcPtr[1];
	  if(c=='>'){ if (pRot<=prio) return n; srcPtr+=2; n = n >> Value(pRot); goto op; }	// shift right
				  if (pCmp<=prio) return n;		// korr. 2006-09-09 kio
	  if(c=='='){                           srcPtr+=2; n = -(n>=Value(pCmp)); goto op; }// greater or less
		                                    srcPtr+=1; n = -(n> Value(pCmp)); goto op;	// greater than
	}

// no operator followed  =>  return value; caller will check the reason of returning anyway
	return n;
}



/* ----	handle label definition -----------------------------
*/
void Ass::DefineLabel ( cstr name )
{
	TestChar(':');					// skip optional ':'

	cstr s = srcPtr;				// remember parser position
	cstr w = LowerStr(NextWord());	// test next word

// label: equ  <value>
// label: defl <value>
	if ( SameStr(w,"equ") || SameStr(w,"defl") )
	{
		long value = Value(pAny|pForce);

		Lbl* l = FindLocLbl(name);
		if (l)
		{
			if (l->value!=value) SetError("value redefined");
		}
		else
		{
			AddLabel ( name, value );
		}
	}

	else if ( SameStr(w,"data") )	// label: data <value>
	{
		long n = Value(pAny|pForce);

		if (!pass2) AddLabel ( name, dataPtr );

		if (n>=0)
		{
			dataPtr += n;
			if (dataPtr>dataEnd) SetError("data segment overflow");
		}
		else
		{
			SetError("data size must not be negative");
		}
	}

	else	// label: <opcode>
	{
		srcPtr = s;		// put back last word, because it was not 'defl' 'equ' or 'data'
		if (!pass2) 
		{
			long value = org + destPtr-destBu;

			Lbl* l = FindLocLbl(name);
			if (l)
			{
				if (l->value!=value) SetError("label redefined");
			}
			else
			{
				AddLabel ( name, value );
			}
		}
	}
}



/* ----	evaluate opcode -------------------------------------
		this method is virtual
		derived assemblers replace it to implement their opcodes
		but call it if they dont recognize an opcode name
		the opcode name is already read and passed in w
		returns true if handled
		sets error if errors occur
*/
bool Ass::AssInstr ( cstr w )
{	int n;

	switch (StrLen(w))
	{
	case 0:			// end of line  =>  empty line or comment only
		goto l;		// handled

	case 2:
		switch (peek_2(w))
		{
		case '  db':	goto db;	// 2002-09-17 kio added
		case '  dw':	goto dw;	// 2002-09-17 kio added
		case '  ds':	goto ds;	// 2002-09-17 kio added
		case '  dm':	goto dm;	// 2002-09-17 kio added  ((not shure whether this was common syntax))
		}
		break;

	case 3:			
		switch (peek_3(w))
		{
		case ' org':
			if(!destBu) 
			{	// kio 2005-04-08: "#code" now optional for .rom and .bin
				// if no #code segment defined yet, define it here, to maximum, will be auto-truncated
				if (target!=0&&target!=' rom'&&target!=' bin') SetError( "no code segment defined", fatal ); 
				else AssembleLine("#code\t0,$10000\t; ((inserted by zasm))");		
				if(error) goto l;
			}
			org = Value(pAny|pForce) -(destPtr-destBu);			// only adjust org, don't move destPtr
			goto l;
		}
		break;

	case 4:
		switch (peek_4(w))
		{
		case 'defs':
	ds:		n = Value(pAny|pForce);

			if (error)		{ SetError("could not evaluate gap size"); goto l; }
			if (n<0)		{ SetError("size negative"); goto l; }
			if (TestComma()){ store_space( Value(pAny), n ); goto l; }
			else 			{ CheckFree(n); goto l; }			// simply increment destPtr: core is preset.			

		case 'defw':
	dw:		do { n=Value(pAny); store_word(n); } while (!error&&TestComma());
			goto l;


		case 'defb':	// defb und defm synonym behandeln.
		case 'defm':	// erlaube jede Mixtur von literal, label, "text", 'Text', 'c' Char, $abcdef stuffed hex, usw.
	db:	
	dm:	{	cptr oldSrcPtr = srcPtr;
			w = NextWord();
			if (*w==0) { SetError("value expected"); goto l; }

	// Text string or character literal:
			if (w[0]=='\''||w[0]=='"')
			{
				n = StrLen(w);
				if (n<2||w[n-1]!=w[0]) { SetError ( "closing quotes expected" ); goto l; }
				w = MidStr(w,1,n-2);
			cb:	store_block ( w, StrLen(w) );
				if (TestChar('+'))	store_byte(*--destPtr+Value(pAny)); else
				if (TestChar('-'))	store_byte(*--destPtr-Value(pAny)); else
				if (TestChar('|'))	store_byte(*--destPtr|Value(pAny)); else
				if (TestChar('&'))	store_byte(*--destPtr&Value(pAny)); else
				if (TestChar('^'))	store_byte(*--destPtr^Value(pAny)); else
				if (TestChar('*'))	store_byte(*--destPtr*Value(pAny)); else
				if (TestChar('%') ||
					TestChar('\\'))	store_byte(*--destPtr%Value(pAny)); else
				if (TestChar('/'))	store_byte(*--destPtr/Value(pAny));
				if (TestComma() && !error) goto dm; else goto l;
			}
			
	// Stuffed Hex:
			n = StrLen(w);
			if( n>3 && w[0]=='$' )
			{
			sx:	w = MidStr(w,1); n-=1;
			sh:	if (n&1) { SetError ( "equal number of hex characters expected" ); goto l; }
				store_hexbytes(w,n/2);
				if (TestComma()) goto dm; else goto l;
			}

			if( n>4 && _is_dec_digit(w[0]) && tolower(w[n-1])=='h' ) 
			{
				w = LeftStr(w,n-1); n-=1; 
				if( n&1 && w[0]=='0' ) goto sx;		// 2007-09-25 kio: added
				goto sh; 
			}

	// pre-defined special words:
			if (*w=='_')
			{
				if (SameStr(w,"__date__")) { w = GetDate(); w += *w==' '; goto cb; }
				if (SameStr(w,"__time__")) { w = GetTime(); w += *w==' '; goto cb; }
				if (SameStr(w,"__file__")) { w = sourcename?sourcename:"stdin"; goto cb; }
			}
			
	// anything else:
			srcPtr = oldSrcPtr;
			n = Value(pAny); store_byte(n);
			if (TestComma() && !error) goto dm; else goto l;
		}
		}
	}

	return no;		// not handled
l:	return yes;		// handled
}



void Ass::HandleTarget()
{	cstr w,x;

// #target <nikname>
// known targets are: 'rom' and 'bin'
// more targets may be added by AssDirect() of derived class
// open target file
// must be balanced by #end

	if (target)
	{	SetError("#target already defined",fatal);
		return;
	}

	w = NextWord();
	StripQuotes(w);
	x = strrchr(w,'.');
	if (x) x++; else x=w;
	switch(strlen(x))
	{
	case 0:	SetError("argument missing",fatal); return;
	case 1:	target=peek_1(x); break;		// "X"    --> 'x'
	case 2:	target=peek_2(x); break;		// "XY"   --> '  xy'
	case 3:	target=peek_3(x); break;		// "XYZ"  --> ' xyz'
	default:target=peek_4(x); break;		// "WXYZ" --> 'wxyz'
	}

// full filename supplied ?
	if (x!=w)
	{
		SetError("TODO: filenames not yet supported",fatal);
		return;
	}

// mangle targetname
	if (targetname&&LastChar(targetname)=='$')
	{
		if (targetstyle==' ')  targetstyle = 'b';			// assume file => default style = binary
		cstr t = targetstyle=='b' ? "" : ".hex";			// secondary extension for intel hex files => e.g. "myfile.rom.hex"
		cstr z=targetname;
		cstr d=strrchr(z,'.'); XXTRAP(!d);
		targetname = NewCopy(CatStr(SubStr(z,d+1),x,t));
		delete[] z;
	}

	if (pass2)
	{
		if (targetname)  targetfile = fopen(targetname,"w");  // note: targetname may be changed by assembler source!
		if (!targetfile) targetfile = stdout;
		targetfilepointer = 0;
		// enforce hexdump for tty
		// note: therefore subsequent #targets even to non-TTY are forced to hexdump too
		if (IsTTY(targetfile)) targetstyle='x';
		if (targetstyle==' ')  targetstyle = IsFile(targetfile) ? 'b' : 'x';
	}
}



/* ----	handle #code <start>,<size> --------------
		note: called for .bin and .rom only
		Derived assemblers (eg. AssZ80) reimplement AssDirect()
		which call their own #code handlers for own target types.
*/
void Ass::HandleCode()
{	int n,m;
// #code <start>,<size>
// write current code segment to target file (if any)
// purge current code buffer (if any)
// allocate new code segment
// define starting pc 'org' and segment size

	if (!target) 
	{ 
		AssembleLine("#target\trom\t\t; ((inserted by zasm))"); if(error) return;	// kio 2005-04-08
		// SetError("#code without #target",fatal); return; 
	}

// write current #code segment to file (if any)
	TruncateSegment(no||targetstyle=='x');	// not the last code segment => don't truncate
	WriteSegment();							// except intel hex format => always truncate

// parse arguments
	n = Value(pAny|pForce); ExpectComma(); if (n!=(short)n&&n!=(ushort)n) SetError("illegal start",fatal);
	m = Value(pAny|pForce); if (m<=0||m>0x10000) SetError("illegal length",fatal);	// allow 1 .. $10000
	if ( ushort(n)+m > 0x10000 ) SetError("start + length exceeds $10000",fatal);

// create new code segment
	targetfilepointer = n;					// 2005-03-23 kio: set physical address base for intel hex files
	org = n;
	NewDestBu( m, -(target==' rom') );		// preset with $00 / $FF for defs instruction
}



/* ---- handle #end ----------------------------
		note: called directly for .bin and .rom only
		Derived assemblers (eg. AssZ80) reimplement AssDirect()
		which call their own #end handlers for own target types.
*/
void Ass::HandleEnd()
{
// #end
// truncate code segment to fit
// write code segment to target file
// purge code buffer
// close target file

	if (!target) { SetError("#end without #target",fatal); return; }

// write current code segment to file
	TruncateSegment(yes);				// last segment => truncate
	WriteSegment();

// if intel hex file append closing record
	if (targetfile && targetstyle=='x')
	{
		if( fputs(":00000001FF\r\n", targetfile) < 0 ) SetError(ferror(targetfile));
	}

// close target file (if not stdout/stderr)
	if (targetfile&&fileno(targetfile)>2)
	{
		fclose(targetfile);
		targetfile = NULL;
	}

	target=0;
}



void Ass::HandleData()
{	int n,m;
// #data <start>,<size>
// define data segment
// define starting address and size
// there is no closing tag

// parse arguments
	n = Value(pAny|pForce); ExpectComma(); if (n!=(short)n&&n!=(ushort)n) SetError("illegal start",fatal);
	m = Value(pAny|pForce); if (m<0||m>0x10000) SetError("illegal length",fatal);	// allow 0 .. $10000
	if ( ushort(n)+m > 0x10000 ) SetError("start + length exceeds $10000",fatal);

	dataPtr = n;
	dataEnd = n+m;
}



void Ass::HandleInclude()
{
// #include <"path/filename">
// save current source file state
// load include file
// assemble by recursive call to this procedure
// unload include file
// restore current source file state

	cstr w = NextWord(); if (error) return;
	StripQuotes(w);
	Include(w);
}



void Ass::HandleInsert()
{
// #insert <"path/filename">
// insert file's contents into code

	cstr w = NextWord(); if (error) return;
	StripQuotes(w);

	if (sourcename) w = CatStr(DirectoryFromPath(sourcename),w);

	FILE* file = fopen(w,"r");
	if (!file) {  SetError(errno,fatal); return; }
	int n = destEnd-destPtr;
	int m = fread(destPtr,1,n,file); destPtr += m;		// ob auch n==0 bytes erlaubt sind?
	OSStatus err=ferror(file);
	if(err) SetError(err);
	else if(n==m)
	{
		char c;
		(void)fread(&c,1,1,file);
		err=ferror(file);
		if(err) SetError(err);
		else if (!feof(file)) CheckFree(1);			// trigger code segment error
	}
	fclose(file);
}



/* ----	handle #if <condition> -------------
		2002-09-17 kio: revised
*/
void Ass::HandleIf()
{
// #if <value>
// start block of source which is only assembled if value==true
// any number of #elif may follow
// then single #else may follow
// then final #endif must follow
// while assembling is disabled, only #if, #else, #elif and #endif are recognized
// also note that #include is also skipped if conditional assembly is off.

	if( cond[NELEM(cond)-1] != no_cond ) { SetError("too many conditions nested"); return; }
	bool f = cond_off || Value(pAny|pForce);			// higher nesting level off => ignore; else evaluate value
	if(!cond_off) { if(ExpectEol()){/*ok*/}else{/*error*/ errors |= 0x1000; /*isfatal*/ }; }
	memmove( cond+1, cond, NELEM(cond)-1 );
	cond[0] = cond_if + f;
	cond_off = (cond_off<<1) + !f;
}



/* ----	handle #else -----------------------
		2002-09-17 kio: revised
*/
void Ass::HandleElif()
{
	switch(cond[0])
	{
	default:			SetError("#elif without #if");	break;
	case cond_else:		SetError("#elif after #else");	break;
	case cond_if_dis:	cond_off |= 1; 					break;	// disable #elif clause
	case cond_if:
		XXXTRAP((cond_off&1)==0);
		bool f = (cond_off>>1) || Value(pAny|pForce);	// higher nesting level off => ignore; else evaluate value
		cond_off -= f;									// if f==1 then clear bit 0 => enable #elif clause
		cond[0]  += f;									// and switch state to cond_if_dis => disable further elif evaluation
		break;
	}
}



/* ----	handle #else -----------------------
		2002-09-17 kio: revised
*/
void Ass::HandleElse()
{
	switch(cond[0])
	{
	default:			SetError("#else without #if");		 break;
	case cond_else:		SetError("multiple #else clause");	 break;
	case cond_if_dis:	cond[0] = cond_else; cond_off |=  1; break;		// disable #else clause
	case cond_if:		cond[0] = cond_else; cond_off &= ~1; break;		// enable #else clause
	}
}



/* ----	handle #else -----------------------
		2002-09-17 kio: revised
*/
void Ass::HandleEndif()
{
	if( cond[0]==no_cond ) { SetError("no #if pending"); return; }
	memmove( cond, cond+1, NELEM(cond)-1 );
	cond[NELEM(cond)-1] = no_cond;
	cond_off = cond_off>>1;
}



void Ass::HandleLocal(){	TODO();
}

void Ass::HandleEndlocal(){	TODO();
}

void Ass::HandleMacro(){	TODO();
//	#macro	name		<formalparameterliste>
//			...instructions...			implicitly using #local
//	#endmacro	<==> #endlocal
}


/* ----	handle #directive --------------------------------------
		this method is virtual
		derived assemblers replace it to implement their own #directives
		but call it if they dont recognize a #directive
		returns true if handled
		sets error if errors occur
*/
bool Ass::AssDirect ( cstr w )
{
	if (SameStr(w,"if"))	  HandleIf();		else
	if (SameStr(w,"elif"))	  HandleElif();		else
	if (SameStr(w,"else"))	  HandleElse();		else
	if (SameStr(w,"endif"))	  HandleEndif();	else

	if (cond_off) 			  return yes; 		else

	if (SameStr(w,"target"))  HandleTarget();	else
	if (SameStr(w,"end")) 	  HandleEnd();		else
	if (SameStr(w,"code"))	  HandleCode();		else
	if (SameStr(w,"data"))	  HandleData();		else
	if (SameStr(w,"include")) HandleInclude();	else
	if (SameStr(w,"insert"))  HandleInsert();	else
	if (SameStr(w,"local"))	  HandleLocal();	else
	if (SameStr(w,"endlocal"))HandleEndlocal();	else
	if (SameStr(w,"macro"))	  HandleMacro();	else return no;

	if (error) FatalError();

	return yes;		// handled;
}




/* ----	assemble single line ------------------
		if you assemble line by line:
			Reset()					<- only if reusing Ass instance
			n* AssembleLine(str)	<- only if forward references used
			Pass2()
			n* AssembleLine(str)
*/
void Ass::AssembleLine( cstr source )
{	cstr w;
	XXTRAP(!source);
	XXTRAP( error);

	const char* oldSrcPtr = srcPtr;		// in case of recursive calls		kio 2005-04-08
	srcPtr   = source;
	destPtr0 = destPtr;

	line++;
	lines++;

// empty line ?
	if (*source==0) goto x;

// comment starting in column 1 ?
	if (*source==';') goto x;

// #directive ?
	if (*source=='#')
	{
		srcPtr++;
		w = LowerStr(NextWord());
		if (!AssDirect(w)) SetError( CatStr("unknown directive '#",w,"'") );
		if (error) FatalError();
		goto x;
	}

// assembling conditionally off ?
	if (cond_off) goto x;

// label definition ?
	if ((uchar)*source>' ')
	{
		DefineLabel(NextWord());
		if (error) goto x;
	}

// handle opcode or pseudo opcode
	w = LowerStr(NextWord());
	if (!AssInstr(w)) SetError( "unknown opcode " );
	ExpectEol();

// write listing
x:	if( listv&&listf )
	{
		HexDump ( listfile );
		//fputc('\t',listfile);
		//if(destPtr==destPtr0) fputc('\t',listfile);
		//if(destPtr==destPtr0) fprintf(listfile,"        ");
	}

	if (listf)
	{
		fprintf(listfile,"%s\n",source);

		if (error)
		{
			fprintf
			( listfile, "%s%s^ ***ERROR***: %s\n",
				SpaceStr(15*(listv&&listf)), WhiteStr(SubStr(source,srcPtr-1)), ErrorText()
			);
		}
	}

// list copy to stderr
	if( error && (!listf || listfile!=stderr) )
	{
		fprintf
		( stderr, "%s\n%s^ ***ERROR***: %s\n",
			source, WhiteStr(SubStr(source,srcPtr-1)), ErrorText()
		);
	}

// yielded error logging errors itself ?
	if (errno)
	{
		error=NULL;
		SetError(errno,fatal);
	}
	else
	{
		ClearError();
	}
	
	srcPtr = oldSrcPtr;		// in case of recursive calls		kio 2005-04-08
}


/* ----	include source file -----------------------------------------
*/
void Ass::Include ( cstr sname )
{	cstr z_sourcename = sourcename;
	FILE* z_sourcefile = sourcefile;

	ClearError();
	if (sourcename) sname = CatStr(DirectoryFromPath(sourcename),sname);
	sourcename = NewCopy(sname);

	if (sourcename)
	{
		sourcefile = fopen(sourcename,"r");
		if (!sourcefile) { SetError(errno); goto x; }
	}
	else
	{
		sourcefile = stdin;
	}

	// remember #if states
	// ***REVISE*** ***TODO***  Ass:Include()
	char z_cond[sizeof(cond)/sizeof(char)];
	memcpy(z_cond,cond,sizeof(cond));

	for( line=0; errors<maxerrors; )
	{
		cstr s = NewReadStr(sourcefile);
		if(!s) break;
		AssembleLine(s);
		delete[] s;
	}

	if (memcmp(cond,z_cond,sizeof(cond))) SetError("#endif missing",fatal);

x:	if (sourcefile&&fileno(sourcefile)>2) fclose(sourcefile);
	sourcefile = z_sourcefile;
	delete[] sourcename;
	sourcename = z_sourcename;
}


/* ----	assemble file ----------------------------
		do the complete job
*/
void Ass::AssembleFile ( cstr sname, cstr dname, cstr lname, bool l1, bool l2, bool v, bool w, char style )
{
// init:
	listname    = NewCopy(lname);
	targetname  = NewCopy(dname);
	targetstyle = style;

	if(l1||l2||v) fprintf( stderr, "  zasm: \"%s\", \"%s\", \"%s\"\n", sname?sname:"stdin", dname?dname:"stdout", lname?lname:"stderr" );

// pass 1
	if(l1)
	{
		if (!listfile)
		{	if (listname)  listfile = fopen(lname,"w");
			if (!listfile) listfile = stderr;
		}
	}

	SetListv(v);
	SetList(l1);
	Include(sname); if(error||errors) goto x;
	/* if (target) { SetError("#end missing",fatal); return; */ 
	if (target) { AssembleLine("#end\t\t\t; ((inserted by zasm))"); if(error||errors) goto x; }	// kio 2005-04-08
	if (l1&&w) ListLabels(); if(error||errors) goto x;

// pass 2
	if(l2)
	{
		if (!listfile)
		{	if (listname)  listfile = fopen(lname,"w");
			if (!listfile) listfile = stderr;
		}
	}

	if(l1&&l2) fputs( "\n\n######## pass 2 ########\n\n\n", listfile );

	Pass2(); if (error) goto x;
	SetList(l2);
	Include(sname); if(error||errors) goto x;
	if (target) { AssembleLine("#end\t\t\t; ((inserted by zasm))"); if(error||errors) goto x; }	// kio 2005-04-08
	if (l2&&w) ListLabels(); if(error||errors) goto x;

// exit:
x:	if (error)
	{
		fprintf(stderr,"***ERROR***: %s\n",error);

		if(listfile&&listfile!=stderr) fprintf(listfile,"***ERROR***: %s\n",error);
	}
	if(Errors())
	{
		fprintf(stderr,"  zasm: %i error%s.\n",Errors(),Errors()==1?"":"s");
	}
	else //if(l1||l2)
	{
		fputs("  zasm: no errors.\n",stderr);
	}
}








