/*	Copyright  (c)	Günter Woigk 1994 - 2009
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.
*/

#ifndef Ass_h
#define Ass_h

#include "kio/kio.h"


typedef signed long OSStatus;


// ----	structs declared inside ass.cp ----
struct Lbl;


// ----	priorities for LineAssZ80::Value(prio) ----
enum
{ 	pAny = 0,		// whole expression: up to ')' or ','
	pCmp, 			// comparisions:	 lowest priority
	pAdd, 			// add, sub
	pMul, 			// mul, div, rem
	pBoo, 			// bool/masks:		 higher than add/mult
	pRot, 			// rot/shift
	pUna,			// unary operator:	 highest priority
	pForce=128		// force evaluation: even in pass 1
};



OSStatus	IntelHexDump	( FILE* f, ulong& fp, ptr bu, ulong sz );



/* ----	the main class ----------------------------
*/
class Ass
{
protected:
// options:
	bool		listf;			// generate listing
	bool		listv;			// listing verbose incl. obj.code
	int			maxerrors;

// associated files for Include()
	cstr		sourcename;		// current source file
	cstr		listname;		// list file
	cstr		targetname;		// target file
	FILE*		sourcefile;
	FILE*		targetfile;
	ulong		targetfilepointer;	// physical code deposition address
	FILE*		listfile;
	char		targetstyle;	// ' '/'b'/'x' == default/binary/intel hex
	int			target;			// target format: bin, rom, sna etc.

// internal state
	char		datetime[26];	// current date & time for __date__ and __time__
	bool		pass2;			// true if pass 2
	int			errors;			// total errors
	cstr		error;			// current error or NULL==noerror
	long		lines;			// total lines within current pass
	long		line;			// current line within current sourcefile

// cond. assembly:
	ulong		cond_off;		// effective final on/off state of conditions nested: 0 = assemble; !0 => assembly off
	char		cond[32];		// cond. state for up to 32 nested conditional blocks
	enum 	{	no_cond=0, 		// no conditional assembly
				cond_if,		// #if or #elif pending and no path 'on' up to now
				cond_if_dis,	// #if or #elif pending and 'on' path currently or already  processed
				cond_else	 	// #else pending
			};

// source buffer
	const char*	srcPtr;			// current pointer into source text

// label buffer
	Lbl*		lblBu;			// buffer for labels
	Lbl*		lblPtr;			// current ptr into label buffer
	Lbl*		lblEnd;			// end of label buffer

// local contexts
	Lbl**		locBu;			// stack for local contexts
	Lbl**		locPtr;			// current pointer into stack
	Lbl**		locEnd;			// end of stack

// code segment
	char*		destBu;			// target code buffer
	char*		destPtr;		// current write ptr
	char*		destPtr0;		// ptr to start of current instruction ( '$' )
	char*		destEnd;		// end of buffer
	int			org;			// logical code origin normalized to destBu

// data segment
	long		dataPtr;		// current address within data segment
	long		dataEnd;		// end of data segment


// initializing
	void		init			( );	// reset data members; allocate initial buffers
	void		kill			( );	// purge all buffers
	void		DeleteDestBu	( );
	void		NewDestBu		(size_t size, int fillbyte);

// byte order safe lower case peeks
	uchar  		peek_1			(cstr w) 		{ return Peek1X(w) | 0x20;       }
	ulong 		peek_2			(cstr w) 		{ return Peek2X(w) | 0x20202020; }
	ulong  		peek_3 			(cstr w) 		{ return Peek3X(w) | 0x20202020; }
	ulong  		peek_4			(cstr w) 		{ return Peek4X(w) | 0x20202020; }

// label handling
	void		AddLabel		( cstr name, long value );
	Lbl*		FindLabel		( cstr name );
	Lbl*		FindLocLbl		( cstr name );

	void		BeginLocal		( );			// push label pointer
	void		EndLocal		( );			// pop label pointer

// source handling
	bool		TestEol			( );			// test for end-of-line
	bool		ExpectEol		( );			// expect end of line;  raise error if wrong

	char		PeekChar		( );			// peek next char
	bool		TestChar		( char c );		// test for & skip char
	bool		TestComma		( );			// test for & skip comma
	bool		Expect			( char c );		// expect & skip char;  raise error if wrong
	bool		ExpectComma		( );			// expect & skip comma; raise error if wrong
	bool		ExpectClose		( );			// expect & skip ')';   raise error if wrong

	cstr		NextWord		( );			// get & skip next word

// object code storing
	bool		CheckFree		( int n );
	void		store_1			( int );
	void		store_2			( int,int );
	void		store_3			( int,int,int );
	void		store_4			( int,int,int,int );
	void		store_opcode	( int n );
	void		store_byte 		( int n );
	void		store_offset 	( int n );
	void 		store_word		( int n );
	void		store_block		( cstr blk, int  n );
	void		store_space		( int c,    int  n );
	void		store_hexbytes	( cstr hex, int  n );

	void		HexDump			( FILE* f );
	void		TruncateSegment	( bool f=1 )		{ if(f) destEnd = destPtr; }
	void		WriteSegment	( );				// store & delete[] destBu

// compiling
	long		Value			( int prio );		// get, skip & evaluate expression
	void		DefineLabel		( cstr w );			// handle label definition
	void		HandleTarget	( );
	void		HandleEnd		( );
	void		HandleCode		( );
	void		HandleData		( );
	void 		HandleInclude	( );
	void 		HandleInsert	( );
	void 		HandleIf		( );
	void 		HandleElif		( );
	void 		HandleElse		( );
	void 		HandleEndif		( );
	void 		HandleLocal		( );
	void 		HandleEndlocal	( );
	void 		HandleMacro		( );

// virtual methods to be augmented by derived classes
virtual bool	AssInstr		( cstr opc );		// processor specific opcodes
virtual bool	AssDirect		( cstr dir );		// processor specific #directives

public:
				Ass				( )					{ init(); }
	virtual		~Ass			( )					{ kill(); }
				Ass				( const Ass& );		// prohibit
	Ass&		operator=		( const Ass& );		// prohibit

// errors:
	void		ClearError		( )					{ ::ClearError(); error=NULL; }
	void		SetError		( OSStatus/*OSErr*/ n,  bool isfatal=0 );	enum { nonfatal=0, fatal=1 };
	void		SetError		( cstr msg, bool isfatal=0 );
	void		CheckErrno		( );
	void		FatalError		( )					{ errors |= 0x1000; }
	int			Errors			( )					{ return errors&0xfff; }
	void		SetMaxErrors	( int n )			{ maxerrors=n; }
	int			MaxErrors		( )					{ return maxerrors; }
	cstr		ErrorText		( )					{ return error; }

// list options
	void		SetList			( bool f=1 )		{ listf=f; }
	void		SetListv		( bool f=1 )		{ listv=f; }
	bool		List			( )					{ return listf; }
	bool		Listv			( )					{ return listv; }

// querry state
	cstr		DateTime		( )					{ return datetime; }
	cstr		GetDate			( );				// from datetime:  27.Jan.2002
	cstr		GetTime			( );				// from datetime:  23:55:30
	int			Pass			( )					{ return 1+pass2; }
	long		Lines			( )					{ return lines; }
	long		Line			( )					{ return line; }
	long		Labels			( );
	void		ListLabels		( FILE*f=NULL );
	cstr		TargetName		( )					{ return targetname; }

// line assembler:
virtual	void	Reset			( );
virtual void	Pass2			( );				// prepare for pass2   (( to query pass: Pass() ))
	void		Include			( cstr src );
	void		AssembleLine	( cstr txt );

// file assembler:
	void		AssembleFile	( cstr src, cstr dest, cstr list,
								  bool list1, bool list2, bool listv, bool listw, char targetstyle );
};


#endif
