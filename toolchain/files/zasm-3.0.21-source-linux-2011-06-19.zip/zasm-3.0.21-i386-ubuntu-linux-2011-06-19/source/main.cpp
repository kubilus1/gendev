//	utf-8

/*	Copyright  (c)	Günter Woigk 1994 - 2010
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.

	2002-01-20	kio	port to unix started
	2002-01-28	kio	3.0.0 released
*/


#define	LOG 	0
#define	SAFE	2

#include	"config.h"
#include	<stdlib.h>
#include	<dirent.h>
#include	"AssZ80.h"
#include	"kio/errors.h"
#include	"unix/file_utilities.h"



cstr appl_name = "zasm";



/* ---- Hilfstext anzeigen -----------------------------------
		Anzeige optimiert für 80-Zeichen-Terminal
*/
void ShowHelp( FILE* stream )
{
	fprintf( stream, "%s",
"______________________________________________________________________________\n"
"  zasm - z80 assembler (c) 1994-2010 Günter Woigk.\n"
"  version 3.0.21, 2011-05-29, for BSD / Mac OSX.\n"
"  send bug reports to: kio@little-bat.de\n\n"

"syntax:\n"
"  zasm [-vw12bx]  [[-i] inputfile] [-o outfile] [-l listfile]\n\n"

"examples:\n"
"  zasm speccirom.src\n"
"  zasm romsources/* -o roms/\n"
"  zasm -vw2 -i speccirom.src -o rom_v2.0.1.rom\n\n"

"zasm [-vw12] ...\n"
"  all options start with '-'\n"
"  -1  enable listing in pass 1\n"
"  -2  enable listing in pass 2\n"
"  -v  include object code in listing\n"
"  -w  append label listing to listing\n"
"  -b  write output as binary data\n"
"  -x  write output in intel hex format\n\n"

"default output format if no option '-b' or '-x' is used:\n"
"  intel hex format for TTYs\n"
"  binary for regular files and other non-TTYs\n\n"

"zasm ... [[-i] filenames|dirname] ...\n"
"  specify input file(s):\n"
"  if no input file is given, zasm reads from stdin (BUGGY!).\n"
"  if one or multiple files are given, zasm runs once for each file.\n"
"  if input is a tty, then zasm runs in command line mode (BUGGY!).\n"
"  note: '-i' is optional (for most filenames).\n\n"

"zasm ... [-o filename|\"\"|dirname] ...\n"
"  specify output file(s):\n"
"  -o <filename>   => output is written to that file.\n"
"  -o \"\"           => output is written to stdout.\n"
"  -o <directory>:\n"
"    input = file  => output to regular files with derived filenames.\n"
"    input = stdin => default filenames are used.\n"
"  if no output is specified:\n"
"    input = file  => output to regular file with a derived filename.\n"
"    input = stdin => output is written to stdout.\n\n"

"zasm ... [-l filename|\"\"|dirname] ...\n"
"  specify list file(s):\n"
"  same rules as for output files except use of stderr.\n"
"______________________________________________________________________________\n"
"");
}


/* ---- run the assembler -------------

		sname==0	=> stdin		dname==0	=> sname.rom			lname==0	=> sname.log
		sname==""	=> stdin		dname==""	=> stdout				lname==""	=> stderr
		sname==file	=> file			dname==file	=> file					lname==file	=> file
		sname==dir	=> dir			dname==dir	=> dir/sname.rom		lname==dir	=> dir/sname.log
*/
int Assemble ( cstr sname, cstr dname, cstr lname, bool f1, bool f2, bool v, bool w, char style )
{
	int errors = 0;
	::ClearError();
	if (sname&&!*sname) sname=NULL;

	if (sname)
	{
		DIR* dir = opendir(sname);
		if (dir)
		{
		// source == directory
			cstr sdir = sname;
			if (LastChar(sdir)!='/') sdir=CatStr(sdir,"/");
			sdir=NewCopy(sdir); 

			if (!dname) dname = sdir; else if (!*dname) dname = NULL;
			if (!lname) lname = sdir; else if (!*lname) lname = NULL;

			for(;!errors;)	// loop for sdir/*
			{
				struct dirent* d = readdir(dir);
				if(!d) break;

			// skip "." and ".."	note: these are not always direntry[0] and direntry[1]
				if ( d->d_name[0]=='.' && ( d->d_name[1]==0 || (d->d_name[1]=='.' && d->d_name[2]==0) ) ) continue;

				sname = NewCopy( CatStr(sdir,d->d_name) ); 
				errors += Assemble(sname,dname,lname,f1,f2,v,w,style);
				delete[] sname;
			}

			closedir(dir);
			delete[] sdir;
			return errors;
		}
		else
		{
		// source == file/queue/...
			if (!dname) dname=DirectoryFromPath(sname);
			if (!lname) lname=DirectoryFromPath(sname);
		}
	}
	else
	{
	// source == stdin
	}

// now: source = file/pipe/stdin

	if (dname&&!*dname) dname=NULL;
	if (lname&&!*lname) lname=NULL;

// mangle listfile path
	if (lname)
	{
		DIR* dir = opendir(lname);
		if (dir)
		{
			if (LastChar(lname)!='/') lname=CatStr(lname,"/");
			if (sname) lname = CatStr( lname, BasenameFromPath(sname), ".log" );
			else	   lname = CatStr( lname, "zasm.log" );
			closedir(dir);
		}
	}

// mangle targetfile path
	if (dname)
	{
		DIR* dir = opendir(dname);
		if (dir)
		{
			if (LastChar(dname)!='/') dname=CatStr(dname,"/");
			if (sname) dname = CatStr( dname, BasenameFromPath(sname), ".$" );
			else	   dname = CatStr( dname, "zasm.$" );
			closedir(dir);
		}
	}

// doit:
	sname=NewCopy(sname);
	dname=NewCopy(dname);
	lname=NewCopy(lname);

	AssZ80 ass;
	ass.AssembleFile( sname,dname,lname, f1,f2,v,w,style );

	delete[] sname;
	delete[] dname;
	delete[] lname;

	return ass.Errors();
}


/* ---- program entry ---------------------------
*/
int main( int argc, cstr argv[] )
{
#if XXLOG || XXXSAFE
	printf("argc = %i\n", argc);
	for (int i=0;i<argc;i++) printf("  [%s]\n",argv[i]);
#endif

// options:
	bool list1=0;		// listing in pass 1
	bool list2=0;		// listing in pass 2
	bool listv=0;		// object code included in listing
	bool listw=0;		// label listing appended to listing
	char style=' ';		// ' '/'b'/'x' == default/binary/intel hex

// files/paths as given in argv[]:
	cstr sourcefile = NULL;
	cstr targetfile = NULL;
	cstr listfile   = NULL;

/*	Schleife:
	Alle Optionen, listfile und targetfile suchen.
	Alle erkannten Parameter werden aus argv[] entfernt (NULL).
	Danach sind alle Parameter!=NULL sourcefiles!
*/
	for (int i=1;i<argc;i++)
	{
		cstr s = argv[i];
		if (!s||s[0]!='-') continue;		// skip non-options
		argv[i]=NULL;						// optionstring aus argumentliste entfernen

		for (uint j=1;j<strlen(s);j++)
		{
			switch(s[j])
			{
			case '1': list1=1;	continue;
			case '2': list2=1;	continue;
			case 'v': listv=1;	continue;
			case 'w': listw=1;	continue;
			case 'x': style='x';continue;
			case 'b': style='b';continue;

			case 'i':
				if (++i>=argc) goto h;
				continue;

			case 'o':
				if (++i>=argc||targetfile) goto h;
				targetfile = argv[i]; argv[i]=NULL;
				continue;

			case 'l':
				if (++i>=argc||listfile) goto h;
				listfile = argv[i]; argv[i]=NULL;
				continue;

			default:
			h:	ShowHelp(stderr);
				return 1;
			}
		}
	}

// Logikcheck für Listing:

	if( (listfile||listv||listw) && !(list1||list2) ) list2=1;

// Schleife über alle Sourcefiles:

	int errors=0;
	int scnt=0;
	for( int i=1; !errors; i++ )
	{
		if (i>=argc)
		{	// ein zusätzlicher lauf...
			if (scnt) break;	// es wurden Sourcefiles angegeben und bearbeitet.
			// else: gar kein Sourcefile angegeben => 1x mit sourcefile==NULL <=> stdin:
			sourcefile=NULL;
		}
		else
		{
			sourcefile = argv[i];
			if( !sourcefile||!*sourcefile ) continue;
		}
		scnt++;
		errors += Assemble( sourcefile, targetfile, listfile, list1, list2, listv, listw, style );
	}

// errors ?

	if (errors)
	{
		fprintf( stderr, "  zasm: (aborted)\n" );
	}

	return errors;		// 0 == ok
}












