/*	Copyright  (c)	Günter Woigk 1994 - 2007
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.

	2002-01-20 kio	port to unix started
	2006-09-08 kio	adding more IX/IY illegals
*/


#define	LOG 	0
#define	SAFE	3

#include	"config.h"
#include	"AssZ80.h"
#include	"Z80/Z80opcodes.h"
#include	"targetfiles.h"
INIT_MSG


static char sna_dflt[] = {	0x3f,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,1,7 };
static char z80_dflt[] = {	0,0,0,0,0,0,0,0,0,0,0,0,0x3f,0,7<<1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1+(1<<6),
							0,23,0,0,0,0,0,7,0,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
							0,0,0,0,0,0,-1,-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
							0	};


/* ==========================================================
				z80 assembler specific methods
========================================================== */


/* ----	store XY CB dis opcode -------------------------------
*/
void AssZ80::store_XYCB_op ( int pfx, int n, int dis )
{
	if (pass2 && dis!=(char)dis) SetError("displacement out of range");
	store_4(pfx,PFX_CB,dis,n);
}

#define	store_IXCB_opcode(OP,DIS)	store_XYCB_op(PFX_IX,OP,DIS)
#define	store_IYCB_opcode(OP,DIS)	store_XYCB_op(PFX_IY,OP,DIS)


/* ----	store pfx + opcode ----------------------------------
*/
#define	store_ED_opcode(OP)	store_2(PFX_ED,OP)
#define	store_CB_opcode(OP)	store_2(PFX_CB,OP)
#define	store_IX_opcode(OP)	store_2(PFX_IX,OP)
#define	store_IY_opcode(OP)	store_2(PFX_IY,OP)


/* ----	store XY opcode dis ---------------------------------
*/
void AssZ80::store_XY_byte_op ( int pfx, int n, int dis )
{
	if (pass2 && dis!=(char)dis) SetError("displacement out of range");
	store_3(pfx,n,dis);
}

#define	store_IX_byte_opcode(OP,DIS)	store_XY_byte_op(PFX_IX,OP,DIS)
#define	store_IY_byte_opcode(OP,DIS)	store_XY_byte_op(PFX_IY,OP,DIS)


/* ---- expect and evaluate condition -----------------------
*/
enum   { NZ,Z,NC,C,PO,PE,P,M };

int AssZ80::Condition ( cstr w )
{
	switch(StrLen(w))
	{
	case 1:
		switch(peek_1(w))
		{
		case 'z': return Z;
		case 'c': return C;
		case 'p': return P;
		case 'm': return M;
		}
		break;
	case 2:
		switch(peek_2(w))
		{
		case '  nz':	return NZ;
		case '  nc':	return NC;
		case '  po':	return PO;
		case '  pe':	return PE;
		}
		break;
	}
	SetError ( "illegal condition" );
	return -1;
}


/* ----	test for and evaluate register -------------------------
*/
enum
{	RB,RC,RD,RE,RH,RL, OPEN,RA,
	XH,XL,YH,YL,						// 2006-09-08 kio: for ill. IX/IY opcodes
	RF, RI, RR,   BC,DE,HL,SP,
	IX,IY,AF,PC,  AF2,BC2,DE2,HL2
};

int AssZ80::Register ( cstr w )
{
	switch(StrLen(w))
	{
	case 1:
		switch(peek_1(w))
		{
		case 'a':	return RA;
		case 'f':	return RF;
		case 'b':	return RB;
		case 'c':	return RC;
		case 'd':	return RD;
		case 'e':	return RE;
		case 'h':	return RH;
		case 'l':	return RL;
		case '(':	return OPEN;
		case 'i':	return RI;
		case 'r':	return RR;
		}
		break;
	case 2:
		switch(peek_2(w))
		{
		case '  af':	return AF;
		case '  bc':	return BC;
		case '  de':	return DE;
		case '  hl':	return HL;
		case '  ix':	return IX;
		case '  iy':	return IY;
		case '  sp':	return SP;
		case '  pc':	return PC;
		case '  xh':	return XH;		// 2006-09-08 kio: for ill. IX/IY opcodes
		case '  xl':	return XL;		// 2006-09-08 kio: for ill. IX/IY opcodes
		case '  yh':	return YH;		// 2006-09-08 kio: for ill. IX/IY opcodes
		case '  yl':	return YL;		// 2006-09-08 kio: for ill. IX/IY opcodes
		}
		break;
	}
	return -1;
}



/* ---- assemble z80 instruction ---------------------------
		parameter: lowercase opcode menmo w already read from source
*/
bool AssZ80::AssInstr ( cstr w )
{	int i,j,n=0,m=0;
	cstr s;

	switch (StrLen(w))		// handle opcode / pseudo instruction
	{
// ---- 2-char mnemos ----
	case 2:
		switch(peek_2(w))
		{
//		default:		LogLine("peek_2 = %8x",peek_2(w)); break;
		
		case '  ei':	store_opcode(EI); goto x;
		case '  di':	store_opcode(DI); goto x;

		case '  jp':
			if (TestChar('('))						// jp (hl), (ix), (iy)
			{	switch(Register(NextWord()))
				{	case HL:	store_opcode   (JP_HL); break;
					case IX:	store_IX_opcode(JP_HL); break;
					case IY:	store_IY_opcode(JP_HL); break;
					default:	goto ill_reg;
				}
				ExpectClose();
				goto x;
			}
			s=srcPtr; w=NextWord();
			if (TestComma())	i = JP_NZ + 8*Condition(w); 	// conditional jump
			else			    srcPtr=s, i = JP;				// unconditional jump
			n = Value(pAny);
			store_opcode(i);
			store_word(n);
			goto x;

		case '  im':
		{	static char im[]={IM_0,IM_1,IM_2};
			n=Value(pAny); if (n>=0&&n<=2) store_ED_opcode(im[n]); else SetError ( "illegal interrupt mode" );
			goto x;
		}

		case '  in':
			n=Register(NextWord()); if (n==OPEN) goto ill_dest;
			ExpectComma();
			s=srcPtr;
			Expect('(');
			m = Register(NextWord());
			ExpectClose();
			if (m==RC)
			{	if (n==RF) n=OPEN;
				if (n>=RB&&n<=RA) store_ED_opcode(IN_B_xC+8*n); else { srcPtr=s; goto ill_dest; }
				goto x;
			}
			srcPtr=s;
			if (n!=RA) goto ill_dest;
			store_opcode(INA);
			store_byte(Value(pAny));
			goto x;

		case '  rl':
			i = RL_B;
			goto rr;

		case '  rr':
			i = RR_B;
		rr:	n = Register(NextWord());
			if (n<RB||n>RA) goto ill_target;
			if (n==OPEN) 	// hl/ix/iy register indirect ?
			{	switch(Register(NextWord()))
				{
				case IX:	store_IXCB_opcode(i+OPEN,Value(pAny)); break;
				case IY:	store_IYCB_opcode(i+OPEN,Value(pAny)); break;
				case HL:	store_CB_opcode  (i+OPEN);             break;
				default:	goto ill_reg;
				}
				ExpectClose(); goto x;
			}
			store_CB_opcode(i+n);
			goto x;

		case '  ex':
			i = Register(NextWord());
			if (i==OPEN) { if (Register(NextWord())!=SP) goto ill_reg; ExpectClose(); }
			ExpectComma();
			n = Register(NextWord());
			if (n==OPEN) { if (Register(NextWord())!=SP) goto ill_reg; ExpectClose(); }
			if (n==AF) Expect('\'');
			if (i==DE) { i=n; n=DE; }
			if (i==OPEN) { i=n; n=OPEN; }
			if (i==AF&&n==AF) store_opcode(EX_AF_AF); 
			else if (i==HL&&n==DE) store_opcode(EX_DE_HL); 
			else if (i==HL&&n==OPEN) store_opcode(EX_HL_xSP); 
	//		else if (i==IX&&n==DE) store_IX_opcode(EX_DE_HL); 		// ex de,hl always changes only de and hl. 2006-09-13 kio
			else if (i==IX&&n==OPEN) store_IX_opcode(EX_HL_xSP); 	// valid illegal. 2006-09-13 kio
	//		else if (i==IY&&n==DE) store_IY_opcode(EX_DE_HL); 		// ex de,hl always changes only de and hl. 2006-09-13 kio
			else if (i==IY&&n==OPEN) store_IY_opcode(EX_HL_xSP);	// valid illegal. 2006-09-13 kio
			else goto ill_reg;
			goto x;

		case '  jr':
			s=srcPtr;
			n=JR;
			w=NextWord();
			if (TestChar(','))
			{	n=Condition(w);
				if (n>C) goto ill_cond;
				n=JR_NZ+n*8;
			}
			else	srcPtr=s;
			store_opcode(n);
			store_offset(Value(pAny)-(org + (destPtr+1-destBu)));
			goto x;

		case '  cp':
			i=CP_B;
		cp:	s=srcPtr;
			n=Register(NextWord());
			if (TestComma())
			{	if (n!=RA) goto ill_target;
				s=srcPtr;
				n=Register(NextWord());
			}
			switch(n)
			{
			case -1:		// immediate value
			{	srcPtr=s;
				store_opcode(i+CP_N-CP_B);
				store_byte(Value(pAny));
				goto x;
			}
			case OPEN:		// hl/ix/iy register indirect ?
			{	switch(Register(NextWord()))
				{
				case IX: store_IX_byte_opcode(i+n,PeekChar()==')'?0:Value(pAny)); break; // 2007-09-25 kio: (IX) w/o offset
				case IY: store_IY_byte_opcode(i+n,PeekChar()==')'?0:Value(pAny)); break; // 2007-09-25 kio: (IY) w/o offset
				case HL: store_opcode(i+n); break;
				default: goto ill_reg;
				}
				ExpectClose(); goto x;
			}
			case XL:										// 2006-09-08 kio: for ill. IX/IY opcodes
			case XH:										// 2006-09-08 kio: for ill. IX/IY opcodes
				store_IX_opcode(i+n+(RL-XL)); goto x;		// 2006-09-08 kio: for ill. IX/IY opcodes
			case YL:										// 2006-09-08 kio: for ill. IX/IY opcodes
			case YH:										// 2006-09-08 kio: for ill. IX/IY opcodes
				store_IY_opcode(i+n+(RL-YL)); goto x;		// 2006-09-08 kio: for ill. IX/IY opcodes
			default:
				if (n>RA) goto ill_source;				
				store_opcode(i+n); goto x;
			}

		case '  or':
			i = OR_B; goto cp;

		case '  ld':
			// target:	i = register;  if no register: -1;  if indirect: 100 added
			// 			n = value (100-1) or offset (100+IX/100+IY)
			// source:	j = register;  if no register: -1;  if indirect: 100 added
			// 			m = value (100-1/-1) or offset (100+IX/100+IY)
			i = Register ( NextWord() );	if (i<0) goto ill_dest;
			if (i==OPEN)
			{	s=srcPtr;
				i = Register ( NextWord() );
				if (i>=0)	// (reg)
				{	if (i==IX||i==IY) n = PeekChar()==')'?0:Value(pAny);	// 2007-09-25 kio: added (IX) and (IY) w/o offset
				}
				else		// (nn)
				{	srcPtr=s; n=Value(pAny);
				};
				i+=100;
				ExpectClose();
			};
			ExpectComma();

			s=srcPtr;
			j = Register ( NextWord() );
			if (j<0) 		// nn
			{	srcPtr=s; m=Value(pAny);
			}
			else if (j==OPEN)
			{	s=srcPtr;
				j = Register ( NextWord() );
				if (j>=0)	// (reg)
				{	if (j==IX||j==IY) m = PeekChar()==')'?0:Value(pAny);	// 2007-09-25 kio: added (IX) and (IY) w/o offset
				}
				else		// (nn)
				{	srcPtr=s; m=Value(pAny);
				};
				j+=100;
				ExpectClose();
			};

			if (i>=99&&j>=99) { SetError ( "no z80 instruction can access memory twice!" ); goto x; }

			if ( (i<BC||i>=99/*>IY*/) && (j<BC||j>=99/*>IY*/) )	// byte operations		
			{													// korr.: nach IY noch Doppelregister bis HL2 (kio)
				if (i==100+HL) i=OPEN;
				if (j==100+HL) j=OPEN;

				if (i>=RB&&i<=RA)
				{
					switch(j)
					{
					case -1:	 store_opcode(LD_B_N+i*8); store_byte(m); goto x;
					case 100+IX: store_IX_byte_opcode(LD_B_xHL+i*8,m); goto x;
					case 100+IY: store_IY_byte_opcode(LD_B_xHL+i*8,m); goto x;
					case XH:													// 2006-09-08 kio: for ill. IX/IY opcodes
					case XL:	if (i==RH||i==RL||i==OPEN) break;				// 2006-09-08 kio: for ill. IX/IY opcodes
								store_IX_opcode(LD_B_B+i*8+(j-XH+RH)); goto x;	// 2006-09-08 kio: for ill. IX/IY opcodes
					case YH:													// 2006-09-08 kio: for ill. IX/IY opcodes
					case YL:	if (i==RH||i==RL||i==OPEN) break;				// 2006-09-08 kio: for ill. IX/IY opcodes
								store_IY_opcode(LD_B_B+i*8+(j-YH+RH)); goto x;	// 2006-09-08 kio: for ill. IX/IY opcodes
					case RB:
					case RC:
					case RD:
					case RE:
					case RH:
					case RL:
					case OPEN:
					case RA:	store_opcode(LD_B_B+i*8+j); goto x;
					}
				}
				
				if (i>=XH&&i<=YL)		// 2006-09-08 kio: for ill. IX/IY opcodes
				{
					if (i<=XL)	// XH or XL
					{
						switch(j)
						{
						case -1:	store_IX_opcode(LD_B_N+(i-XH+RH)*8); store_byte(m); goto x;
						case XH:
						case XL:	store_IX_opcode(LD_B_B+(i-XH+RH)*8+(j-XH+RH)); goto x;
						case RB:
						case RC:
						case RD:
						case RE:
						case RA:	store_IX_opcode(LD_B_B+(i-XH+RH)*8+j); goto x;
						}
					}					
					else		// YH or YL
					{
						switch(j)
						{
						case -1:	store_IY_opcode(LD_B_N+(i-YH+RH)*8); store_byte(m); goto x;
						case YH:															
						case YL:	store_IY_opcode(LD_B_B+(i-YH+RH)*8+(j-YH+RH)); goto x;
						case RB:
						case RC:
						case RD:
						case RE:
						case RA:	store_IY_opcode(LD_B_B+(i-YH+RH)*8+j); goto x;
						}
					}
				}

				if (i==RA)
				{	switch (j)
					{
					case 100-1:		store_opcode(LD_A_xNN); store_word(m); goto x;
					case 100+BC:	store_opcode(LD_A_xBC); goto x;
					case 100+DE:	store_opcode(LD_A_xDE); goto x;
					case RI:		store_ED_opcode(LD_A_I); goto x;
					case RR:		store_ED_opcode(LD_A_R); goto x;
					}
				}

				if (j==RA)
				{	switch (i)
					{
					case 100-1:		store_opcode(LD_xNN_A); store_word(n); goto x;
					case 100+BC:	store_opcode(LD_xBC_A); goto x;
					case 100+DE:	store_opcode(LD_xDE_A); goto x;
					case RI:		store_ED_opcode(LD_I_A); goto x;
					case RR:		store_ED_opcode(LD_R_A); goto x;
					}
				}

				if (i==100+IX)
				{
					if (j==-1)				// ld (ix+dis),nn
					{	store_IX_byte_opcode(LD_xHL_N,n); store_byte(m); goto x;
					}
					else if (j>=RB&&j<=RA)	// ld (ix+dis),reg
					{	store_IX_byte_opcode(LD_xHL_B+j,n); goto x;
					}
				}

				if (i==100+IY)
				{
					if (j==-1)				// ld (ix+dis),nn
					{	store_IY_byte_opcode(LD_xHL_N,n); store_byte(m); goto x;
					}
					else if (j>=RB&&j<=RA)	// ld (ix+dis),reg
					{	store_IY_byte_opcode(LD_xHL_B+j,n); goto x;
					}
				}
			}
			else					// word operations
			{
				if (i==100+HL)		// Goodie: ld (hl),dreg
				{
					if(j==BC) 
					{
						store_opcode(LD_xHL_C); store_opcode(INC_HL);
						store_opcode(LD_xHL_B); store_opcode(DEC_HL);
						goto x;
					}
					if(j==DE) 
					{
						store_opcode(LD_xHL_E); store_opcode(INC_HL);
						store_opcode(LD_xHL_D); store_opcode(DEC_HL);
						goto x;
					}
				}

				if (j==100+HL)		// Goodie: ld dreg,(hl)
				{
					if(i==BC) 
					{
						store_opcode(LD_C_xHL); store_opcode(INC_HL);
						store_opcode(LD_B_xHL); store_opcode(DEC_HL);
						goto x;
					}
					if(i==DE) 
					{
						store_opcode(LD_E_xHL); store_opcode(INC_HL);
						store_opcode(LD_D_xHL); store_opcode(DEC_HL);
						goto x;
					}
				}
				
				if (i>=BC&&i<SP&&j>=BC&&j<SP)		// goodie: ld dreg,dreg
				{	n = (i-BC)*8+(j-BC);
					store_opcode(LD_B_B+n*2);		// high byte
					store_opcode(LD_C_C+n*2);		// low byte
					goto x;
				}

				if (i==IX) { i=HL; store_opcode(PFX_IX); }	else
				if (i==IY) { i=HL; store_opcode(PFX_IY); }	else
				if (j==IX) { j=HL; store_opcode(PFX_IX); }	else
				if (j==IY) { j=HL; store_opcode(PFX_IY); }

				if (i==100-1)		// (NN)
				{	switch(j)
					{
					case HL:	store_opcode(LD_xNN_HL); break;
					case BC:	store_ED_opcode(LD_xNN_BC); break;
					case DE:	store_ED_opcode(LD_xNN_DE); break;
					case SP:	store_ED_opcode(LD_xNN_SP); break;
					default:	goto ill_source;
					}
					store_word(n);
					goto x;
				}

				if (j==100-1)		// (NN)
				{	switch(i)
					{
					case HL:	store_opcode(LD_HL_xNN); break;
					case BC:	store_ED_opcode(LD_BC_xNN); break;
					case DE:	store_ED_opcode(LD_DE_xNN); break;
					case SP:	store_ED_opcode(LD_SP_xNN); break;
					default:	goto ill_source;
					}
					store_word(m);
					goto x;
				}

				if (j==-1)			// NN
				{	switch(i)
					{
					case HL:	store_opcode(LD_HL_NN); break;
					case BC:	store_opcode(LD_BC_NN); break;
					case DE:	store_opcode(LD_DE_NN); break;
					case SP:	store_opcode(LD_SP_NN); break;
					default:	goto ill_source;
					}
					store_word(m);
					goto x;
				}

				if (i==SP&&j==HL)	{ store_opcode(LD_SP_HL); goto x; }
			}
			SetError ( "parameter error" );
			goto x;
		}

		break;


// ---- 3 char mnemos ----
	case 3:
		switch (peek_3(w))
		{
		case ' scf':	store_opcode(SCF); goto x;
		case ' ccf':	store_opcode(CCF); goto x;
		case ' cpl':	store_opcode(CPL); goto x;
		case ' daa':	store_opcode(DAA); goto x;
		case ' rra':	store_opcode(RRA); goto x;
		case ' rla':	store_opcode(RLA); goto x;
		case ' nop':	store_opcode(NOP); goto x;
		case ' neg':	store_ED_opcode(NEG); goto x;
		case ' exx':	store_opcode(EXX); goto x;
		case ' rrd':	store_ED_opcode(RRD); goto x;
		case ' rld':	store_ED_opcode(RLD); goto x;
		case ' ldi':	store_ED_opcode(LDI); goto x;
		case ' cpi':	store_ED_opcode(CPI); goto x;
		case ' ini':	store_ED_opcode(INI); goto x;
		case ' ldd':	store_ED_opcode(LDD); goto x;
		case ' cpd':	store_ED_opcode(CPD); goto x;
		case ' ind':	store_ED_opcode(IND); goto x;
		case ' and':	i = AND_B; goto cp;
		case ' xor':	i = XOR_B; goto cp;
		case ' sub':	i = SUB_B; goto cp;
		case ' rlc':	i = RLC_B; goto rr;
		case ' rrc':	i = RRC_B; goto rr;
		case ' sla':	i = SLA_B; goto rr;
		case ' sra':	i = SRA_B; goto rr;
		case ' sll':	i = SLL_B; goto rr;
		case ' srl':	i = SRL_B; goto rr;
		case ' res':	i = RES0_B; goto bit;
		case ' set':	i = SET0_B; goto bit;
		case ' dec':	i = 8; goto inc;

		case ' rst':
			n = Value(pAny);
			if (n%8==0) n>>=3;
			if (n>=0&&n<=7) store_opcode(RST00+n*8); else SetError ( "illegal vector" );
			goto x;

		case ' add':
			s=srcPtr; n=Register(NextWord()); if(n<=YL/*illegals added 2006-09-08 kio*/) { srcPtr=s; i = ADD_B; goto cp; }
			if (n!=HL&&n!=IX&&n!=IY) goto ill_reg;
			ExpectComma(); 					// hl/ix/iy
			if (n==IX) store_opcode(PFX_IX);
			if (n==IY) store_opcode(PFX_IY);
			i = Register(NextWord());
			switch(i)
			{
			case BC:	store_opcode(ADD_HL_BC); goto x;
			case DE:	store_opcode(ADD_HL_DE); goto x;
			case SP:	store_opcode(ADD_HL_SP); goto x;
			case HL:
			case IX:
			case IY:	store_opcode(ADD_HL_HL); if (i==n) goto x;
			}
			goto ill_reg;

		case ' sbc':
			s=srcPtr; n=Register(NextWord()); if(n<=YL/*illegals added 2006-09-08 kio*/) { srcPtr=s; i = SBC_B; goto cp; }
			i=SBC_HL_BC;
	sbc:	if (n!=HL) goto ill_reg;
			ExpectComma();
			switch ( Register(NextWord()) )
			{
			case BC:	store_ED_opcode(i   ); goto x;
			case DE:	store_ED_opcode(i+16); goto x;
			case HL:	store_ED_opcode(i+32); goto x;
			case SP:	store_ED_opcode(i+48); goto x;
			}
			goto ill_reg;

		case ' adc':
			s=srcPtr; n=Register(NextWord()); if(n<=YL/*illegals added 2006-09-08 kio*/) { srcPtr=s; i = ADC_B; goto cp; }
			i=ADC_HL_BC; goto sbc;

		case ' bit':
			i = BIT0_B;
	bit:	n=Value(pAny); if (n<0||n>7) { SetError("illegal bit number"); goto x; }
			i += n*8;
			ExpectComma();
			n=Register(NextWord());
			if (n<RB||n>RA) goto ill_target;
			if (n!=OPEN) { store_CB_opcode(i+n); goto x; }
			switch(Register(NextWord()))
			{
			case HL: store_CB_opcode(i+n); break;
			case IX: store_IXCB_opcode(i+n,PeekChar()==')'?0:Value(pAny)); break; // 2007-09-25 kio:
			case IY: store_IYCB_opcode(i+n,PeekChar()==')'?0:Value(pAny)); break; // added (IX) w/o offset
			default: goto ill_reg;
			}
			ExpectClose(); 
			goto x;

		case ' inc':
			i = 0;
	inc:	n=Register(NextWord());
			if (n>=BC)
			{	if (i) i=DEC_BC-INC_BC;
				switch(n)
				{
				case BC:	store_opcode(INC_BC+i); goto x;
				case DE:	store_opcode(INC_DE+i); goto x;
				case HL:	store_opcode(INC_HL+i); goto x;
				case SP:	store_opcode(INC_SP+i); goto x;
				case IX:	store_IX_opcode(INC_HL+i); goto x;
				case IY:	store_IY_opcode(INC_HL+i); goto x;
				default:	goto ill_reg;	// added: zasm failed to detect some ill. condidions	2006-09-17 kio 
				}
			}
			if (n>=XH)						// inc/dec XH..YL added		2006-09-17 kio 
			{
				if (i) i=DEC_H-INC_H;	// 1
				switch(n)
				{
				case XH:	store_IX_opcode(INC_H+i); goto x; 
				case XL:	store_IX_opcode(INC_L+i); goto x; 
				case YH:	store_IY_opcode(INC_H+i); goto x; 
				case YL:	store_IY_opcode(INC_L+i); goto x; 
				default:	goto ill_reg;
				}
			}
			if (i) i=DEC_B-INC_B;	// 1
			if (n!=OPEN) 
			{ 
				store_opcode(INC_B+i+n*8); goto x; 
			}
			switch(Register(NextWord()))
			{
			case HL:	store_opcode(INC_xHL+i); break;
			case IX:	store_IX_byte_opcode(INC_xHL+i,PeekChar()==')'?0:Value(pAny)); break;	// 2007-09-25 kio:
			case IY:	store_IY_byte_opcode(INC_xHL+i,PeekChar()==')'?0:Value(pAny)); break;	// added (IX) w/o offset
			default:	goto ill_reg;
			}
			ExpectClose();
			goto x;

		case ' out':
			s=srcPtr;
			Expect('(');
			n=Register(NextWord());
			if (n<0)
			{	srcPtr=s; n=Value(pAny);
				ExpectComma();
				if (Register(NextWord())!=RA) goto ill_reg;
				store_opcode(OUTA);
				store_byte(n);
				goto x;
			}
			if (n!=RC&&n!=BC) goto ill_reg;
			ExpectClose();
			ExpectComma();
			s=srcPtr;
			n = Register(NextWord());
			if (n==OPEN) n=999;
			if (n<0) { srcPtr=s; if (Value(pAny)!=0) goto ill_reg; else n=OPEN; }
			if (n<=RA) { store_ED_opcode(OUT_xC_B+n*8); goto x; }
			goto ill_reg;

		case ' ret':
			if (TestEol()) { store_opcode(RET); goto x; }
			store_opcode ( RET_NZ+Condition(NextWord())*8 );
			goto x;

		case ' pop':
			i = 0;
	pop:	switch ( Register(NextWord()) )
			{
			case BC:	store_opcode(POP_BC+i); goto x;
			case DE:	store_opcode(POP_DE+i); goto x;
			case HL:	store_opcode(POP_HL+i); goto x;
			case AF:	store_opcode(POP_AF+i); goto x;
			case IX:	store_IX_opcode(POP_HL+i); goto x;
			case IY:	store_IY_opcode(POP_HL+i); goto x;
			}
			goto ill_reg;

		}
		break;

// ---- 4 char mnemos ----
	case 4:
		switch (peek_4(w))
		{
		case 'rlca':	store_opcode(RLCA); goto x;
		case 'rrca':	store_opcode(RRCA); goto x;
		case 'halt':	store_opcode(HALT); goto x;
		case 'outi':	store_ED_opcode(OUTI); goto x;
		case 'outd':	store_ED_opcode(OUTD); goto x;
		case 'ldir':	store_ED_opcode(LDIR); goto x;
		case 'cpir':	store_ED_opcode(CPIR); goto x;
		case 'inir':	store_ED_opcode(INIR); goto x;
		case 'otir':	store_ED_opcode(OTIR); goto x;
		case 'lddr':	store_ED_opcode(LDDR); goto x;
		case 'cpdr':	store_ED_opcode(CPDR); goto x;
		case 'indr':	store_ED_opcode(INDR); goto x;
		case 'otdr':	store_ED_opcode(OTDR); goto x;
		case 'reti':	store_ED_opcode(RETI); goto x;
		case 'retn':	store_ED_opcode(RETN); goto x;
		case 'push':	i = PUSH_BC-POP_BC; goto pop;

		case 'call':
			s=srcPtr; w=NextWord();
			if (TestComma())	i = CALL_NZ + 8*Condition(w); 	// conditional jump
			else			    i = CALL, srcPtr=s; 			// unconditional jump
			n=Value(pAny);
			store_opcode(i);
			store_word(n);
			goto x;

		case 'djnz':
			store_opcode(DJNZ);
			store_offset(Value(pAny)-(org + (destPtr+1-destBu)));
			goto x;
		}
		break;
	}

// try inherited general Ass method:
	return Ass::AssInstr(w);

// generate error
ill_reg:		SetError("illegal register"); 		goto x;
ill_cond:		SetError("illegal condition");		goto x;
ill_target:		SetError("illegal target");			goto x;
ill_source:		SetError("illegal source");			goto x;
ill_dest:		SetError("illegal destination");	goto x;

x:	return 1;	// instruction handled
}


/* ==============================================================
		handle TAP directives 
============================================================== */

void AssZ80::WriteTapeBlock()
{
	if (!destBu) return;

// store length
	destBu[0] = (destPtr-(destBu+2)+1);
	destBu[1] = (destPtr-(destBu+2)+1)>>8;

// calc checksum
	char crc = 0;
	if(pass2) for( char*p=destBu+2; p<destPtr; p++ ) { crc^=*p; }
	store_byte(crc);

	TruncateSegment(yes);		// TAP: all segments are truncated
	WriteSegment();
}

void AssZ80::HandleCodeTap ( )
{
 	WriteTapeBlock();

// #code start,len,sync

	int n = Value(pAny|pForce);	ExpectComma(); if (n!=(short)n&&n!=(ushort)n) SetError("illegal origin",fatal);
	int m = Value(pAny|pForce); ExpectComma(); if (m<=0||m>=0x10000) SetError("illegal length",fatal);
	int s = Value(pAny); if (s<-128||s>255) SetError("sync byte out of range",fatal);  if (error) return;

//			defw	len
// 			defb	sync
//	org:	defb	<object code>
//			defb	crc

	NewDestBu(m+4,0); if (error) return;	// preset with $00 for defs instruction
	org = n-3;
	store_word(0);				// length (not yet known: sized to fit)
	store_byte(s);				// store the sync byte
}

void AssZ80::HandleEndTap()
{
	WriteTapeBlock();
	Ass::HandleEnd();
}


/* ==============================================================
		handle .80 / .o file directives  (tape for ZX80)
============================================================== */

void AssZ80::HandleCodeZX80 ( )
{
	if(destBu) { SetError(".80 / .o files cannot have multiple segments",fatal); return; }
	

//	#code $4000, len
	int n = Value(pAny|pForce);	ExpectComma(); if (n!=0x4000) SetError("origin must be $4000",fatal);
	int m = Value(pAny|pForce); if (m<=0x0028||m>=0x0c000) SetError("illegal length",fatal); if(error) return;

	NewDestBu(m,0); if (error) return;	// preset with $00 for defs instruction
	org = 0x4000;
}

void AssZ80::HandleEndZX80()
{
	TruncateSegment(yes);
	Poke2Z( destBu+0x000A, 0x4000+destPtr-destBu );		// E_LINE  (end of input line == end of used ram)
	WriteSegment();
	Ass::HandleEnd();
}


/* ==============================================================
		handle .81 / .p file directives  (tape for ZX80)
============================================================== */

void AssZ80::HandleCodeZX81 ( )
{
	if(destBu) { SetError(".81 / .p files cannot have multiple segments",fatal); return; }
	

//	#code $4009, len
	int n = Value(pAny|pForce);	ExpectComma(); if (n!=0x4009) SetError("origin must be $4009",fatal);
	int m = Value(pAny|pForce); if (m<=0x3c-0x09||m>=0x0c000-0x09) SetError("illegal length",fatal); if(error) return;

	NewDestBu(m,0); if (error) return;						// preset with $00 for defs instruction
	org = 0x4009;
}

void AssZ80::HandleEndZX81()
{
	TruncateSegment(yes);
	Poke2Z( destBu+0x14-0x09, 0x4009+destPtr-destBu );		// E_LINE  (end of input line == end of used ram)
	WriteSegment();
	Ass::HandleEnd();
}


/* ==============================================================
		handle SNA directives
============================================================== */

void AssZ80::HandleHeadSna ( )
{
	if (destBu)  { SetError("#head segment already defined"); return; }

	int n = Value(pAny|pForce); if (error) return;
	if (n!=27) { SetError("#head segment size must be 27 for sna files"); return; }

	NewDestBu(n,0); if (error) return;

	org = 0;
	memcpy( destBu, sna_dflt, n );
	head = true;	// flag: #head segment in progress
}


void AssZ80::HandleCodeSna ( )
{
/*
	***TODO*** REVIEW: multiple #code segments
*/
	if (!destBu) { SetError("#head segment not yet defined"); return; }
	if (!head)   { SetError("multiple #code segments are currently not supported for sna files"); return; }

	// write #head segment
	TruncateSegment(no);		// #head segment never truncated
	WriteSegment();
	head = false;				// flag: no #head segment => #code segment in progress

	int n = Value(pAny|pForce);	ExpectComma(); if (n!=0x4000) SetError("origin must be $4000 for sna files");
	int m = Value(pAny|pForce); if (m!=0x4000 && m!=0xC000) SetError("length must be $4000 or $C000 for sna files");

	NewDestBu(m,0); if (error) return;

	org      = n;
	destPtr0 =
	destPtr  = destBu;
	destEnd  = destBu+m;
}


void AssZ80::HandleEndSna()
{
	if (!destBu||head) { SetError("no #code segment found"); return; }

	destPtr = destEnd;	// don't truncate
	Ass::HandleEnd();
}


/* ==============================================================
		handle Z80 directives
============================================================== */

void AssZ80::HandleHeadZ80 ( )
{
	XXXTRAP(target!=' z80');				
	SetError("not yet implemented");		// •••TODO•••

	if (destBu)  { SetError("multiple #head segments"); return; }

	uint n = Value(pAny|pForce); if (error) return;
	if (n<z80v2len||n>255+2+z80v1len) { SetError(".z80: illegal size"); return; }

	NewDestBu(n,0); if (error) return;
	org = 0;
	memcpy(destBu,z80_dflt,MIN(n,sizeof(z80_dflt)));
	((z80head*)destBu)->h2lenl = n -(z80v1len+2);
	head = true;
}

void AssZ80::HandleCodeZ80 ( )
{
	XXXTRAP(target!=' z80');				
	SetError("not yet implemented");		// •••TODO•••
}

void AssZ80::HandlePageZ80()
{
	XXXTRAP(target!=' z80');				
	int n = Value(pAny);
	SetError("not yet implemented",n);		// •••TODO•••
}

void AssZ80::HandleEndZ80()
{
	XXXTRAP(target!=' z80');				
	SetError("not yet implemented");		// •••TODO•••
}



/* ==============================================================
		AssDirect() virtual method
============================================================== */


bool AssZ80::AssDirect ( cstr w )
{
// check for condtitional assembly off:
	if (cond_off) goto y;

// #target:
	if (SameStr(w,"target"))
	{
		Ass::AssDirect(w); if (error) goto x;
		switch(target)
		{
		case 'tape':	target = ' tap'; 
		case    'o':
		case    'p':
		case '  80':	
		case '  81':	
		case ' tap':
		case ' sna':
		case ' z80': 	head=false;
		case ' bin':
		case ' rom':	goto x;
		default:		SetError("unknown #target"); goto x;
		}
	}

// #head:
	if (SameStr(w,"head"))
	{
		switch(target)
		{
		case     0 :	SetError("#head segment without #target"); goto x;
		case ' sna':	HandleHeadSna(); goto x;
		case ' z80':	HandleHeadZ80(); goto x;
		default:		SetError("#head segment not allowed for this #target"); goto x;
		}
	}

// #code:
	if (SameStr(w,"code"))
	{
		switch(target)
		{
		case ' sna':	HandleCodeSna(); goto x; 
		case ' z80':	HandleCodeZ80(); goto x; 
		case ' tap':	HandleCodeTap(); goto x; 
		case    'o':
		case '  80':	HandleCodeZX80(); goto x; 
		case    'p':
		case '  81':	HandleCodeZX81(); goto x; 
		default:		goto y;
		}
	}

// #page idx:
	if (SameStr(w,"page"))
	{
		switch(target)
		{
		case     0 :	SetError("#page segment without #target"); goto x;
		case ' z80':	HandlePageZ80(); goto x; 
		default:		SetError("#page segment not allowed for this #target"); goto x;
		}
	}

// #end:
	if (SameStr(w,"end"))
	{
		switch(target)
		{
		case ' sna':	HandleEndSna(); goto x; 
		case ' z80':	HandleEndZ80(); goto x; 
		case ' tap':	HandleEndTap(); goto x; 
		case    'o':
		case '  80':	HandleEndZX80(); goto x; 
		case    'p':
		case '  81':	HandleEndZX81(); goto x; 
		default:		goto y;
		}
	}

	/*	no recognized #directive
		=> try general Ass #directives
	*/
y:	return Ass::AssDirect(w);

	/*	recognized #directive handled
		all errors are fatal
	*/
x:	if (error) FatalError();
	return 1;
}














