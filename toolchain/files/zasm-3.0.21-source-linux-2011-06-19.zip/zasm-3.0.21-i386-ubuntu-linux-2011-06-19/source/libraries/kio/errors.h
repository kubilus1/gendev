/*	Copyright  (c)	Günter Woigk 1999 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


	error handling
	
this file provides:

	exception classes
		bad_alloc		alias for std::bad_alloc
		any_error		base class for below error classes
		file_error		"unix/file_utilities.h"	
		index_error		"kio/abort.h"		macro INDEX()
		limit_error		"kio/abort.h"		macro LIMIT()
		data_error							for data parsers, e.g. for input data from file
		

	raising, reading and clearing of errors.
	uses the global errno.
	
	cstr ErrorStr	(int errorcode)			returns error text for an OS or application defined error
	cstr ErrorStr	()						returns the user-readable text for the current error
	void SetError	(cstr custommessage)	sets an error with an arbitrary error text
	void SetError	(int errorcode)			sets an OS or application defined error
	int  GetError	()						gets the current error  ((same as errno))
	void ClearError ()						clears the current error


	extending the error code list:

	1:	simply use SetError("custommessage") to set arbitrary errors.
		disadvantage: you can't use errno to detect which error exactly happened.
	2:	define custom errors in "custom_errors.h"
	3:	use SetError(err,msg) to set errno to known error number and msg to arbitrary text.
*/



#ifndef	errors_h
#define	errors_h


#ifndef __cplusplus
	#error	C und nicht C++  !!
#endif

#ifdef __OBJC__
	// there could be some obj-c++ methods here.
#endif


// base of free range for own error numbers:
#define	EBAS	0x7400

extern int custom_error;


enum 
{
#define  EMAC(a,b)	a
#include "error_emacs.h"	// include files with EMAC(number,"message") pairs
};


// methods:
inline	int		GetError		( )									{ return errno; }
inline	bool	NoError			( )									{ return errno==ok; }

extern	cstr	ErrorStr		( int err, bool ce=0 );
inline	cstr	ErrorStr		( )									{ return ErrorStr(errno,1); }

inline	void	ClearError		( )									{ custom_error=0; errno = ok; }

inline	void	SetError		( int err )							{ if(!errno) errno = err; }
extern	void	SetError		( int err, cstr msg );
inline	void	SetError		( cstr msg )						{ SetError(customerror,msg); }

inline	void	ForceError		( int err )							{ errno = err; }
extern  void	ForceError		( int err, cstr msg );
inline  void	ForceError		( cstr msg )						{ ForceError(customerror,msg); }


// String methods:
// implemented in "serrors.cp"
// declared in "sstring.h"
#if 0
extern	void	ForceError		( int err, cString& msg );
inline	void	SetError		( int err, cString& msg )			{ if(NoError()) ForceError(e,msg); }
inline	void	ForceError		( cString& msg )					{ ForceError(-1,msg); }
inline	void	SetError		( cString& msg )					{ if(NoError()) ForceError(-1,msg); }
extern	void	AppendToError	( cString& msg );
extern	void	PrependToError	( cString& msg );

inline	String	ErrorString		( int err )							{ return ErrorStr(err); }
extern	String	ErrorString		( );
#endif




// ------------------------------------------------------------------------
//
//			exception classes
//
// ------------------------------------------------------------------------

#include <new>
extern str Using( cstr, ... );		// #include "cstrings/cstrings.h"

/*
	class std::exception			// #include <exception>
	{
		public:			exception	()			throw(){}
		virtual			~exception	()			throw();
		virtual cstr	what		() const	throw();
	};

hierarchy:
	std::exception					// #include <exception>		base class
		bad_alloc					// #include <new>			out of memory
		std::bad_typeid				// #include <typeinfo>		Falscher Objekttyp
		std::bad_cast				// #include <typeinfo>		Falscher Objekttyp bei Typumwandlung
		std::bad_exception			// #include <exception>		unexpected()
		internal_error				// #include "kio/abort.h"	ABORT, TRAP, ASSERT, IERR, TODO

		any_error;					//							base class for own errors: includes error code
			file_error;				// "unix/file_utilities.h"	
			index_error;			// "kio/abort.h"			macro INDEX()	index outside array
			limit_error;			// "kio/abort.h"			macro LIMIT()	array too large
			data_error;				//							data parsers, e.g. for input data from file

		std::logic_error			// #include <stdexcept>		theoretisch vermeidbare Laufzeitfehler
			std::invalid_argument	// #include <stdexcept>		stdc++ lib ((general function argument error))
			std::length_error		// #include <stdexcept>		stdc++ lib ((data exceeding allowed size))
			std::out_of_range		// #include <stdexcept>		stdc++ lib ((e.g. index))
			std::domain_error		// #include <stdexcept>		stdc++ lib ((domain of math. function))

		std::runtime_error			// #include <stdexcept>		fehlerhafte Daten zur Laufzeit
			std::range_error		// #include <stdexcept>		arith. Bereichsüberschreitung
			std::overflow_error		// #include <stdexcept>		arith. Überlauf
			std::underflow_error	// #include <stdexcept>		arith. Unterlauf
*/


typedef	std::bad_alloc	bad_alloc;

class internal_error : public std::exception
{
protected:
	int		err;			// OS error code
	cstr	file;			// const or tempmem 
	uint	line;
	cstr	text;			// custom error message or NULL

	cstr	filename() const throw()	{ cstr p = strrchr(file,'/'); return p?p+1:file; }
	
public:
	inline			internal_error	( cstr file, uint line )			throw();
	inline			internal_error	( cstr file, uint line, cstr text )	throw();
	inline			internal_error	( cstr file, uint line, int err )	throw();
	virtual			~internal_error	()									throw(){}
	virtual cstr	what			() const							throw();
	inline	int		error			() const							throw(){ return err; }
};

class any_error : public std::exception
{
protected:
		int		err;			// OS error code
		cstr	text;			// custom error message or NULL

public:
inline			any_error	( cstr s )					throw()		: err(customerror), text(s) {}
inline			any_error	( int err )					throw()		: err(err), text(NULL) {}
inline			any_error	( int err, cstr s )			throw()		: err(err), text(s) {}
virtual			~any_error	()							throw()		{}

inline	int		error		() const					throw()		{ return err; }
virtual	cstr	what		() const					throw()		{ return text ? text : ErrorStr(err); }
};

class data_error : public any_error
{
public:			data_error	(cstr s)				throw()	: any_error(s)		{ }
				data_error	(int err)				throw()	: any_error(err)	{ }
				data_error	(int err, cstr t)		throw()	: any_error(err,t)	{ }
virtual			~data_error	()						throw(){}
};

class file_error : public any_error
{
		cstr	file;
	
public:			file_error	(cstr s)					throw()		: any_error(s), file(NULL)		{ }
				file_error	(int err)					throw()		: any_error(err), file(NULL)	{ } 
				file_error	(int err, cstr t)			throw()		: any_error(err,t), file(NULL)	{ }
				file_error	(int err, cstr t,cstr file)	throw()		: any_error(err,t), file(file)	{ }
virtual			~file_error	()							throw(){}

virtual	cstr	what		() const					throw();
inline	cstr	filename	() const					throw()		{ return file; }	// may be NULL
};

class limit_error : public internal_error
{
	size_t	size;
	
public:
inline			limit_error	(cstr file, uint line, size_t sz)	throw();
virtual			~limit_error()									throw(){}
virtual	cstr	what		() const							throw();
};

class index_error : public internal_error
{
	long	index;
	
public:
inline			index_error	( cstr file, uint line, long idx )	throw();
virtual			~index_error()									throw(){}
virtual cstr	what		() const							throw();
};


// --------------------------------------------------------------------------
// implementations:


// internal_error:

inline internal_error::internal_error( cstr file, uint line ) throw()
: err(internalerror), file(file), line(line), text(NULL) 
{}

inline internal_error::internal_error( cstr file, uint line, cstr text ) throw()
: err(internalerror), file(file), line(line), text(text) 
{}

inline internal_error::internal_error( cstr file, uint line, int err ) throw()
: err(err), file(file), line(line), text(NULL) 
{}

inline cstr internal_error::what () const throw()
{
	return Using( "in file \"%s\" line %u: %s",filename(),(uint)line,(text?text:ErrorStr(err)) ); 
}


// file_error:

inline cstr file_error::what() const throw()
{
	cstr msg = text?text:ErrorStr(err); 
	return file ? Using("File %s: %s",file,msg) : msg; 
}


// index_error:

inline index_error::index_error ( cstr file, uint line, long idx )	throw()
: internal_error(file,line,indexerror), index(idx) 
{}

inline cstr index_error::what () const throw() 
{
	return Using("in file \"%s\" line %u: bad index: %li",filename(),(uint)line,(long)index); 
}

// limit_error:

inline limit_error::limit_error ( cstr file, uint line, size_t sz )	throw()
: internal_error(file,line,limiterror), size(sz) 
{}

inline cstr limit_error::what () const throw() 
{ 
	return Using("in file \"%s\" line %u: bad size: %zi",filename(),(uint)line,(size_t)size); 
}


#endif











