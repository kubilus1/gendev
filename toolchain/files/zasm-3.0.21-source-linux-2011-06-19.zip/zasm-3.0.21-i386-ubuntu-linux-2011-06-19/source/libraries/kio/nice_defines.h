/*	Copyright  (c)	Günter Woigk 1995 - 2009
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


	nice defines

	this file should be included from "kio.h"
	
	contains:
		basic maths
		byte sex independent and unaligned peek and poke
		count bits
	
recent changes:	
	2005-03-21		_x_()		byte sex swapper removed => use PeekX(), PokeX() etc.
	2007-07-09		Log2()		et.al. overhauled
	2008-06-04		random()	added declaration #ifndef HAVE_STDLIB_H
*/


#ifndef nice_defines_h
#define nice_defines_h


#ifndef standard_types_h
typedef	unsigned long	ulong;
typedef	unsigned short	ushort;
typedef	unsigned int 	uint;
#endif



// ----	Debugging ----------------------------------------------------------
#define	LOL				fprintf(stderr,"LOL> \"%s\" - %d\n",__FILE__,__LINE__);



// ----	Nice defines -------------------------------------------------------

#ifndef MIN
	#define MIN(a,b)	((a)<(b)?(a):(b))
#endif
#ifndef MAX
	#define MAX(a,b)	((a)>(b)?(a):(b))
#endif
#ifndef ABS
	#define ABS(a)   	((a)<0?-(a):(a))
#endif

//#define	LIMIT(A,N,E)	if (N<(A)) N=(A); else if (N<=(E)) {} else N=(E)	// [A … E]
#define	SWAP(a,b)		((a)^=(b),(b)^=(a),(a)^=(b))					
#define	SORT(a,b)		if ((a)<=(b)) {} else SWAP(a,b)
#define	SIGN(a)			(((a)>0)-((a)<0))					
#define	NELEM(feld)		(sizeof(feld)/sizeof((feld)[0]))					// UNSIGNED !!
#define	BIT(B,N)		(((N)>>(B))&1)										// get bit value at bit position B
#define	BITMASK(i,n)	((0xFFFFFFFF<<(i)) ^ (0xFFFFFFFF<<((i)+(n))))		// mask to select bits ]i+n .. i]
#define	RMASK(n)		(~(0xFFFFFFFF<<(n)))								// mask to select n bits from the right
#define LMASK(i)		(  0xFFFFFFFF<<(i) )								// mask to select all but the i bits from right



// ----	Calculate base 2 logarithm or 'position' of leftmost '1' bit -----------------
//		note: for 0x00000000 the returned value is 0 as for 0x00000001
//		note: overloaded functions for c++ below
#define LOG2NIBBLE(N)	(((N)>7)+((N)>3)+((N)>1))											/* 0 ...  3 */
#define LOG2BYTE(N)		(uint8(N) >  0x0Fu ? 4 + LOG2NIBBLE(uint8 (N)>>4 ) : LOG2NIBBLE(N))	/* 0 ...  7 */
#define LOG2SHORT(N)	(uint16(N)>0x00FFu ? 8 + LOG2BYTE  (uint16(N)>>8 ) : LOG2BYTE(N)  )	/* 0 ... 15 */
#define LOG2(N)			(uint32(N)>0xFFFFu ? 16+ LOG2SHORT (uint32(N)>>16) : LOG2SHORT(N) )	/* 0 ... 31 */



/* ----	scale conversion with proper rounding --------------------------
		limits:   oldval*newmax+oldmax/2 <= ulong_max
*/
inline ulong Scale ( ulong oldval, ulong oldmax, ulong newmax )
	{ return ( oldval*newmax+oldmax/2 ) / oldmax; }




/* ----	overloading ahead -----------------------------------------------
*/
#ifdef __cplusplus							


template<class T>		// auto-destruction pointer:
class ADP
{
	T*		p;

	ADP&	operator=	( ADP const& );	// prohibit: can't be handled.
			ADP			( ADP const& );	// prohibit: can't be handled.

public:		ADP			()			: p(NULL) {}
			ADP			( T* p )	: p(p) {}
			~ADP		()			{ delete p; }
	T*		operator->	()			{ return p; }
	T&		operator*	()			{ return *p; }
	ADP&	operator=	( T* q )	{ if(p!=q) { delete p; p=q; } return *this; }
};


template<class T>		// auto-destruct array
class ADA
{
	T*		p;
			ADA(ADA const&);			// prohibit
	ADA&	operator=(ADA const&);		// prohibit

public:		ADA			()				{p=0;}
			ADA			(T*q)			{p=q;}
			~ADA		()				{delete[]p;}
	void	operator=	(T*q)			{delete[]p;p=q;}
	T&		operator[]	(ulong i)		{return p[i];}
	T*		operator+	(ulong n)		{return p+n;}
	T*		operator-	(ulong n)		{return p-n;}
};

typedef ADA<int8>	ADi8ptr;
typedef ADA<uint8>	ADu8ptr;
//	typedef ADA<int16>	ADi16ptr;
//	typedef ADA<uint16>	ADu16ptr;
//	typedef ADA<int32>	ADi32ptr;
//	typedef ADA<uint32>	ADu32ptr;


/* ----	Calculate base 2 logarithm or 'position' of leftmost '1' bit -----------------
		return value:
				Log2(n>0) = int(log2(n))
		note:	Log2(n=1) = 0
		caveat:	Log2(n=0) = 0		// illegal argument!
		
		note: template does not work correctly because i don't know how to cast a signed type to a same-sized unsigned type
*/
inline int	Log2Nibble	( uint8 n )	 { return (n>7) + (n>3) + (n>1); }									//  0 ..  3
inline int	Log2		( uint8 n )	 { int b=0,i=4; do{if(n>>i){n>>=i;b+=i;}}while((i>>=1)); return b; } // 0 ..  7
inline int	Log2		( uint16 n ) { int b=0,i=8; do{if(n>>i){n>>=i;b+=i;}}while((i>>=1)); return b; } // 0 .. 15
inline int	Log2		( uint32 n ) { int b=0,i=16;do{if(n>>i){n>>=i;b+=i;}}while((i>>=1)); return b; } // 0 .. 31
inline int	Log2		( uint64 n ) { int b=0,i=32;do{if(n>>i){n>>=i;b+=i;}}while((i>>=1)); return b; } // 0 .. 63
inline int	Log2		( int8 n )	 { return Log2((uint8)n); }
inline int	Log2		( int16 n )	 { return Log2((uint16)n); }
inline int	Log2		( int32 n )	 { return Log2((uint32)n); }
inline int	Log2		( int64 n )	 { return Log2((uint64)n); }


/* ----	Calculate the number of digits required to print a number:
		return value:
				BinaryDigits(n=0) = 1
				BinaryDigits(n>0) = ceil(log2(n+1))
*/
template <class T> inline int	BinaryDigits ( T number )	 { return Log2(number)  +1; }	// result >= 1
template <class T> inline int	HexDigits	 ( T number )	 { return Log2(number)/4+1; }	// result >= 1

/* ----	Calculate the number of digits required to store a numbers of a given range:

				changed from 'maxval' to 'range' 2007-07-10 kio !

		return value:																
				Bits(n) = ceil(log2(n))
		note:	Bits(1) = ceil(log2(1)) = 0
		caveat:	Bits(0) = ceil(log2(0)) = 0		// illegal range!
*/
template <class T> inline int	Bits	 ( T count )	{ return count>1 ? Log2(count-1)  +1 : 0; }
template <class T> inline int	Nibbles	 ( T count )	{ return count>1 ? Log2(count-1)/4+1 : 0; }
template <class T> inline int	Bytes	 ( T count )	{ return count>1 ? Log2(count-1)/8+1 : 0; }



/* ----	random number with range ----------------------------------------
		returns random value [0 ... [n
*/
inline uint16	random	( uint32 n )						{ return ( n * uint32(uint16(random())) ) >> 16; }



/* ----	basic maths -----------------------------------------------------
*/
template <class T> inline T		Sign   ( T a )				{ return SIGN(a); }
template <class T> inline T		Abs    ( T a )				{ return ABS(a); }

template <class T> inline T		Min    ( T a, T b )			{ return a<b ? a : b; }
template <class T> inline T		Max    ( T a, T b )			{ return a>b ? a : b; }
template <class T> inline T		MinMax ( T a, T n, T e )	{ return n<=a ? a : n>=e ? e : n;  }

template <class T> inline void	Limit  ( T a, T&n, T e )	{ if (n<a) n=a; else if (n>e) n=e; }
template <class T> inline void	Swap   ( T& a, T& b )		{ T c=a; a=b; b=c;    }
template <class T> inline void	Sort   ( T& a, T& b )		{ if (a>b) Swap(a,b); }




/* ----	byte order independent and unaligned peek & poke -------------------------------
		PeekX => 'abcd' == *(ulong*)"abcd"	--> access data written by m68k, ppc, ...	<-- this is the internet order
		PeekZ => 'abcd' == *(ulong*)"dcba"	--> access data written by i386, z80, ...	<-- avoid if possible
		Peek  =>  machine order, unaligned. --> glue for machines which don't support unaligned memory access.
*/
	#define P(i)	((uint8*)p)[i]

	inline uint16 swap	(uint16 n)				{ return n<<8 | n>>8; }
	inline uint32 swap	(uint32 n)				{ return uint32(swap((uint16)n))<<16 | uint32(swap((uint16)(n>>16))); }
	inline uint64 swap	(uint64 n)				{ return uint64(swap((uint32)n))<<32 | uint64(swap((uint32)(n>>32))); }
	inline int16  swap	(int16 n)				{ return swap(uint16(n)); }
	inline int32  swap	(int32 n)				{ return swap(uint32(n)); }
	inline int64  swap	(int64 n)				{ return swap(uint64(n)); }

#if defined(_BIG_ENDIAN)		// PPC
	template<class T> inline T HiLo(T n) { return n; }
	template<class T> inline T LoHi(T n) { return swap(n); }
#elif defined(_LITTLE_ENDIAN)	// i386
	template<class T> inline T HiLo(T n) { return swap(n); }
	template<class T> inline T LoHi(T n) { return n; }
#endif


#if defined(_BIG_ENDIAN) && !_ALIGNMENT_REQUIRED
	inline uint8  Peek1X ( void const* p )		{ return *(uint8* )p; }
	inline uint16 Peek2X ( void const* p )		{ return *(uint16*)p; }
	inline uint32 Peek4X ( void const* p )		{ return *(uint32*)p; }
	inline uint64 Peek8X ( void const* p )		{ return *(uint64*)p; }
	inline void   Poke1X ( void* p, uint8 n )	{		 *(uint8* )p = n; }
	inline void   Poke2X ( void* p, uint16 n)	{		 *(uint16*)p = n; }
	inline void   Poke4X ( void* p, uint32 n )	{		 *(uint32*)p = n; }
	inline void   Poke8X ( void* p, uint64 n )	{		 *(uint64*)p = n; }
#else
	inline uint8  Peek1X ( void const* p )		{ return P(0); }
	inline uint16 Peek2X ( void const* p )		{ return P(0)<<8  | P(1); }
	inline uint32 Peek4X ( void const* p )		{ return P(0)<<24 | P(1)<<16 | P(2)<<8 | P(3); }
	inline void   Poke1X ( void* p, uint8 n )	{		 P(0)=n; }
	inline void   Poke2X ( void* p, uint16 n)	{		 P(0)=n>>8;  P(1)=n; }
	inline void   Poke4X ( void* p, uint32 n )	{		 P(0)=n>>24; P(1)=n>>16; P(2)=n>>8; P(3)=n; }
#endif
	inline void   Poke3X ( void*p, uint32 n )	{        Poke1X(p,n>>16); Poke2X((ptr)p+1,n); }
	inline uint32 Peek3X ( void const*p )		{ return Peek1X(p) <<16 | Peek2X((ptr)p+1);   }

#if defined(_LITTLE_ENDIAN) && !_ALIGNMENT_REQUIRED
	inline uint8  Peek1Z ( void const* p )		{ return *(uint8* )p; }
	inline uint16 Peek2Z ( void const* p )		{ return *(uint16*)p; }
	inline uint32 Peek4Z ( void const* p )		{ return *(uint32* )p; }
	inline void   Poke1Z ( void* p, uint8 n )	{		 *(uint8 *)p = n; }
	inline void   Poke2Z ( void* p, uint16 n)	{		 *(uint16*)p = n; }
	inline void   Poke4Z ( void* p, uint32 n )	{		 *(uint32*)p = n; }
#else
	inline uint8  Peek1Z ( void const* p )		{ return								 P(0); }
	inline uint16 Peek2Z ( void const* p )		{ return					   P(1)<<8 | P(0); }
	inline uint32 Peek4Z ( void const* p )		{ return P(3)<<24 | P(2)<<16 | P(1)<<8 | P(0); }
	inline void   Poke1Z ( void* p, uint8 n )	{								     P(0)=n; }
	inline void   Poke2Z ( void* p, uint16 n)	{					      P(1)=n>>8; P(0)=n; }
	inline void   Poke4Z ( void* p, uint32 n )	{ P(3)=n>>24; P(2)=n>>16; P(1)=n>>8; P(0)=n; }
#endif
	inline void   Poke3Z ( void* p, uint32 n )	{        Poke1Z((ptr)p+2,n>>16); Poke2Z(p,n); }
	inline uint32 Peek3Z ( void const* p )		{ return Peek1Z((ptr)p+2) <<16 | Peek2Z(p);   }

	#undef P


/* ----	unaligned peek & poke -------------------------------
		note: on PDP machines data is stored in little endian order.
		unaligned Peek and Poke on PDP machines is braindead anyway.
*/
#ifdef _BIG_ENDIAN
	inline uint8  Peek1 ( void const* p )	{ return Peek1X(p); }
	inline uint16 Peek2 ( void const* p )	{ return Peek2X(p); }
	inline uint32 Peek3 ( void const* p )	{ return Peek3X(p); }
	inline uint32 Peek4 ( void const* p )	{ return Peek4X(p); }

	inline void   Poke1 ( void* p, uint8 n  ) { Poke1X(p,n); }
	inline void   Poke2 ( void* p, uint16 n ) { Poke2X(p,n); }
	inline void   Poke3 ( void* p, uint32 n ) { Poke3X(p,n); }
	inline void   Poke4 ( void* p, uint32 n ) { Poke4X(p,n); }
#else
	inline uint8  Peek1 ( void const* p )	{ return Peek1Z(p); }
	inline uint16 Peek2 ( void const* p )	{ return Peek2Z(p); }
	inline uint32 Peek3 ( void const* p )	{ return Peek3Z(p); }
	inline uint32 Peek4 ( void const* p )	{ return Peek4Z(p); }

	inline void   Poke1 ( void* p, uint8  n ) { Poke1Z(p,n); }
	inline void   Poke2 ( void* p, uint16 n ) { Poke2Z(p,n); }
	inline void   Poke3 ( void* p, uint32 n ) { Poke3Z(p,n); }
	inline void   Poke4 ( void* p, uint32 n ) { Poke4Z(p,n); }
#endif



/* ----	count bits -------------------------------------------
*/

inline uint CountBits ( uint8 z )
{
	uint rval = z;
	rval = ((rval & 0xAAu) >> 1) + (rval & 0x55u);
	rval = ((rval & 0xCCu) >> 2) + (rval & 0x33u);
	rval = ((rval & 0xF0u) >> 4) + (rval & 0x0Fu);
	return rval;
}

inline uint CountBits ( uint16 z )
{
	uint rval = z;
	rval = ((rval & 0xAAAAu) >>  1) + (rval & 0x5555u);
	rval = ((rval & 0xCCCCu) >>  2) + (rval & 0x3333u);
	rval = ((rval & 0xF0F0u) >>  4) + (rval & 0x0F0Fu);
	rval = ((rval & 0xFF00u) >>  8) + (rval & 0x00FFu);
	return rval;
}

inline uint CountBits ( uint32 z )
{
	z = ((z & 0xAAAAAAAAu) >>  1) + (z & 0x55555555u);
	z = ((z & 0xCCCCCCCCu) >>  2) + (z & 0x33333333u);
	z = ((z & 0xF0F0F0F0u) >>  4) + (z & 0x0F0F0F0Fu);
	z = ((z & 0xFF00FF00u) >>  8) + (z & 0x00FF00FFu);
	z = ((z & 0xFFFF0000u) >> 16) + (z & 0x0000FFFFu);
	return z;
}

inline uint CountBits ( int8 z )	{ return CountBits((uint8)z); }
inline uint CountBits ( int16 z )	{ return CountBits((uint16)z); }
inline uint CountBits ( int32 z )	{ return CountBits((uint32)z); }

template<class T>
inline uint CountBits ( T z )		{ return sizeof(T)<4 ? CountBits((uint16)z) : CountBits((uint32)z); }


// count bits in array:
//
inline ulong CountBits( cu8ptr p, ulong bytes )
{
	ulong rval = 0;
	uint32 n;
	if(bytes<4) goto b;
	n=0; while(size_t(p)&3)	{ n = (n<<8) + *p++; bytes--; }

a:	rval += CountBits(n);
	if(bytes>=4) { n = *(uint32*)p; p+=4; bytes-=4; goto a; }

b:	n=0; while(bytes) { n = (n<<8) + *p++; bytes--; }
	if(n) goto a;
	return rval;
}


// count bits in array:
// if bits&7 != 0 then the last byte must be filled left-aligned (msb)
//
inline ulong CountBitsL( cu8ptr p, ulong bits )
{
	ulong rval = 0;
	uint32 n;
	if(bits<32) goto b;
	n=0; while(size_t(p)&3)	{ n = (n<<8) + *p++; bits-=8; }

a:	rval += CountBits(n);
	if(bits>=32) { n = *(uint32*)p; p+=4; bits-=32; goto a; }

b:	n=0; while(bits>=8) { n = (n<<8) + *p++; bits-=8; }
	if(bits) { n = ((n<<8)+*p)>>(8-bits); bits=0; }
	if(n) goto a;
	return rval;
}

// count bits in array:
// if bits&7 != 0 then the last byte must be filled right-aligned (lsb)
//
inline ulong CountBitsR( cu8ptr p, ulong bits )
{
	ulong rval = CountBits(p,bits/8);
	if(bits&7) rval += CountBits( uint8(p[bits/8]<<(8-(bits&7))) );
	return rval;
}



#endif	// __cplusplus


#endif



