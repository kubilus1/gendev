/*	Copyright  (c)	Günter Woigk   1999-2009
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	
	Display error and abort


	1999-01-01	kio	first work on this file
	2001-08-25	kio	added option for Abort() to suspend/terminate thread instead of quit appl
	2002-02-05	kio	cocoa support
	2008-06-04	kio	nothing special to cocoa in here -> deleted cocoa version
*/


#define	SAFE	2
#define	LOG		0

#include	"kio.h"
INIT_MSG

extern cstr appl_name;		// must be defined in application source


/* ----	print error message and quit application -------------------------------
		Print error message to stderr and abort.
*/
#if defined(_UNIX)

	void Abort ( cstr t, cstr u, cstr v  )
	{
		fputs( appl_name ? appl_name : "(who, me?)", stderr );
		fputs(": a fatal error occured:\n",stderr);
		if(t) fputs(t,stderr);
		if(u) fputs(u,stderr);
		if(v) fputs(v,stderr);
		fputs("\n",stderr);
		abort();
	}

#else
	#error   platform not yet supported
#endif


/* ----	display an alert and quit application -------------------------------
		Print file name, line number and message via Log()
		display a requester and abort.
*/
void Abort ( cstr file, long line, cstr text )
{
	cstr p = strrchr(file,'/'); if(p) file = p+1;	// filename from path

	char t[30]; sprintf(t," in line %ld: ",line);
	Abort( file, t, text );
}



