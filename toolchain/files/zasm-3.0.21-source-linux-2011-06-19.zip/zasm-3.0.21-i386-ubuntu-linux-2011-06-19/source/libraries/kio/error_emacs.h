/*	Copyright  (c)	Günter Woigk 1999 - 2008
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


	error number and error text definitions
	this file is included in "kio/errors.h"

	extending the error code list:
	file "custom_errors.h"
	custom application error messages
	file must exist but may be empty
*/


// basic errors:
	EMAC( customerror=EBAS, "custom error"				),	// kio/errors.h: custom error message
	EMAC( notanumber,		"not a number"				),	// cstrings/cstrings.h:	0.0/0.0 or string is not a number
	EMAC( unexpectedfup,	"utf-8 char started with fup"),	// cstrings/cstrings.h
	EMAC( endoffile,		"end of file"				),	// unix/file_utilities.h
#define    outofmemory		ENOMEM							// kio/errors.h: macro OMEM(), <=> std::bad_alloc : exception
	EMAC( internalerror,	"internal error"			),	// kio/errors.h: macro NIMP(),  class internal_error
	EMAC( notyetimplemented,"not yet implemented"		),	// kio/errors.h: macro TODO(),  class internal_error
	EMAC( indexerror,		"index out of range"		),	// kio/errors.h: macro INDEX(), class index_error : internal_error
	EMAC( limiterror,		"size out of range"			),	// kio/errors.h: macro LIMIT(), class limit_error : internal_error
	

#include "custom_errors.h"
#undef EMAC


#if 0

//	error codes used in my libraries:
//	these were moved to files "xxxerrors.h" which should be included in your "custom_errors.h":
//	left here for informational purpose.

//	unix/os_utilities_errors.h:
	childterminatedbysignal,"child terminated by signal"
	childreturnederror,		"child returned error"

//	var_errors.h:		
//	class Var:
	typemismatch,		"type mismatch in operator"		
	variableinuse,		"variable in use"		 		
	vtypeislocked,		"variable type is locked"		
	vdataislocked,		"variable data is locked"		
	listsintersect,		"one variable contains the other"
	listrequired,		"list required"

//	string_errors.h:
//	class String:
	notastring,			"not a string"
	nofinalquotes,		"unterminated text literal"

//	unicode_errors.h:
//	Unicode library:
	unknownconversion,	"unknown conversion type"		
	truncatedchar,		"truncated character"			
	illegaloverlong,	"illegal overlong encoding"		
	illegalchar,		"illegal character"				
	unexpectedfup,		"utf-8 char started with fup"	
	notindestcharset,	"character not in destination charset"
	missingquotes,		"missing quote(s) '\"'"	
	unmaskedamp,		"unmasked ampercent '&'"
	endofsource,		"end of source buffer"

//	compress_errors.h
//	freeze / shring compression library:
	buffertoosmall,		"buffer too small"

//	outdated error numbers:
//	should be replaced by standard unix error codes:
	numbertoobig		--> ERANGE	"Floating point number exceeds +/-HUGE_VAL"
	numbertoosmall		-->	ERANGE	"Floating point number is rounded to ±0.0"
	notsupportedbydev	-->	ENODEV	"Operation not supported by device"
	permissiondenied	--> EACCES	"Permission denied"
	ioerror				-->	EIO		"Unspecific input/output error"
	dupfilename			-->	EEXIST	"File exists"
	fileisbusy			-->	ETXTBSY	"File still in use"
	diskfull			--> ENOSPC	"No space left on device"
	directorynotfound	-->	ENOENT	"No such file or directory"
	filenotfound		-->	ENOENT	"No such file or directory"
	diskwriteprot		--> EROFS	"Read-only file system (hardware)"
	volumewriteprot		--> EROFS	"Read-only file system (software)"
	unknownfiletype		-->	EFTYPE	"Inappropriate file type or format"  ((non-posix only))

//	other outdated errors:
//	add in your "custom_errors.h" file:
	nosuchservice,		"no such service"
	notadevice,			"not a device"	
	badfilename,		"bad file name"
	controlcode,		"control code"
	inputbufferempty,	"input buffer empty"
	outputbufferfull,	"output buffer full"
	filenotopen,		"file not open"
	filealreadyopen,	"file already open"
	filewritelocked,	"file already open for writing"
	volumenotfound,		"volume not found"		
	filenotexecutable,	"file is not executable"
	emptyfilehandle,	"empty file handle"	
	filewriteprot,		"file is write protected"	// marked as write-protected (not read-only FS)

#endif

















