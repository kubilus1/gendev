/*	Copyright  (c)	Günter Woigk 1999 - 2009
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


	error exits & security levels

	this file is included by "kio/kio.h"

HOWTO:

	#define SAFE in every source file before #including any header:
		#define	SAFE 0		can't bummer:	rare!
		#define SAFE 1		stable release:	check only data from external sources (file, user input, etc.)
		#define SAFE 2		beta state: 	plus: check data in calls from other modules 
		#define	SAFE 3		alpha state:	plus: check data in module-internal calls
		#define SAFE 4		debugging:		check everything

	note: #ifdef DEBUG (e.g. with -DDEBUG on the command line for the compiler) 
		  then the safety level of each file is increased by 1 in "kio/kio.h"
	note: #ifdef FINAL (e.g. with -DFINAL on the command line for the compiler) 
		  then the safety level of each file is decreased by 1 in "kio/kio.h"


These are the basic test macros:

	XASSERT(<test>)				perform <test> and abort if result is false (just like "assert")
	XTRAP(<test>)				perform <test> and abort if result is true  (just opposed to "assert")
	XINDEX(index,size)			test index and abort if index >= size
	XLIMIT(size,limit)			test size and abort if size > limit
	XCheck(<arguments>)			call test procedure Check(<arguments>)  ((which must be defined by you))

	These macros have variants which differ in the amount of Xes:
	Each test is only enabled and compiled into the code if the current safety level of SAFE is
	at least as high as the amount of Xes. Otherwise the whole test will not generate any code.	

	These tests are not meant to trap expectable illegal data
	but to test preconditions to functions and to trap supposedly impossible conditions while debugging only!

	IMPORTANT:

	• Do not put required code in XTRAP() and others; e.g. don't: XASSERT( my_ptr=new char[n] ).
	  Each test is only compiled into the code if the current safety level of SAFE is at least 
	  as high as the amount of Xes. Otherwise the whole test will not generate any code!	
	  

Examples:

	source:							printed:

	ABORT("too tired");			--> sorry, a fatal error occured: main.cc in line 123: too tired
	TODO();						--> sorry, a fatal error occured: main.cc in line 123: not yet implemented
	IERR();						--> sorry, a fatal error occured: main.cc in line 123: internal error
//	OMEM(my_ptr);				--> sorry, a fatal error occured: main.cc in line 123: out of memory

	XXTRAP(0<0);				--> sorry, a fatal error occured: main.cc in line 123: TRAP: 0<0
	XXINDEX(my_idx,my_size)		--> sorry, a fatal error occured: main.cc in line 123: bad index: -1
	XXTRAP(s==NULL);
	XXASSERT(s!=NULL);

	void Check(int a);
	void Check(int a, int b);
	XCheck(arg1,arg2);
	XXCheck(anton);
*/



#ifdef kio_h


#ifdef __cplusplus
//	#define	ABORT(MSG)	Abort ( __FILE__, __LINE__, (MSG) )
	#define	ABORT(MSG)	throw( internal_error( __FILE__, __LINE__, (MSG) ) )
//	#define	OMEM(X)		if ( (X) )										 {} else throw( omem_error(__FILE__, __LINE__) )
	#define	INDEX(I,M)	if ( (ulong)(long)(I)<(ulong)(long)(M) )		 {} else throw( index_error(__FILE__,__LINE__,(I)) )
	#define	LIMIT(I,M)	if ( (unsigned size_t)(I)<=(unsigned size_t)(M) ){} else throw( limit_error(__FILE__,__LINE__,(I)) )
#else
	#define	ABORT(MSG)	Abort ( __FILE__, __LINE__, (MSG) )
	#define	OMEM(X)		if ( (X) ) 	                             {} else ABORT ( "out of memory" )
#endif

	#define NIMP()		NIMP_heisst_jetzt_TODO
	#define ORANGE()	ORANGE_heisst_jetzt_INDEX

	#define	IERR()		ABORT( internalerror )
	#define	TODO()		ABORT( notyetimplemented )
	#define	TRAP(X)		if ( !(X) )	{} else ABORT ( "TRAP: " #X )
	#define	ASSERT(X)	if ( (X) )	{} else ABORT ( "FAILED: " #X )


	#define	XSAFE			(SAFE>=1)
	#define	XXSAFE			(SAFE>=2)
	#define	XXXSAFE			(SAFE>=3)
	#define	XXXXSAFE		(SAFE>=4)


	#define	XTRAP(X)		if( !XSAFE )	{} else TRAP(X)
	#define	XXTRAP(X)		if( !XXSAFE ) 	{} else TRAP(X)
	#define	XXXTRAP(X)		if( !XXXSAFE )	{} else TRAP(X)
	#define	XXXXTRAP(X)		if( !XXXXSAFE )	{} else TRAP(X)


	#define	XASSERT(X)		if( !XSAFE )	{} else ASSERT(X)
	#define	XXASSERT(X)		if( !XXSAFE ) 	{} else ASSERT(X)
	#define	XXXASSERT(X)	if( !XXXSAFE )  {} else ASSERT(X)
	#define	XXXXASSERT(X)	if( !XXXXSAFE ) {} else ASSERT(X)


	#define	XINDEX(I,M)		if( !XSAFE )	{} else INDEX(I,M)
	#define	XXINDEX(I,M)	if( !XXSAFE ) 	{} else INDEX(I,M)
	#define	XXXINDEX(I,M)	if( !XXXSAFE )	{} else INDEX(I,M)
	#define	XXXXINDEX(I,M)	if( !XXXXSAFE )	{} else INDEX(I,M)


	#define	XLIMIT(I,M)		if( !XSAFE )	{} else LIMIT(I,M)
	#define	XXLIMIT(I,M)	if( !XXSAFE ) 	{} else LIMIT(I,M)
	#define	XXXLIMIT(I,M)	if( !XXXSAFE )	{} else LIMIT(I,M)
	#define	XXXXLIMIT(I,M)	if( !XXXXSAFE )	{} else LIMIT(I,M)


	#define	XCheck			if( !XSAFE )	{} else Check
	#define	XXCheck			if( !XXSAFE )	{} else Check
	#define	XXXCheck		if( !XXXSAFE )	{} else Check
	#define	XXXXCheck		if( !XXXXSAFE )	{} else Check


	extern void	Abort		( cstr s, cstr t=0, cstr u=0  );		// -> abort()
	extern void	Abort		( cstr file, long line,  cstr text );	// -> abort()
	inline void Abort		( cstr file, long line,  int err )		{ Abort(file,line,strerror(err));   }
	inline void	Abort		( cstr file, long line )				{ Abort(file,line,strerror(errno)); }


#endif








