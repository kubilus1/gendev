/*	Copyright  (c)	Günter Woigk 1994 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	Kio's universal standard c++ header.
	
	required files in project:
		config.h			the unix-style MY_COMPILER_HAS_THIS_OR_THAT #defines
		custom_errors.h		custom error number/message pair macros. may be empty

	includes minimal set of headers from my libraries/
		kio/standard_types.h"
		kio/log.h
		kio/abort.h
		kio/errors.h
		kio/nice_defines.h
		cstrings/cstrings.h

	
	asserted macros:
		safety level:		SAFE
		log level:			LOG
		major platform:		_UNIX  or  _WINDOWS
		minor platform:		_WINDOWS  or  _LINUX  or  _BSD  or  _MINIX  or  _SOLARIS
		compiler:			_METROWERKS  or  _GCC  or  _MPW
		processor:			_POWERPC  or  _M68K  or  _I386  or  _ALPHA  or  _SPARC  or  _I386x64
		byte order:			_LITTLE_ENDIAN  or  _BIG_ENDIAN  or  _PDP_ENDIAN
		data alignment:		_ALIGNMENT_REQUIRED
							_MAX_ALIGNMENT			
							_SHORT_ALIGNMENT
							_INT_ALIGNMENT	
							_LONG_ALIGNMENT	
							_LONG_LONG_ALIGNMENT
							_DOUBLE_ALIGNMENT	
							_LONG_DOUBLE_ALIGNMENT
							_POINTER_ALIGNMENT	

	other defines:
		_PLATFORM			"<platform-subplatform>"
		_COMPILER			"<compiler>"
		_PROCESSOR			"<processor>"
		_BYTEORDER			"<byteorder-info>"
		
		INIT_MSG(text)		print message to stderr during startup
		ON_INIT(action())	initialize module
		char const dirsep;	directory separator character	(dep. on target platform)
		char const nl;		line break character			(dep. on target platform)
		#define no_index	dummy index for empty arrays	(dep. on compiler)
*/

#ifndef	kio_h
#define	kio_h


#define	myName				"Günter Woigk"
#define	myAddress			"Sankt Johann 6/246, 91056 Erlangen, Germany"
#define	myEmail				"kio@little-bat.de"
#define	myDomain			"k1.dyndns.org"



/* ----	include "config.h" ----------------------------------------
		on unix systems "config.h" should be generated from "configure.in"
		using autoconf and should not be part of the cvs repository.

		on other systems put this file into the platform specific subfolder
		and edit this file directly. this platform specific variant should
		go into the cvs.
*/
#include "config.h"


/* ----	determine platform ----------------------------------------

		platform identifier:
		guarantee that platform is detected.
		_UNIX, _WINDOWS							undefined or 1

		sub platform identifier:
		guarantee that sub platform is detected.
		_LINUX, _BSD, _MINIX, _SOLARIS			undefined or 1
*/
#if defined(_UNIX) + defined(_WINDOWS) != 1
	#error platform not #defined in "config.h"  ((or multiple platforms detected))!
#endif

#if defined(_UNIX) && ( defined(_LINUX) + defined(_BSD) + defined(_MINIX) + defined(_SOLARIS) != 1 )
	#error UNIX sub platform not #defined in "config.h"  ((or multiple sub platforms detected))!
#endif

#if defined(_UNIX)
	#if defined(_LINUX)
		#if defined(_SUSE)
			#define _PLATFORM "Unix-Linux-SuSE"
		#elif defined(_DEBIAN)
			#define _PLATFORM "Unix-Linux-Debian"
		#elif defined(_REDHAT)
			#define _PLATFORM "Unix-Linux-Redhat"
		#elif defined(_YELLOWDOG)
			#define _PLATFORM "Unix-Linux-YellowDog"
		#else
			#define _PLATFORM "Unix-Linux"
		#endif
	#elif defined(_BSD)
		#if  defined(_FREEBSD)
			#define _PLATFORM "Unix-BSD-FreeBSD"
		#elif defined(_OPENBSD)
			#define _PLATFORM "Unix-BSD-OpenBSD"
		#elif defined(_NETBSD)
			#define _PLATFORM "Unix-BSD-NetBSD"
		#elif defined(_MACOSX)
			#define _PLATFORM "Unix-BSD-MacOSX"
		#else
			#define _PLATFORM "Unix-BSD"
		#endif
	#elif defined(_MINIX)
		#define _PLATFORM "Unix-Minix"
	#elif defined(_SOLARIS)
		#define _PLATFORM "Unix-Solaris"
	#else
		#define _PLATFORM "Unix"
	#endif
#elif defined(_WINDOWS)
	#define _PLATFORM "Windows"
#else
	#define _PLATFORM "platform unknown"
#endif


/* ----	determine compiler ----------------------------------
		guarantee that compiler is detected.
		_METROWERKS, _GCC, _MPW
*/
#if !defined(_METROWERKS) && !defined(_GCC) && !defined(_MPW)
	#if defined(_MPW_C) || defined(_MPW_CPLUS)
		#define _MPW			1
	#elif defined(__GNUC__) || defined(__GNUG__)
		#define _GCC			1
	#else
		#error "can't determine compiler"
	#endif
#endif
#if defined(_METROWERKS)
	#define _COMPILER "Metrowerks"
#elif defined(_GCC)
	#define _COMPILER "gcc"
#elif defined(_MPW)
	#define _COMPILER "MPW"
#endif



/* ----	basic system headers -----------------------
*/
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#else
extern long random();
#endif

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif

#ifdef HAVE_STDARG_H
#include <stdarg.h>
#endif

#ifdef HAVE_STDIO_H
#include <stdio.h>
#endif

#ifdef HAVE_STRING_H
#include <string.h>
#endif

#ifdef HAVE_CTYPE_H
#include <ctype.h>
#endif

#ifdef HAVE_ASSERT_H
#include <assert.h>
#endif

#ifdef HAVE_MACHINE_ENDIAN_H
#include <machine/endian.h>
#endif

#ifdef HAVE_ENDIAN_H
#include <endian.h>
#endif



/* ----	determine processor -----------------------------------
		guarantee that processor is detected.
		_POWERPC, _M68K, _I386, _ALPHA, _SPARC, _I386x64
*/
#if defined(_POWERPC) + defined(_M68K) + defined(_I386) + defined(_ALPHA) + defined(_SPARC) + defined(_I386x64) != 1
	#if defined(__i386__) || defined(__i386)
		#define	_I386		1
	#elif defined(__ppc__) || defined(__PPC__) || defined(__powerpc__)
		#define	_POWERPC	1
	#elif defined(__x86_64__)
		#define _I386x64	1		
	#elif defined(__alpha__) || defined(__ia64)
		#define	_ALPHA		1
	#elif defined(__sparc__) || defined(__sparc)
		#if defined(__sparcv8)		// 32 bit cpu
			#define	_SPARC	"V8"
		#elif defined(__sparcv9)	// 64 bit cpu
			#define	_SPARC	"V9"
		#else
			#define _SPARC	1
		#endif
	#endif
	#if defined(_POWERPC) + defined(_M68K) + defined(_I386) + defined(_ALPHA) + defined(_SPARC) + defined(_I386x64) != 1
		#error "can't determine processor type. ((or multiple processor types detected))"
	#endif
#endif
#if defined(_POWERPC)
	#define _PROCESSOR "PowerPC"
#elif defined(_M68K)
	#define _PROCESSOR "MC680x0"
#elif defined(_I386)
	#define _PROCESSOR "i386"
#elif defined(_ALPHA)
	#define _PROCESSOR "Alpha"
#elif defined(_SPARC)
	#define _PROCESSOR "Sparc"
#elif defined(_I386x64)
	#define _PROCESSOR "i386x64"
#endif



/* ==== dependencies ==============================================
*/



/* ---- directory separator ------------------------
		guaranteed constant.
*/
#if defined(_WINDOWS)
	char const	dirsep	=	'\\';
#else
	char const	dirsep	=	'/';
#endif



/* ----	newline separator ------------------------------
		guaranteed constant.
		note: *MAYBE* we'll support DOS a little better?
*/
	char const	nl		=	10;



/* ----	no_index --------------------------------------
		guaranteed macro.
		in structs and classes the last data member can be a variable length array.
		this is handled differently by different compilers:
		either you set the index to 0 or you leave it completely out.
*/
#if defined(_GCC)
	#define		no_index		0
#elif defined(_METROWERKS)
	#define		no_index		/* ((empty)) */
#elif defined(_MPW)
	#error "please set no_index to what is supported by MPW. thanks."
#else
	#error
#endif



/* ----	processor characteristics ---------------------
		2003-11-26 kio: switch to Sun's names
*/
#if defined(_SPARC)
// all should be setup by /usr/include/sys/isa_defs.h
//	#define	_BIG_ENDIAN
//	#define	_SHORT_ALIGNMENT		2
//	#define	_INT_ALIGNMENT			4
//	#define	_LONG_LONG_ALIGNMENT	8
//	#define	_DOUBLE_ALIGNMENT		8
//	#define	_ALIGNMENT_REQUIRED		1
//	#if _SPARC=="V8"
//		#define	_LONG_ALIGNMENT			4
//		#define	_LONG_DOUBLE_ALIGNMENT	8
//		#define	_POINTER_ALIGNMENT		4
//		#define	_MAX_ALIGNMENT			8
//	#elif _SPARC=="V9"
//		#define	_LONG_ALIGNMENT			8
//		#define	_LONG_DOUBLE_ALIGNMENT	16
//		#define	_POINTER_ALIGNMENT		8
//		#define	_MAX_ALIGNMENT			16
#endif


#if defined(_ALPHA)
	#undef	_LITTLE_ENDIAN
	#undef	_BIG_ENDIAN
	#undef	_PDP_ENDIAN
	#undef	_SHORT_ALIGNMENT
	#undef	_INT_ALIGNMENT
	#undef	_LONG_ALIGNMENT
	#undef	_LONG_LONG_ALIGNMENT
	#undef	_DOUBLE_ALIGNMENT
	#undef	_POINTER_ALIGNMENT
	#undef	_MAX_ALIGNMENT
	#undef	_ALIGNMENT_REQUIRED

	#define	_LITTLE_ENDIAN			1
	#define	_SHORT_ALIGNMENT		2
	#define	_INT_ALIGNMENT			4
	#define	_LONG_ALIGNMENT			8
	#define	_LONG_LONG_ALIGNMENT	8
	#define	_DOUBLE_ALIGNMENT		8
	#define	_LONG_DOUBLE_ALIGNMENT	16
	#define	_POINTER_ALIGNMENT		8
	#define	_MAX_ALIGNMENT			16
	#define	_ALIGNMENT_REQUIRED		1
#endif


#if defined(_I386)
	#undef	_LITTLE_ENDIAN
	#undef	_BIG_ENDIAN
	#undef	_PDP_ENDIAN
	#undef	_SHORT_ALIGNMENT
	#undef	_INT_ALIGNMENT
	#undef	_LONG_ALIGNMENT
	#undef	_LONG_LONG_ALIGNMENT
	#undef	_DOUBLE_ALIGNMENT
	#undef	_LONG_DOUBLE_ALIGNMENT
	#undef	_POINTER_ALIGNMENT
	#undef	_MAX_ALIGNMENT
	#undef	_ALIGNMENT_REQUIRED

	#define	_LITTLE_ENDIAN			1
	#define	_SHORT_ALIGNMENT		2
	#define	_INT_ALIGNMENT			4
	#define	_LONG_ALIGNMENT			4
	#define	_LONG_LONG_ALIGNMENT	4
	#define	_DOUBLE_ALIGNMENT		4
	#define _LONG_DOUBLE_ALIGNMENT	4
	#define	_POINTER_ALIGNMENT		4
	#define	_MAX_ALIGNMENT			4
	#define	_ALIGNMENT_REQUIRED		0
#endif


#if defined(_I386x64)
	#undef	_LITTLE_ENDIAN
	#undef	_BIG_ENDIAN
	#undef	_PDP_ENDIAN
	#undef	_SHORT_ALIGNMENT
	#undef	_INT_ALIGNMENT
	#undef	_LONG_ALIGNMENT
	#undef	_LONG_LONG_ALIGNMENT
	#undef	_DOUBLE_ALIGNMENT
	#undef	_LONG_DOUBLE_ALIGNMENT
	#undef	_POINTER_ALIGNMENT
	#undef	_MAX_ALIGNMENT
	#undef	_ALIGNMENT_REQUIRED

	#define	_LITTLE_ENDIAN			1
	#define	_SHORT_ALIGNMENT		2
	#define	_INT_ALIGNMENT			4
	#define	_LONG_ALIGNMENT			4
	#define	_LONG_LONG_ALIGNMENT	8
	#define	_DOUBLE_ALIGNMENT		8
	#define _LONG_DOUBLE_ALIGNMENT	8
	#define	_POINTER_ALIGNMENT		8
	#define	_MAX_ALIGNMENT			8
	#define	_ALIGNMENT_REQUIRED		0
#endif


#if defined(_POWERPC)
	#undef	_LITTLE_ENDIAN
	#undef	_BIG_ENDIAN
	#undef	_PDP_ENDIAN
	#undef	_SHORT_ALIGNMENT
	#undef	_INT_ALIGNMENT
	#undef	_LONG_ALIGNMENT
	#undef	_LONG_LONG_ALIGNMENT
	#undef	_DOUBLE_ALIGNMENT
	#undef	_POINTER_ALIGNMENT
	#undef	_MAX_ALIGNMENT
	#undef	_ALIGNMENT_REQUIRED

	#define	_BIG_ENDIAN				1
	#define	_SHORT_ALIGNMENT		2
	#define	_INT_ALIGNMENT			4
	#define	_LONG_ALIGNMENT			4
	#define	_LONG_LONG_ALIGNMENT	4
	#define	_DOUBLE_ALIGNMENT		4
	#define _LONG_DOUBLE_ALIGNMENT	4
	#define	_POINTER_ALIGNMENT		4
	#define	_MAX_ALIGNMENT			4
	#define	_ALIGNMENT_REQUIRED		0
	// note: missaligned access to float/double is handled _very_slowly_ (~2000 clock cycles)
	//		 probably by trap on G3/G4. don't know about G5.
#endif


#if defined(_M68K)
	#undef	_BIG_ENDIAN
	#define	_BIG_ENDIAN				1
#endif


#if defined(_PDP)
	#undef	_PDP_ENDIAN
	#define	_PDP_ENDIAN				1
#endif



/* ----	byte order ---------------------------------
		guarantee that byte order is detected.
		_BIG_ENDIAN  	e.g. M68k	dc.l '4321' = dc.b '4','3','2','1'	(ok.)
		_LITTLE_ENDIAN	e.g. i386	dc.l '4321' = dc.b '1','2','3','4'	(bad!)
		_PDP_ENDIAN  	e.g. PDP	dc.l '4321' = dc.b '3','4','1','2'	(brain dead!)
*/
#if defined(BYTE_ORDER) && ( defined(_LITTLE_ENDIAN) + defined(_BIG_ENDIAN) + defined(_PDP_ENDIAN) == 0 )
	#if defined(BIG_ENDIAN) && BYTE_ORDER==BIG_ENDIAN
		#define			_BIG_ENDIAN		1
	#elif defined(LITTLE_ENDIAN) && BYTE_ORDER==LITTLE_ENDIAN
		#define			_LITTLE_ENDIAN	1
	#elif defined(PDP_ENDIAN) && BYTE_ORDER==PDP_ENDIAN
		#define			_PDP_ENDIAN		1
	#endif
#endif

#if defined(__BIG_ENDIAN__) && !defined(_BIG_ENDIAN)
	#error Big Endian: fix me!
#endif

#if defined(__LITTLE_ENDIAN__) && !defined(_LITTLE_ENDIAN)
	#error Little Endian: fix me!
#endif

#if defined(_LITTLE_ENDIAN) + defined(_BIG_ENDIAN) + defined(_PDP_ENDIAN) != 1
	#error "can't detect byte order  ((or multiple byte orders detected))"
#endif

#if defined(_LITTLE_ENDIAN)
	#define _BYTEORDER "little endian (lsb first)"
#elif defined(_BIG_ENDIAN)
	#define _BYTEORDER "big endian (msb first)"
#elif defined(_PDP_ENDIAN)
	#define _BYTEORDER "pdp endian (lsb first + msw first)"
#endif


/* ----	verify that all processor characteristics are set --------------------
*/
#if !defined(_SHORT_ALIGNMENT) || !defined(_INT_ALIGNMENT) || !defined(_LONG_ALIGNMENT) || !defined(_LONG_LONG_ALIGNMENT)
	#error "missing CPU characteristics. (1) fixme!"
#elif !defined(_ALIGNMENT_REQUIRED) || !defined(_DOUBLE_ALIGNMENT) || !defined(_POINTER_ALIGNMENT) || !defined(_MAX_ALIGNMENT)
	#error "missing CPU characteristics. (2) fixme!"
#endif



/* ----	#define SAFE and LOG ---------------------------
		guaranteed macros.
		• ifndef LOG then LOG is set to 1
		• ifndef SAFE then compiling is aborted via #error
		• ifdef FINAL then SAFE is decremented by 1 and LOG is cleared to 0
		• ifdef DEBUG then SAFE is incremented by 1
*/
#ifndef LOG
	#define	LOG		1
	//	Log()		final:	errors, asserts
	//	XLog()				rare events, statistics, warnings, debug info
	//	XXLog()				initialization, more events
	//	XXXLog()	debug:	global procs: entry & exit, opt. results
#endif
#ifndef SAFE
	#error 'SAFE' not #defined!
	//	TRAP()		final:	rare tests and onetime asserts: system, environment, data types
	//	XTRAP()				low-impact tests: critical positions, basic check external call arguments
	//	XXTRAP()			mid-impact tests: check external call args, basic check internal call args
	//	XXXTRAP()	debug:	high-impact tests: check arguments, check internal state of module
#endif



// command line option -DFINAL
// no logging, less error checking
#ifdef FINAL
	#if LOG>0
		#undef 		LOG
		#define		LOG		0
	#endif

	#if SAFE>2
		#undef 		SAFE
		#define		SAFE	2
	#elif SAFE>1
		#undef 		SAFE
		#define		SAFE	1
	#else
		#undef 		SAFE
		#define		SAFE	0
	#endif
#endif

// command line option -DDEBUG
// more error checking
#ifdef DEBUG
	#if SAFE<1
		#undef		SAFE
		#define		SAFE	1
	#elif SAFE<2
		#undef		SAFE
		#define		SAFE	2
	#elif SAFE<3
		#undef		SAFE
		#define		SAFE	3
	#endif
#endif



/* ----	other standard headers ---------------------
*/
#include "standard_types.h"
#include "log.h"
#include "abort.h"
#include "errors.h"
#include "nice_defines.h"
#include "cstrings/cstrings.h"



/* ---- log message at start ----
		INIT_MSG -> print filename
		• during statics initialization 
		• depending on log level
*/
#if XLOG
#define INIT_MSG static struct _iMSG { _iMSG(cstr f){ Log( "%s: ",strrchr(f,'/')+1 ); } } _imsg("/"__FILE__);
#else
#define INIT_MSG
#endif


/* ----	initialization at start ----
		• during statics initialization
		• only once
		• you must assert yourself that the module/class is not used 
		  by other modules/classes before it is initialized.
		  else use a 'virgin' test in constructors et.al. 
		  or use pthread pthread_once_t.
*/
#define ON_INIT(ACTION) static struct _OnInitStruct { _OnInitStruct( void(*f)() ){f();} } z(ACTION);


/* ----	new() / delete() library to use ------------------------------
*/
#ifdef USE_KIOS_MALLOC
	#include	"malloc/malloc.h"
#else
//	void*		operator new	    ( size_t );
//	void*		operator new[]		( size_t );
//	inline void*operator new    	( size_t, void* p )	{ return p; }
//	void		operator delete 	( void* );
//	void 		operator delete[]	( void* );
#endif



#endif		// kio_h















