/*	Copyright  (c)	Günter Woigk 1995 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	c-string library

	• this library provides string manipulation for c-style strings.
	• results are typically stored in thread-safe TempMem buffers 
	  and are valid until the current TempMemPool is deallocated.
	• they are intended for immediate use, 
	  e.g. for printing, intermediate values in string expressions 
	  and for returning result strings.
*/


#ifndef cstrings_h
#define cstrings_h

#include "kio/kio.h"



inline	bool	_is_uppercase(char c)	{ return uchar(c-'A')<='Z'-'A'; }
inline	char	_to_lower(char c)		{ return uchar(c-'A')<='Z'-'A' ? c|0x20 : c; }
inline	bool	_is_lowercase(char c)	{ return uchar(c-'a')<='z'-'a'; }
inline	char	_to_upper(char c)		{ return uchar(c-'a')<='z'-'a' ? c&~0x20 : c; }
inline	bool	_is_letter(char c)		{ return uchar((c|0x20)-'a')<='z'-'a'; }

inline	bool	_is_bin_digit(char c)  	{ return uchar(c-'0')<='1'-'0'; } // { return (c|1)=='1'; }
inline	bool	_is_oct_digit(char c)  	{ return uchar(c-'0')<='7'-'0'; } // { return (c|7)=='7'; }
inline	bool	_is_dec_digit(char c)  	{ return uchar(c-'0')<='9'-'0'; }
inline	bool	_is_hex_digit(char c) 	{ return uchar(c-'0')<='9'-'0' || uchar((c|0x20)-'a') <= 'f'-'a'; }

inline	bool	_no_bin_digit(char c)  	{ return uchar(c-'0')>'1'-'0'; } // { return (c|1)=='1'; }
inline	bool	_no_oct_digit(char c)  	{ return uchar(c-'0')>'7'-'0'; } // { return (c|7)=='7'; }
inline	bool	_no_dec_digit(char c)  	{ return uchar(c-'0')>'9'-'0'; }
inline	bool	_no_hex_digit(char c) 	{ return uchar(c-'0')>'9'-'0' && uchar((c|0x20)-'a') > 'f'-'a'; }

// char -> digit value: ['0'..'9'] ---> [0..9]; non-digits ---> [10..255]
inline	int		_digit_val(char c)	 	{ return uchar(c-'0'); }

// char -> digit value: ['0'..'9']['A'..'Z']['a'..'z'] ---> [0...35]; non-digits ---> [36..233]
inline	int		_digit_value(char c)	{ return c<='9' ? uchar(c-'0') : int(uchar((c&~0x20)-'A'))+10; }



// ----	allocate with new[] ----
str 		NewStr		( int n ) throw(bad_alloc);		// allocate memory with new[]
str			NewCopy		( cstr )  throw(bad_alloc);		// allocate memory with new[] and copy text


// ---- querries ----
inline int	StrLen		( cstr s )			{ return s?strlen(s):0; }		// c-string
bool		SameStr		( cstr, cstr );


// ---- allocate in TempMem pool ----
str			TempStr		( int n ) throw(bad_alloc);		// tempmem.h
str			XtTempStr	( int n ) throw(bad_alloc);		// tempmem.h
str			SpaceStr	( int n, char c=' ' );
str			WhiteStr	( cstr, char c=' ' );
str			DupStr		( cstr );
str			XtDupStr	( cstr );

str			SubStr		( cptr a, cptr e );
inline str	SubStr		( cuptr a, cuptr e )		{ return SubStr((cptr)a,(cptr)e); }		// convenience method
str 		MulStr 		( cstr, int n );
str 		CatStr 		( cstr, cstr );
str 		CatStr 		( cstr, cstr, cstr, cstr=0, cstr=0, cstr=0 );
str 		MidStr 		( cstr, int a, int n );
str 		MidStr 		( cstr, int a );
str 		LeftStr 	( cstr, int n );
str 		RightStr 	( cstr, int n );
inline char	LastChar	( cstr s )					{ return s&&*s ? s[strlen(s)-1] : 0; }

str			HexStr 		( long n, int len );
str			BinStr		( int n, cstr b0="00000000", cstr b1="11111111" );
str			NumStr 		( float32 );
str			NumStr 		( double );
str			NumStr 		( long double );
str			NumStr 		( int64 n );
str			NumStr 		( uint64 n );
str			NumStr 		( int32 n );
str			NumStr 		( uint32 n );
str			CharStr		( char c );

inline void	ToUpper		( str s )					{ if(s) for( ;*s;s++ ) *s = _to_upper(*s); }
inline void	ToLower		( str s )					{ if(s) for( ;*s;s++ ) *s = _to_lower(*s); }
str			UpperStr	( cstr );
str			LowerStr	( cstr );
str			ReplacedStr	( cstr, char oldchar, char newchar );	// 2010-12-28: added 'd' to name
str			Quoted		( cstr s );
str			Unquoted	( cstr s );
str			Escaped		( cstr s );
str			Unescaped	( cstr s );
str			ToHtml		( cstr s );
str			FromHtml	( cstr s );
str			ToUtf8Str	( cstr s );
str			FromUtf8Str	( cstr s );					// UCS1 / Latin-1 only. may set errno.

str			VaUsing		( cstr format, va_list arg );
str			Using		( cstr format, ... );

ptr			FindStr		( cstr target, cstr search );
ptr			RFindStr	( cstr target, cstr search );

str			DateStr		( time_t secs );			// 2010-12-04: only data
str			TimeStr		( time_t secs );			// 2010-12-04
str			DateTimeStr	( time_t secs );			// 2010-12-04
time_t		DateVal		( cstr );
str			DurationStr	( time_t secs );
str			DurationStr ( double secs );			// 2010-10-16
str			SpeakingNumber ( double n );


// _________________________________________________________________________
//
#ifdef INCLUDE_DEPRECATED

	#define	CompileDate()	(__DATE__" at "__TIME__)

	enum strconvtype { str_noconv,str_html,str_escaped,str_printable=str_escaped,str_quoted };

	str		ConvertedTo	( cstr, strconvtype );
	str		ConvertedFrom(cstr, strconvtype );

//	str 	NewReadStr 	( FILE* ) throw(bad_alloc);		// moved to unix/FILE.cpp
	char	NextChar	( cptr& p );

#endif

#endif









