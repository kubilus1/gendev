/*	Copyright  (c)	Günter Woigk 1995 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	1995-06-29 kio	started work on pascal string lib
	2000-01-28 kio	started work on c string lib
	2002-01-19 kio	started unix port
	2002-01-26 kio	simplified Using(): now using vsnprintf()
	2002-01-26 kio	added xpool[] for unlimited string length support
	2004-12-16 kio	split into functions and qstring part for multi threading safe version for Cocoa
	2006-10-31 kio	renamed QString() to QuickStr() wg. naming collission with Qt.
	2008-05-14 kio	renamed QuickStr() to TempStr()
	2008-05-15 kio	unified thread-safe temporary memory allocation using the new TempMem library
	2010-10-17 kio	skip whitespace after \-escaped linebreak in ConvertedFrom(escaped)
*/


#define	SAFE	3
#define	LOG		1

#include	<math.h>
#include	<time.h>
#include	"unix/tempmem.h"
#include	"cstrings.h"
INIT_MSG

#ifdef HAVE_NAN_H
#include	<nan.h>
#endif
#ifndef NAN
const double NAN = 0.0/0.0;
#endif
static char null = 0;
static str emptystring = &null;



/* ----	allocate char[] -----------------------------------------
		deallocate with delete[]
		presets terminating 0
		2007-07-10: added the 'bad_alloc'
*/
str NewStr ( int n ) throw(bad_alloc)
{
	str c = new char[n+1];
	c[n] = 0;
	return c;
}


/* ----	allocate char[] -----------------------------------------
		deallocate with delete[]
		includes OOMEM check
		returns NULL if source string is NULL			2001-01-29
*/
str NewCopy ( cstr s ) throw(bad_alloc)
{
	str c = NULL;
	if (s)
	{
		c = NewStr(strlen(s));
		strcpy ( c, s );
	}
	return c;
}


#ifdef _MPW
/* ----	vsnprintf emulation for MPW ---------------
		kio 2002-09-15 quick hack
*/
inline int vsnprintf ( str dest, size_t size, cstr format, va_list va )
{
	int bytes_written = vsprintf(dest,format,va);
	TRAP(bytes_written>size);
	return bytes_written;
}
#endif


/* ----------------------------------------------------------
			METHODS
---------------------------------------------------------- */


/* ----	Create duplicate of string ---------------------------------
		Put a string in the pool
*/
str DupStr ( cstr s )
{
	if (!s||!*s) return emptystring;							// 2000-12-28
	int n = strlen(s);
	str c = TempStr(n);
	memcpy ( c,s,n );
	return c;
}


/* ----	Create duplicate of string --------------------------------- 2009-06-19
		Put a string in the outer pool
*/
str XtDupStr ( cstr s )
{
	if (!s||!*s) return emptystring;
	int n = strlen(s);
	str c = XtTempStr(n);
	memcpy ( c,s,n );
	return c;
}


/* ---- compare strings -------------------------------------
		NULL pointers are assumed ""
*/
bool SameStr ( cstr s, cstr t )
{
	if (s&&t)										// kio 2000-12-28
	{
		while (*s) if (*s++!=*t++) return false;
		return *t==0;								// kio 2000-04-01
	}
	else
	{
		return ((!s)||(!*s)) && ((!t)||(!*t));		// kio 2002-01-20
	}
}


/* ----	search sub string ------------------------------------ kio 2001-08-11 ----
*/
char* FindStr ( cstr target, cstr search )
{
	if (!search||!*search) return (char*)target;

	int t_len = StrLen(target);
	int s_len = StrLen(search);

	for ( int i=0; i<=t_len-s_len; i++ )
	{
		const char* s = search;
		const char* t = target+i;
		do { if (*s==0) return (char*)target+i; } while (*s++==*t++);
	}
	return NULL;	// not found
}


/* ----	search sub string ------------------------------------ kio 2001-08-22 ----
*/
char* RFindStr ( cstr target, cstr search )
{
	int t_len = StrLen(target);
	int s_len = StrLen(search);

	if (!search||!*search) return (char*)target+t_len;
	const char* se = search+s_len;

	for ( int i=t_len-s_len; i>=0; i-- )
	{
		const char* s = search;
		const char* t = target+i;
		do { if (s==se) return (char*)target+i; } while (*s++==*t++);
	}
	return NULL;	// not found
}


/* ----	Create and clear a string ---------------------------
*/
str SpaceStr ( int n, char c )
{
	if (n<=0) return emptystring;			// kio 26.nov.2000
	str s = TempStr(n);
	memset ( s, c, n );
	return s;
}


/* ----	Convert pascal-style string to c-style string ------------------------------
*/
str CStr ( const uchar *p )
{
	XTRAP(p==0);

	str s = TempStr(*p);
	memcpy(s,p+1,*p);
	return s;
}


// ----	Convert c-style string to pascal-style string ------------------------------
//		string length is limited to 255
uchar* PStr ( cstr c )
{
	XTRAP(c==0);

	int n = StrLen(c);
	if( n>255 ) n = 255;
	uchar* p = (uchar*)TempStr(n);
	*p=n;
	const uchar* e = p+*p;
	while (p<=e) *++p=*c++;
	return p-n-1;
}


/* ----	create blanked-out copy of string ------------------------------------------
		new: 2002-01-27 kio
*/
str WhiteStr ( cstr q, char c )
{
	str s = DupStr(q);
	for( uchar*p=(uchar*)s; *p; p++ ) if(*p>' ') *p=c;
	return s;
}


/* ----	create string from char ----------------------------------------------------
*/
str CharStr ( char c )
{
	str s = TempStr(1);
	*s = c;
	return s;
}


// ----	Replace any occurance of a character by another ----------------------------
str ReplacedStr ( cstr s, char old, char nju )
{
	str t = DupStr(s);
	for ( char* p=t; *p; p++ ) if (*p==old) *p=nju;
	return t;
}


// ----	Convert a string to all lower case -----------------------------------------
str LowerStr ( cstr s )
{
	str t = DupStr(s);
	ToLower(t);
	return t;
}


// ----	Convert a string to all upper case -----------------------------------------
str UpperStr ( cstr s )
{
	str t = DupStr(s);
	ToUpper(t);
	return t;
}


/* ----	Repeate string n times ------------------------------------ 22.aug.2001 ----
*/
char* MulStr ( cstr q, int n )
{
	if (q==NULL || *q==0 || n<=0) return emptystring;

	int len = strlen(q);
	str s   = TempStr(len*n);
	char* z = s;

//	while (n--) z = (char*)memcpy(z,q,len);			should work acc. to man page but doesn't
	while (n--) { memcpy(z,q,len); z+=len; }

	return s;
}


/* ----	Concatenate 2 strings ------------------------------------------------------
*/
char* CatStr ( cstr s1, cstr s2 )
{
	str s = TempStr(StrLen(s1)+StrLen(s2));
	s[0]=0;
	if (s1) strcpy ( s, s1 );
	if (s2) strcat ( s, s2 );
	return s;
}


/* ----	Concatenate up to 6 strings -------------------------------------------------
*/
char* CatStr ( cstr s1, cstr s2, cstr s3, cstr s4, cstr s5, cstr s6 )
{
	str s = TempStr( StrLen(s1)+StrLen(s2)+StrLen(s3)+StrLen(s4)+StrLen(s5)+StrLen(s6) );
	s[0]=0;
	if (s1) strcpy ( s, s1 );
	if (s2) strcat ( s, s2 );
	if (s3) strcat ( s, s3 );
	if (s4) strcat ( s, s4 );
	if (s5) strcat ( s, s5 );
	if (s6) strcat ( s, s6 );
	return s;
}


/* ----	Convert number to decimal string ----------
		the string is sized to fit (max. 12 char if sizeof(long)=4)
*/
char* NumStr ( int32 n )
{
	char* s = TempStr(1+sizeof(int32)*5/2);		// 2010-10-17		
	sprintf( s, "%i", n );
	return s;
}

char* NumStr ( uint32 n )						// 2010-10-17
{
	char* s = TempStr(sizeof(uint32)*5/2);
	sprintf( s, "%u", n );
	return s;
}

char* NumStr ( int64 n )						// 2010-12-04
{
	char* s = TempStr(1+sizeof(int64)*5/2);
	sprintf( s, "%lli", n );
	return s;
}

char* NumStr ( uint64 n )						// 2010-12-04
{
	char* s = TempStr(sizeof(uint64)*5/2);
	sprintf( s, "%llu", n );
	return s;
}


/* ----	Convert floating point number to decimal string ---------- kio 15.aug.2001 ----
		the string is sized to fit
*/
char* NumStr ( double d )
{
	char* s = TempStr(19);
	sprintf ( s, "%.14g", d );
	return s;
}
char* NumStr ( float32 d )
{
	char* s = TempStr(15);
	sprintf ( s, "%.10g", (double)d );
	return s;
}
char* NumStr ( long double d )
{
	char* s = TempStr(27);
	sprintf ( s, "%.22Lg", d );
	return s;
}


/* ----	Convert number to hexadecimal string ----------
*/
char* HexStr ( long n, int digits )
{
	static char hex[] = "0123456789ABCDEF";
	char* c = TempStr(digits);

	while(digits)
	{
		c[--digits] = hex[n&0x0f];
		n >>= 4;
	}
	return c;
}


/* ----	Convert number to binary string ---------- 2009-06-07
*/
str BinStr( int value, cstr b0, cstr b1 )
{
	uint n = strlen(b0); XXXASSERT( n==strlen(b1) );
	str s = TempStr(n); memcpy(s,b0,n);
	while(n--) { if(value&1) s[n]=b1[n]; value=value>>1; }
	return s;
}


/* ----	create string [a ... [e ----------------------  1.apr.00 kio
		does not check for 0-characters between a and e
*/
char* SubStr ( cstr a, cstr e )
{
	if (e<=a) return emptystring;
	char* c = TempStr(e-a);
	memcpy ( c, a, e-a );
	return c;
}


/* ----	create left substring ------------------------
		splits n bytes from the left
		if source string is shorter, the result is shorter too
*/
char* LeftStr ( cstr s, int n )
{
//	long m = StrLen(s); if (m<n) n=m;		<-- dangerous!
	const char*a=s; 		// kio 2.aug.2001
	const char*e=s+n;		// ""
	while (a<e&&*a) a++;	// ""
	n = a-s;				// ""

	if (n<=0) return emptystring;
	char* c = TempStr(n);
	memcpy ( c, s, n );
	return c;
}


/* ----	create right substring ------------------------
		splits n bytes from the right
		if source string is shorter, the result is shorter too
*/
char* RightStr ( cstr s, int n )
{
	long m = StrLen(s); if (m<n) n=m;
	if (n<=0) return emptystring;
	char* c = TempStr(n);
	memcpy ( c, s+m-n, n );
	return c;
}


/* ----	create mid substring ------------------------
		skip a bytes from the left then split n bytes
		if source string is shorter, the result is shorter too
*/
char* MidStr ( cstr s, int a, int n )
{
	if (a<0) { n+=a; a=0; }			// korr. 6.aug.2001 kio
	n = Min(n,StrLen(s)-a);
	if (n<=0) return emptystring;
//	return LeftStr(s+a,n);
	return SubStr(s+a,s+a+n);		// kio 2002-03-29
}


/* ----	create mid-to-end substring -------------------
		kio 2002-03-29
*/
char* MidStr ( cstr s, int a )
{
	if(!s) return emptystring;
	if (a<0) a=0;
	return SubStr(s+a,strchr(s,0));
}


/* ----	create formatted string ----------------------------------
		2002-01-26 kio	now using vsnprintf()
		2003-11-28 kio	now calling VaUsing() which calls vsnprintf()
*/
str Using ( cstr format, ... )
{
	va_list va;
	va_start(va,format);
	str s = VaUsing(format,va);
	va_end(va);
	return s;
}


/* ----	VaUsing() -----------------------
		2003-06-26 kio: hopefully fixed "va_list z = va;" problem
		2003-11-28 kio: hopefully fixed "va_copy" problem
		note: caller must call va_start() prior and va_end() afterwards.
*/
str VaUsing ( cstr format, va_list va )
{
	XXLogIn( "VaUsing()" );

/*	from the GNU autoconf manual:
	va_copy: The ISO C99 standard provides va_copy for copying va_list variables.
	It may be available in older environments too, though possibly as __va_copy
	(e.g., gcc in strict C89 mode). These can be tested with #ifdef.
	A fallback to memcpy (&dst, &src, sizeof(va_list)) will give maximum portability.

	va_list is not necessarily just a pointer.
	It can be a struct (e.g., gcc on Alpha), which means NULL is not portable.
	Or it can be an array (e.g., gcc in some PowerPC configurations),
	which means as a function parameter it can be effectively call-by-reference
	and library routines might modify the value back in the caller
	(e.g., vsnprintf in the GNU C Library 2.1).
*/
	int err = errno;							// save errno

	va_list va2;								// duplicate va_list
	va_copy(va2,va);
//	memcpy( &va2, &va, sizeof(va_list) );

	char bu[1];									
	int n = vsnprintf( bu, 0, format, va2 );	// calc. req. size

	str z = TempStr(n);							
	vsnprintf( z, n+1, format, va );			// create formatted string

	errno = err;								// restore errno
	return z;
}


/* ----	create beautified text for number ---------------------------
		from project vipsi
*/
str SpeakingNumber ( double n )
{
	if (n>=1000000000) return Using( "%7.3lf GB", n/1000000000 );
	if (n>=1000000   ) return Using( "%7.3lf MB", n/1000000 );
	if (n>=1000      ) return Using( "%7.3lf kB", n/1000 );
	                   return Using( "%4.0lf bytes", n );
}


/* ----	convert string ------------------------------
*/
static const char cc[] = "\\\"\e\a\b\f\n\r\t\v";	// control codes
static const char ec[] = "\\\"eabfnrtv";			// escape characters

static const char* StrComp(cstr a, cstr b)
{	char c,d;
	while((c=*a)&&(d=*b)&&c==d) {a++;b++; }
	return a;
}

str	ToHtml( cstr s0 )
{
	str  s;
	char c;
	int  i;
	char *z;

	if (!s0||!*s0) return emptystring;
	z = s = (str)s0;

	for ( i=0; (c=s[i]); i++ )
	{
		switch(c)
		{
		default: 	continue;
		case '<':	z = (str)"&lt;";   break;
		case '>':	z = (str)"&gt;";   break;
		case '&':	z = (str)"&amp;";  break;
		case '"':	z = (str)"&quot;"; break;		// 2002-07-30 kio: added
		case '\n':	z = (str)"<br>";   break;		// 2004-07-08 kio: added
		}
		s = CatStr( LeftStr(s,i), z, s+i+1 ); i+=3;
	}

	return s!=s0 ? s : DupStr(s0);
}

str	Escaped( cstr s0 )
{
	str  s;
	char const *q; 
	char *z;
	uchar uc;

	if (!s0||!*s0) return emptystring;
	z = s = (str)s0;

	while ( (uc=*z) )
	{
		if( uc>=' ' && uc!=0x7F && uc!='\\' && uc!='\"' ) { z++; continue; }
//		if( uc>=' ' && uc<0x7F && uc!='\\' && uc!='\"' ) { z++; continue; }
//		if( uc>=0x80&&UTF8CharValid(z)) { z=UTF8StrNextChar(z); continue; }

		if( (q=strchr(cc,uc)) )
		{
			uc = ec[q-cc];													// 2011-01-02 kio korr.
			q=s; s=CatStr( SubStr(s,z+1), z ); z+=s-q; *z++='\\'; *z++=uc;	// 2011-01-02 kio
			continue;
		}
		char oc[]="\\000";
		oc[1]='0'+(uc>>6); uc&=(1<<6)-1;
		oc[2]='0'+(uc>>3); uc&=(1<<3)-1;
		oc[3]='0'+(uc>>0);
		q=s; s=CatStr(SubStr(s,z),oc,z+1); z+=4+(s-q); continue;
	}

	return s!=s0 ? s : DupStr(s0);
}

str Quoted( cstr s )
{
	return CatStr( "\"", Escaped(s), "\"" );
}

str	Unescaped( cstr s0 )
{
	char c;
	char *q,*z;
	str  s;
	int  n;

	if(!s0||!*s0) return emptystring;
	s = DupStr(s0);

	q = z = strchr(s,'\\');

	if(q) for(;;)
	{
		while((c=*q++)!='\\') 
		{
			*z++ = c; 
			if(!c) return s; 
		}

		c = *q++;					// c = next char after '\' 
		if( (c-'0')&~7 )			// no octal digit
		{
			char const* p = strchr(ec,c);
			if(p)					// found control code
			{
				*z++ = cc[p-ec];
				if(!c) return s;	// 0->0 -> eot
			}
			else					// self-escaped char
			{
				*z++ = c; 
				if(c=='\n') for( c=*q; c<=' '&&c>0&&c!='\n'; q++ ) {}	// 2010-10-17 korr 2011-01-08
			}
		}
		else						// octal digit
		{
			n=c-'0';
			if (((c=*q++-'0')&~7)==0) { n=n*8+c; if (((c=*q++-'0')&~7)==0) n=n*8+c; else q--; } else q--;
			*z++ = n;
		}
	}
	return s;
}

str	Unquoted( cstr s0 )
{
	char c;
	char *q;
	str  s;
	int  n;

	if(!s0||!*s0) return emptystring;

	s = DupStr(s0);

	n=strlen(s);
	c=s[0];
	if( n>=2 && (c=='"'||c=='\'') && s[n-1]==c )
	{	//  backslashes zählen:  ist "abc\\\\\\\\" gequoted ?
		for (q=s+n-2;*q=='\\';q--) {}
		if( (n-(q-s))&1 ) { s++; q[1]=0; }
	}

	return s;
}

str	FromHtml( cstr s0 )
{
	char c;
	char *q,*z;
	str  s;

	if(!s0||!*s0) return emptystring;

	s = DupStr(s0);

	q = z = strchr(s,'&');

	if(q) for(;;)
	{
		while((c=*q++)!='&') { *z++=c; if(!c) return s; }
		if (*StrComp("gt;",  q)==0) { *z++ = '>'; q+=3; continue; }
		if (*StrComp("lt;",  q)==0) { *z++ = '<'; q+=3; continue; }
		if (*StrComp("amp;", q)==0) { *z++ = '&'; q+=4; continue; }		
		if (*StrComp("quot;",q)==0) { *z++ = '"'; q+=5; continue; }	// 2002-07-30 kio: added;  2008-05-12 kio: korr
		*z++='&';	// unquoted '&'
	}
	return s;
}


inline bool utf8_is_7bit( char c )	{ return c>=0; }
inline bool	utf8_no_7bit( char c )	{ return c<0;  }
inline bool utf8_is_fup	( char c )	{ return c<char(0xc0); }
inline bool utf8_no_fup	( char c )	{ return c>=char(0xc0); }


str FromUtf8Str( cstr qstr )		// 2011-03-16
{
	if(qstr==NULL||*qstr==0) return NULL;

	int	zlen = 0;					// golden rule: every non_fup makes a character!
	for(cptr q=qstr;*q;) zlen += utf8_no_fup(*q++);

	str	zstr = TempStr(zlen);
	cptr   q = qstr;
	ptr    z = zstr;
	uint8 c1,c2;

	while(*q)
	{
		if( utf8_is_7bit(c1=*q++) )					{ *z++ = c1; continue; }
		if( utf8_is_fup(c1) )						{ errno=unexpectedfup; continue; }
		if( *q==0||utf8_no_fup(c2=*q)||c1>=0xc4 )	{ *z++ = c1; errno=EOVERFLOW; continue; }
		q++; *z++ = (c1<<6) + (c2&0x3f);
	}
	return zstr;
}



str ToUtf8Str( cstr qstr )		// 2011-03-16
{
	if(qstr==NULL||*qstr==0) return NULL;

	int	zlen = 0;
	cptr q=qstr; while(*q) zlen += utf8_no_7bit(*q++); zlen += q-qstr; 
	str	zstr = TempStr(zlen);
	ptr z = zstr;
	q = qstr;

	while(*q)
	{
		uint c = *q++;
		if(utf8_is_7bit(c)) { *z++ = c; continue; }	// 7-bit ascii
		*z++ = 0xC0+(c>>6);		// 2-char utf8 code
		*z++ = 0x80+(c&0x3f);
	}
	return zstr;
}


/* ====	date&time =============================================
		note: time_t is always in UTC  (seconds since 1970-1-1 0:00 GMT)
*/
static uint next_number ( cuptr& c, cuptr e )
{
	uint  n = 0;
	while ( c<e && _no_dec_digit(*c) ) { c++; }
	while ( c<e && _is_dec_digit(*c) ) n = n*10 + *c++ -'0';
	return n;
}

time_t DateVal ( cstr date )
{	tm d;
	const uchar* c = (cuptr)date;
	const uchar* e = (cuptr)strchr(date,0);

	uint n = next_number(c,e);
	if (n<70) n+=2000; else if (n<100) n+=1900;
	d.tm_year = n-1900;

	d.tm_mon  = next_number(c,e) - 1;
	d.tm_mday = next_number(c,e);
	d.tm_hour = next_number(c,e);
	d.tm_min  = next_number(c,e);
	d.tm_sec  = next_number(c,e);

//	d.tm_wday   = 0;	output field
//	d.tm_yday   = 0;	""
	d.tm_isdst  = 0;	 
#if !defined(_SOLARIS)
	d.tm_gmtoff = 0;
	d.tm_zone   = NULL;
#endif

	return mktime(&d);	// local time
//	return timegm(&d);	// UTC
}


str DateTimeStr ( time_t secs )
{
	tm* dt = localtime(&secs);
	return dt ? Using( "%04u-%02u-%02u %02u:%02u:%02u", 
			    dt->tm_year+1900, dt->tm_mon+1, dt->tm_mday, dt->tm_hour, dt->tm_min, dt->tm_sec )
			  : CatStr("localtime: ",ErrorStr());
}

str DateStr ( time_t secs )
{
	tm* dt = localtime(&secs);
	return dt ? Using( "%04u-%02u-%02u", dt->tm_year+1900, dt->tm_mon+1, dt->tm_mday ) 
			  : CatStr("localtime: ",ErrorStr());;
}

str TimeStr ( time_t secs )
{
	tm* dt = localtime(&secs);
	return dt ? Using( "%02u:%02u:%02u", dt->tm_hour, dt->tm_min, dt->tm_sec )
			  : CatStr("localtime: ",ErrorStr());;
}

str DurationStr ( time_t secs )
{	uint s,m,h,d;
		
	s = secs;			if (s<=300)	return Using("%u sec.",          s);
	m = s/60; s = s%60; if (m<60)	return Using("%um:%us",        m,s);
	h = m/60; m = m%60;	if (h<24)	return Using("%uh:%um:%us",  h,m,s);
	d = h/24; h = h%24;				return Using("%ud:%uh:%um",d,h,m  );
}


str DurationStr ( double secs )		// 2010-10-16
{
	return secs>=60 ? DurationStr( (time_t)secs ) : Using( "%.3f sec.",secs );
}




#ifdef INCLUDE_DEPRECATED

char NextChar ( char const *& p )
{	char c;
	c = *p++; if (c!='\\') return c;	// plain char
	c = *p++;
	if( (c-'0')&~7 )					// no octal digit
	{
		cptr q = strchr(ec,c);
	 	if (c==0) p--;					// dont advance text pointer if "\" at end of text
		if (q) return cc[q-ec]; 		// control code
		return c;						// unkn. escape char / char escaped for unknown reason
	}
	else								// octal digit
	{
		uchar n = c-'0';
		if (((c=*p++-'0')&~7)==0) { n=n*8+c; if (((c=*p++-'0')&~7)==0) return n*8+c; }
		p--; return n;
	}
}


str ConvertedTo ( cstr s, strconvtype ctype )
{
	switch(ctype)
	{
	case str_noconv:	return NewCopy(s);
	case str_html:		return ToHtml(s);
	case str_escaped:	return Escaped(s);
	case str_quoted:	return Quoted(s);
	default:			IERR();
	}
}

str ConvertedFrom ( cstr s, strconvtype ctype )
{
	switch(ctype)
	{
	case str_noconv:	return NewCopy(s);
	case str_html:		return FromHtml(s);
	case str_escaped:	return Unescaped(s);
	case str_quoted:	return Unquoted(s);
	default:			IERR();
	}
}

#endif










