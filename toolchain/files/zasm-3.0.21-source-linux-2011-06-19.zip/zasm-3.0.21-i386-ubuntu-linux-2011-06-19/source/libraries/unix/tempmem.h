/*	Copyright  (c)	Günter Woigk 2008 - 2009
  					mailto:kio@little-bat.de

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.


	Temporary Memory Pool
	=====================

	Provide memory for temporary strings, e.g. for return values or in expressions.
	Any moderately-sized data which does not have a destructor can be stored in temp mem.
	
	• thread safe
	• pools can be nested
	• automatic pool creation


	Basic Usage
	-----------

	Temporary memory pools are created automatically for every thread.

	TempStr() and TempMem() retrieve memory from the pool:

	• allocation with TempStr(len) 
		• 1 byte for c-string delimiter is added and cleared to 0
		• string is not cleared, except delimiter
		• string is not aligned

	• allocation with TempMem(size) 
		• memory is aligned to a multiple of 4
		• memory is not cleared

	Purge all temporary memory of the current thread with PurgeTempMem().
	
	
	Nested Pools
	------------

	A function can create it's own, local pool. 
	Then all subsequent temp mem allocations come from this local pool
	until the pool is destroyed.

	• create a local instance of TempMemPool in the function body.
	
	• use TempStr() and TempMem() as usual: memory now comes from the new pool.

	• PurgeTempMem() purges only memory from the current pool.
	
	• when the function returns, the local TempMemPool instance is destroyed
	  and all temporary memory allocated since it's creation is released.

	• to return results from this function in temp mem, use TempXtStr() and TempXtMem(), 
	  which allocate memory in the surrounding TempMemPool.
	
	
	Accessing Pools Directly
	------------------------
	
	• if you have created a local pool, then you can use AllocStr(), AllocMem() and Purge() 
	  directly with this instance.
	  
	• TempMemPool::GetPool() retrieves and may create the current pool, it never returns NULL.

	• TempMemPool::GetXtPool() similarly retrieves and may create the current surrounding pool.
	
	
	Cave At
	-------
		
	TempMemPool uses a pthread_key. This is unique within the application, but may collide with 
	keys defined somewhere else. Basically this may be interrupt threads issued from the OS, 
	such as sound interrupts. Therefore you should define a local TempMemPool at each entry point
	of external threads into your application.


	Version
	-------

	2008		1.0		initial version (kio)
	2009-05-27	1.1		fixed bug in alignment for TempMemPool::AllocMem (kio)
*/


#ifndef tempmem_h
#define	tempmem_h

#include "kio/kio.h"


extern	char*		TempMem			( int size ) throw(bad_alloc);
extern	char*		TempStr			( int size ) throw(bad_alloc);

extern	char*		XtTempMem		( int size ) throw(bad_alloc);
extern	char*		XtTempStr		( int size ) throw(bad_alloc);

extern	void		PurgeTempMem	( );



/* #######################################################################
*/

struct TempMemData
{
	TempMemData*	prev;
	char			data[0];
};


class TempMemPool
{
	int				size;
	TempMemData*	data;
	TempMemPool*	prev;
	
					TempMemPool		( TempMemPool const& );			// prohibit
	void			operator=		( TempMemPool const& );			// prohibit
		
public:
					TempMemPool		( );
					~TempMemPool	( );
					
	void			Purge			( );
	char*			Alloc			( int size ) throw(bad_alloc);
	char*			AllocStr		( int len  ) throw(bad_alloc);	// 0-terminated
	char*			AllocMem		( int size ) throw(bad_alloc);	// 4-aligned

static TempMemPool*	GetPool			( )		throw(bad_alloc);
static TempMemPool*	GetXtPool		( )		throw(bad_alloc);
};



/* #######################################################################
*/

inline
char* TempMemPool::AllocStr ( int len ) throw(bad_alloc)
{
	char* p = Alloc(len+1);
	p[len] = 0;
	return p;
}


#endif





