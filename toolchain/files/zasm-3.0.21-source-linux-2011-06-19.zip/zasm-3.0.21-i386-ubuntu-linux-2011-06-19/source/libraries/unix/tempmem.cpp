/*	Copyright  (c)	Günter Woigk 2008 - 2009
  					mailto:kio@little-bat.de

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

 	Permission to use, copy, modify, distribute, and sell this software and
 	its documentation for any purpose is hereby granted without fee, provided
 	that the above copyright notice appear in all copies and that both that
 	copyright notice and this permission notice appear in supporting
 	documentation, and that the name of the copyright holder not be used
 	in advertising or publicity pertaining to distribution of the software
 	without specific, written prior permission.  The copyright holder makes no
 	representations about the suitability of this software for any purpose.
 	It is provided "as is" without express or implied warranty.

 	THE COPYRIGHT HOLDER DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 	EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 	CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 	DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 	TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 	PERFORMANCE OF THIS SOFTWARE.
*/


#define SAFE	3
#define LOG		0


#include <pthread.h>
#include "tempmem.h"
INIT_MSG

static pthread_key_t tempmem_key;			// key for per-thread TempMemPool


/* ----	Deallocate pool ----------------------
		called at thread termination 
		while pointer in tempmem_key is != NULL.
		This should happen only once, for
		the automatically created pool.
*/
static void deallocate_pool(void* pool)
{
	delete (TempMemPool*)pool;
}


/* ----	Initialization ---------------------------------
*/
static pthread_once_t once_control = PTHREAD_ONCE_INIT;
static volatile bool  virgin	   = 1;				// for faster init test

static void create_key(void)
{
	int err = pthread_key_create( &tempmem_key, deallocate_pool );
	if(err) Abort( "init TempMemPool: ", strerror(err) );
}

static void init ( )
{
	XLogIn("init TempMemPool");

// check assumptions:
	TRAP( (sizeof(TempMemData)&3) != 0 );
	ptr p1 = new char[17], p2 = new char[15]; 
	TRAP( uintptr_t(p1)&3 || uintptr_t(p2)&3 );
	delete[] p1; delete[] p2;

// initialize: get a pthread_key:
	int err = pthread_once( &once_control, create_key ); 
	XXXTRAP(err); 
	
	virgin = false;
}


/* ---- TempMemPool member functions --------------------
*/
TempMemPool::TempMemPool ( )
:	size(0),
	data(NULL)
{
	XXLogIn("new TempMemPool");
	
	if(virgin) init();

	prev = (TempMemPool*)pthread_getspecific( tempmem_key );
	XXXLogLine("  prev pool = %lx",(ulong)prev);
	XXXLogLine("  this pool = %lx",(ulong)this);
	//int err =
	pthread_setspecific( tempmem_key, this );				// may fail with ENOMEM (utmost unlikely)
	//if(err) { Abort("new TempMemPool: ",strerror(err)); }	// in which case this pool is not registered
}															// and GetPool() keeps using the outer pool


TempMemPool::~TempMemPool ( )
{
	XXLogIn("delete TempMemPool");
	XXXLogLine("  this pool = %lx",(ulong)this);
	XXXLogLine("  prev pool = %lx",(ulong)prev);

	Purge();
	int err = pthread_setspecific( tempmem_key, prev );		// may fail with ENOMEM (utmost unlikely)
	if(err) { Abort("delete TempMemPool: ",strerror(err)); }
}


void TempMemPool::Purge ( )				// Purge() == destroy + create pool
{
	XXLogIn("TempMemPool::Purge");
	XXXLog("  this pool = %lx ",(ulong)this);

	while( data!=NULL )
	{
		XXXLog(".");
		TempMemData* prev = data->prev;
		delete[] (char*)data; data = prev;
	}
	size = 0;
	XXXLogLine(" ok");
}


char* TempMemPool::Alloc ( int bytes ) throw(bad_alloc)
{
	if( bytes<=size )					// fits in current buffer?
	{
		size -= bytes; 
		return data->data + size;
	}
	else if( bytes<500 )				// small request?
	{
		TempMemData* newdata = (TempMemData*)new char[ sizeof(TempMemData) + 2000 ];
		XXXLogLine("tempmem new data = $%lx",(ulong)newdata);
		XXXASSERT( ((uintptr_t)newdata & 3) == 0 );
		newdata->prev = data;
		data = newdata;
		size = 2000-bytes;
		return newdata->data + size;
	}
	else								// large request
	{
		TempMemData* newdata = (TempMemData*)new char[ sizeof(TempMemData) + bytes ];
		XXXLogLine("tempmem new data = $%lx",(ulong)newdata);
		XXXASSERT( ((uintptr_t)newdata & 3) == 0 );
		if(data)
		{
			newdata->prev = data->prev;		// neuen Block 'unterheben'
			data->prev = newdata;
		}
		else
		{
			newdata->prev = NULL;
			data = newdata;
			size = 0;
		}
		return newdata->data;
	}
}


char* TempMemPool::AllocMem ( int bytes ) throw(bad_alloc)
{
	char* p = Alloc(bytes);
	if( data->prev && p == data->prev->data )	// wurde "large request" 'untergehoben' ?
	{
		return p;
	}
	else
	{
		int n = size&3;
		size -= n;
		return p-n;
	}
}


/* ---- Get the current temp mem pool -------------------------
		if there is no pool, then it is created.
*/
TempMemPool* TempMemPool::GetPool() throw(bad_alloc)
{
	if(virgin) init();
	TempMemPool* pool = (TempMemPool*)pthread_getspecific( tempmem_key );
	return pool ? pool : new TempMemPool(); 
}


/* ---- Get the surrounding temp mem pool -------------------------
		if there is no surrounding pool, then it is created.
		a 'current pool' should be in place, else 2 pools are created.
*/
TempMemPool* TempMemPool::GetXtPool() throw(bad_alloc)
{
	TempMemPool* pool = GetPool();
	TempMemPool* prev = pool->prev;
	if( !prev )
	{
		prev = new TempMemPool();					// automatically create 'outer' pool
		prev->prev = NULL;							// 'outer' pool 'unterheben'.
		pool->prev = prev;
		pthread_setspecific( tempmem_key, pool );	// aktuellen Pool erneut als 'aktuell' markieren
	}												// note: *might* fail with ENOMEM (utmost unlikely)
	return prev;									// in which case we keep on using the outer pool
}


/* ---- Get a temp cstring -------------------------
*/
char* TempStr ( int len ) throw(bad_alloc)
{
	return TempMemPool::GetPool()->AllocStr(len);
}


/* ---- Get a temp cstring -------------------------
		from the surrounding pool
*/
char* XtTempStr ( int len ) throw(bad_alloc)
{
	return TempMemPool::GetXtPool()->AllocStr(len);
}


/* ---- Get memory for temp. usage -------------------------
*/
char* TempMem ( int size ) throw(bad_alloc)
{
	return TempMemPool::GetPool()->AllocMem(size);
}


/* ---- Get memory for temp. usage -------------------------
		from the surrounding pool
*/
char* XtTempMem ( int size ) throw(bad_alloc)
{
	return TempMemPool::GetXtPool()->AllocMem(size);
}


/* ---- Purge current pool -------------------------
*/
void PurgeTempMem ( ) 
{
	TempMemPool::GetPool()->Purge(); 
}













