
// to be included in custom_errors.h:

EMAC( childterminatedbysignal,	"child terminated by signal" ),
EMAC( childreturnederror,		"child returned error" ),		
EMAC( datacorrupted,			"data corrupted" ),		
EMAC( wrongfiletype,			"wrong file type" ),		
