/*	Copyright  (c)	Günter Woigk 2001 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef file_utilities_h
#define	file_utilities_h

#include "kio/kio.h"

#ifdef  HAVE_SYS_DIRENT_H
#include <sys/dirent.h>
#endif

#ifdef  HAVE_DIRENT_H
#include <dirent.h>
#endif


typedef enum	// range: 0 .. 15
{
	s_none	= -1,
	s_unkn	= DT_UNKNOWN,		// 0
	s_any	= DT_UNKNOWN,		// 0	used for selecting files by type
	s_file	= DT_REG,
	s_dir	= DT_DIR,
	s_tty	= DT_CHR,
	s_pipe	= DT_FIFO,
	s_sock	= DT_SOCK,
	s_block	= DT_BLK,
	s_link	= DT_LNK,
#ifdef DT_WHT
	s_erased= DT_WHT,
#endif	
}
s_type;


/* universal methods:
*/
inline	s_type	ClassifyFile	( mode_t mode )							{ return s_type(mode>>12); }
extern	str		ModeStr			( mode_t );
extern	str		EffModeStr		( mode_t, gid_t, uid_t );
extern	cstr	Latin1			( cstr non_utf8_str );					// #define USE_LATIN1_PATH
 
extern	cstr	FilenameFromPath		( cstr path );
extern	cstr	ExtensionFromPath		( cstr path );
inline	str		ExtensionFromPath		( str  path )					{ return (str)ExtensionFromPath( (cstr)path ); }
extern	cstr	BasenameFromPath		( cstr path );
extern	cstr	DirectoryFromPath		( cstr path );
extern	cstr	LastComponentFromPath	( cstr path );

extern	void	ChangeWorkingDir( cstr path );
extern	cstr	WorkingDir		( );
extern	cstr	HomeDir			( );
extern	cstr	TempFileName	( cstr same_dir_as_file );				// renameable to 'file'
extern	cstr	QuickFullPath	( cstr path );							// just add workingdir or homedir 


// __________________________________________________________________
// PATH methods:
//
extern	s_type	ClassifyFile	( cstr path, bool resolve_last_symlink=1 );
inline	bool	IsFile			( cstr path, bool resolve_last_symlink=1 )	{ return ClassifyFile(path,resolve_last_symlink)==s_file; }
inline	bool	IsDir			( cstr path, bool resolve_last_symlink=1 )	{ return ClassifyFile(path,resolve_last_symlink)==s_dir; }
inline	bool	IsLink			( cstr path )								{ return ClassifyFile(path,no)==s_link; }
inline	bool	IsTTY			( cstr path )								{ return ClassifyFile(path)==s_tty; }

extern	time_t	FileMTime		( cstr path, bool resolve_last_symlink=1 );		// modification time
extern	time_t	FileATime		( cstr path, bool resolve_last_symlink=1 );		// last access time
extern	time_t	FileCTime		( cstr path, bool resolve_last_symlink=1 );		// last status change time

extern	off_t	FileLength		( cstr path, bool resolve_last_symlink=1 );		// returns -1 and sets errno on error

extern	str		FullPathToNode	(  str path, bool resolve_last_symlink=1, bool auto_create_path=no );
extern	str		FullPathToNode	( cstr path, bool resolve_last_symlink=1, bool auto_create_path=no );
extern	cstr	FullPath		( cstr path, bool resolve_last_symlink   );		// returns cstr in strPool

//extern void	RenameNode		( cstr oldname, cstr newname, bool overwrite, bool resolve_last_symlink, s_type typ=s_any );
extern	void	RenameNode		( cstr oldpath, cstr newpath, bool overwrite );
extern	void	DeleteNode		( cstr path, bool resolve_last_symlink, s_type typ=s_any );
extern	void	DeleteDir		( cstr dpath, bool fulltree=no );
extern	void	SwapFiles		( cstr path1, cstr path2 );

extern	void	CreateFile		( cstr path, int8 const* data, uint32 len, int how='w'/*overwrite*/, int mode=0660 );	
/*
extern	void	CreateFile		( cstr path, class Int8Array& data, cstr mode );	
extern	void	ReadFile		( cstr path, class Int8Array& data );
*/

// __________________________________________________________________
// Volumes, Directories, Links:
//
enum { vol_wprot=1, vol_ejectable=2, vol_mounted=4 };

extern	uint	VolumeFlags		( cstr path );
extern	double	VolumeFree		( cstr path );
//		void	GetVolumeInfo	( Var& v );		TODO

//extern void	CreateDir		( cstr path, cstr mode );
extern	void	CreateDir		( cstr path, int mode=0777 );
extern	void	CreatePipe		( cstr path, int mode=0660 );
extern	void	ReadDir			( cstr path, class StrArray& v );	

//extern void	CreateLink		( cstr path, cstr data, cstr mode );
extern	void	CreateLink		( cstr path, cstr data );
extern	void	ReadLink		( cstr path, str& data );



// __________________________________________________________________
// FD methods:
//

extern	s_type	ClassifyFile	( int fd );

extern	void	SetBlocking		( int fd, bool onoff );
extern	void	SetAsync		( int fd, bool onoff );

extern	time_t	FileMTime		( int fd );			// modification time
extern	time_t	FileATime		( int fd );			// last access time
extern	time_t	FileCTime		( int fd );			// last status change time

extern	off_t	FileLength		( int fd );			// returns -1 and sets errno on error

extern	int		NewTempFile		();					// create & open temp file in /tmp/

extern	int		TerminalSize	( int tty, int& rows, int& cols );
extern	int		TerminalRows	( int tty );
extern	int		TerminalCols	( int tty );
extern	int		TerminalWidth	( int tty );		// pixel
extern	int		TerminalHeight	( int tty );		// pixel
extern	int		SetTerminalSize	( int tty, int rows, int cols );		// does not work !?



#endif


