/*	Copyright  (c)	Günter Woigk 2001 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	2003-08-15 kio	fixed buggy call to ioctl() in SetBlocking() and SetAsync()
	2003-10-09 kio	FullPath(): enhanced to match broken utf-8 filenames
	2004-05-07 kio	FullPath(): added buffer overflow check for initial rpath assembly
	2004-05-08 kio	FullPath(): returned path now has a trailing "/" for a deref'ed, existing directory
	2004-06-11 kio	FullPath(): Bug: always overwrote n.ex. path components with latin1
	2007-02-14 kio	NewTempFile(), DupFile(), filecopy(), lots of new file i/o functions.
*/

#define	SAFE	2
#define	LOG		1

#include	<unistd.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	<sys/param.h>
#include	<sys/fcntl.h>
#include	<sys/ioctl.h>
#include	<sys/stat.h>
#include	<sys/termios.h>
#include	<new>
#include	<sys/mount.h>
#include	<dirent.h>
#ifdef HAVE_SYS_VFS_H
#include	<sys/vfs.h>
#endif

#include	"tempmem.h"
#include	"file_utilities.h"
INIT_MSG


#if !defined(_POSIX_SOURCE) && !defined(_SOLARIS)
	#define M_TIME(TS) ((TS).st_mtimespec.tv_sec)
	#define A_TIME(TS) ((TS).st_atimespec.tv_sec)
	#define C_TIME(TS) ((TS).st_ctimespec.tv_sec)
#else
	#define M_TIME(TS) ((TS).st_mtime /* +(TS).st_mtimesec/1e9 */)
	#define A_TIME(TS) ((TS).st_atime /* +(TS).st_atimesec/1e9 */)
	#define C_TIME(TS) ((TS).st_ctime /* +(TS).st_ctimesec/1e9 */)
#endif


/* ========================================================
			universal methods
   ===================================================== */

// these shall bummer if assumptions fail:
#ifndef _LINUX
#define	S_IFMT		0170000		/* [XSI] type of file mask */
#define	S_IFIFO		0010000		/* [XSI] named pipe (fifo) */
#define	S_IFCHR		0020000		/* [XSI] character special */
#define	S_IFDIR		0040000		/* [XSI] directory */
#define	S_IFBLK		0060000		/* [XSI] block special */
#define	S_IFREG		0100000		/* [XSI] regular */
#define	S_IFLNK		0120000		/* [XSI] symbolic link */
#define	S_IFSOCK	0140000		/* [XSI] socket */
#ifdef  S_IFWHT
#define	S_IFWHT		0160000		/* whiteout */
#endif
#define	DT_UNKNOWN	 0
#define	DT_FIFO		 1
#define	DT_CHR		 2
#define	DT_DIR		 4
#define	DT_BLK		 6
#define	DT_REG		 8
#define	DT_LNK		10
#define	DT_SOCK		12
#define	DT_WHT		14
#endif

/* 	
s_type ClassifyFile ( mode_t mode )
{
	if (S_ISREG (mode)) return s_file;  else	// File
	if (S_ISFIFO(mode)) return s_pipe;  else	// Pipe
	if (S_ISDIR (mode)) return s_dir;   else	// Directory
	if (S_ISBLK (mode)) return s_block; else	// Block device
	if (S_ISSOCK(mode)) return s_sock;  else	// Socket
	if (S_ISLNK (mode)) return s_link;  else	// Symbolic link
	if (S_ISCHR (mode)) return s_tty;   else	// Character special
#ifdef S_ISWHT
	if (S_ISWHT (mode)) return s_null;  else	// White out
#endif
	return s_unkn;
}
*/

str ModeStr ( mode_t mode )
{
	char r[]="-r";
	char w[]="-w";
	char x[]="-x";
	char s[]="rwxrwxrwx";
	s[0] = r[(mode&S_IRUSR)!=0];
	s[1] = w[(mode&S_IWUSR)!=0];
	s[2] = x[(mode&S_IXUSR)!=0];
	s[3] = r[(mode&S_IRGRP)!=0];
	s[4] = w[(mode&S_IWGRP)!=0];
	s[5] = x[(mode&S_IXGRP)!=0];
	s[6] = r[(mode&S_IROTH)!=0];
	s[7] = w[(mode&S_IWOTH)!=0];
	s[8] = x[(mode&S_IXOTH)!=0];
	cstr z = mode&S_ISUID ? "u" : mode&S_ISGID ? "g" : "-";
	return CatStr(z,s); 
}

str EffModeStr ( mode_t mode, gid_t file_grp, uid_t file_usr )
{
	gid_t g = getegid();
	uid_t u = geteuid();
	cstr  z = mode&S_ISUID ? "u" : mode&S_ISGID ? "g" : "-";

// mix bits to 'other' bits:
	if (g==file_grp) mode |= (mode>>3);
	if (u==file_usr) mode |= (mode>>6);
	if (u==0)        mode |= (mode>>6);		// prüfen: ist root==0?

	char r[]="-r";
	char w[]="-w";
	char x[]="-x";
	char s[]="rwx";
	s[0] = r[(mode&S_IROTH)!=0];
	s[1] = w[(mode&S_IWOTH)!=0];
	s[2] = x[(mode&S_IXOTH)!=0];
	return CatStr(z,s);
}

#ifdef USE_LATIN1_PATH
/* ----	convert filename to latin-1 ------------------------- [rewritten: kio 2004-05-10]

		normally when searching a directory for a given filename, we expect both,
		the filename to search and the filenames in the directory, to have the same encoding.

		if both use utf-8 or both use the same 8-bit character set everything is fine.
		even if both use _different_ 8-bit character sets, the application can at least
		access all files, even if the filenames displayed may look weird.

		but if our application internally uses UCS2 or UCS4 encoded strings (unicode)
		then it will convert filenames to utf-8 encoded c-style strings to access the files.

		valid utf-8 strings can not express all arbitrary 8-bit character sequences.
		thus this way some 8-bit character set filenames not only display strange
		but also become completely unreachable for the application.

		Latin1() implements a quirk to find iso-latin-1 encoded filenames in a directory
		which correspond to a utf-8 encoded filename.

	howto:
		1. match your filename against all filenames in the directory of interest without quirks.
		2. if you don't find a match, try to match against Latin1(filename) as a second shot.

	returns:
		returns iso-latin-1 encoded filename or
		returns NULL if conversion did not result in a different filename
*/
cstr Latin1 ( cstr filename )
{
// does filename contain non-Ascii letters?
// if not, then there is no difference between utf-8 and latin-1 --> quick exit
	cptr q = filename;
	for(;;)
	{
		char c = *q++;
		if(c>0)  continue;
		if(c==0) return NULL;				// no non-ascii letters found
		else	 break;						// non-acii letter found
	}

// convert filename to iso-latin-1:
// if filename contains utf-8 character codes >= 256 --> give up
// if filename contains broken utf-8 itself --> give up
// if filename contains illegal overlong encoding --> give up
	while(*q) q++;							// find string end
	str file = TempStr(q-filename);			// temp string
	ptr z = file;
	q = filename;
	for(;;)
	{
		char c = *q++;
		if (c>0)  { *z++ = c; continue; }
		if (c==0) { *z=0; break; }			// conversion utf-8 -> latin-1 complete
	// 2 byte codes:	110xxxxx 10xxxxxx
	// ill. overlong:	1100000x 10xxxxxx
	// latin-1 range:	1100001x 10xxxxxx
		if ((c&0xFE)!=0xC2) return NULL;	// char code too high, ill. overlong encoding or broken utf-8
		uchar c2 = *q++ - 0x80;
		if (c2>=0x3F) return NULL;			// no fup -> broken utf-8
		*z++ = (c<<6) + c2;					// combine c1 + fup
	}

// the resulting latin-1 string may also be a valid utf-8 string again!
// if so, we must not return it:
//
// if we used it, and it actually is an ordinary utf-8 filename,
//		then we access and manipulate wrong files:
//		e.g. we try to delete all files "XY" and unexpectedly also delete all files "Z".
// if we don't use it, though it really is a latin-1 filename,
//		then it is still accessible by the application
//		though it probaly will have a weird filename
//		which even may contain exotic characters which your display font does not provide
//		therefore showing up as the 'character replacement char', frequently a square box.
//
// so using it is dangerous, not using it is just ugly.
// therefore we assert that the converted filename is invalid utf-8 and discard it otherwise.
//
// routine adopted from:
// 		static UCS4Char* ucs4_from_utf8 ( UCS4Char*z, cUTF8CharPtr a, cUTF8CharPtr e, bool latin_1 )
// 		in lib-kio/ustring/sstring.cp
// 		re-implemented to avoid dependency on class String.
	z = file;
	for (;;)
	{
		ulong c0 = uchar(*z++);
		if ((char)c0>0) continue;					// ascii
		if (c0==0) return NULL;						// end of filename reached without invalid utf-8
		if ((char)c0 < (char)0xc0) return file;		// unexpected fups
		if (c0>=0xfe) return file;					// ill. codes

	// parse multi-byte character:
		ulong n = 0;		// UCS-4 char code akku
		uint  i = 0;		// UTF-8 character size

		while( c0 & (0x80u>>(++i)) )
		{
			ulong c1 = uchar(*z++);
			if ((char)c1 >= (char)0xc0) return file;// no fup: truncated char (end of text or non-fup)
			n = (n<<6) + (c1&0x3F);
		}

	// now: i = total number of digits
	//      n = UCS4 char code without c0 bits
		n += (c0&(0x7f>>i)) << (6*i-6);				// n := UCS4 char code

	// test for ill. overlong encoding:
		if ( n < (1u<<(i*5-4)) ) return file;		// ill. overlong encoding
	}
}
#endif

/* ----	separate filename from path ---------------------------------------
		returned string points into passed path argument  ((guaranteed!))
		returned string is empty if path ended with '/'
*/
cstr FilenameFromPath ( cstr path )
{
	XXTRAP(!path);
	cstr p = strrchr(path,'/');
	return p ? p+1 : path;
}

/* ----	separate filename or last directory from path ---------------------
		returned string points into passed path argument  ((guaranteed!))
*/
cstr LastComponentFromPath ( cstr path )
{
	XXTRAP(!path);
	cstr p = strchr(path,0) -2;
	while( p>=path && *p!='/' ) { p--; }
	return p>=path ? p+1 : path;
}

/* ----	separate filename extension from path -----------------------------
		returned string points into passed path argument  ((guaranteed!))
		returned strings includes '.'
		if path has no valid extension, then the returned string points to chr(0) at end of path
*/
cstr ExtensionFromPath ( cstr path )
{
	path = FilenameFromPath(path);
	cstr dot = strrchr(path,'.');
	cstr spc = strrchr(path,' ');
	if( dot>spc ) return dot; else return strchr(path,0);
}

/* ----	separate filename basename from path ------------------------------
		returns string in cstring pool
*/
cstr BasenameFromPath ( cstr path )
{
	path = FilenameFromPath(path);
	return SubStr( path, ExtensionFromPath(path) );
}

/* ----	separate directory path from path ------------------------------
		returns string in cstring pool
		returned string includes final '/'
		returns "./" instead of "" if passed path contains no '/'
*/
cstr DirectoryFromPath ( cstr path )
{
	path = SubStr( path, FilenameFromPath(path) );
	return *path ? path : "./";
}

/* ----	working directory --------------------------------------
*/
void ChangeWorkingDir( cstr path )
{
	ClearError();
	if(!path||!*path)       { errno=ENOTDIR; return; }
	if(LastChar(path)!='/') { errno=ENOTDIR; return; }
	chdir(path); if(errno==ok) return;
	path = FullPathToNode(path);
	if(errno==ok) chdir(path);	// will probably fail again
}

cstr WorkingDir()
{
	for ( ulong n=0x80; n<0x10000; n*=2 )
	{
		str s = getcwd ( TempStr(n), n );
		if (s) return s;
	}	
	return "/";		// errno = erange  set by getcwd()
}

cstr HomeDir()		// may be NULL
{
	return getenv("HOME");
}

cstr QuickFullPath( cstr path )
{
	if(path[0]=='~' && path[1]=='/') { cstr h=HomeDir(); if(h) path = CatStr(h,path+1); }
	if(path[0]!='/')				 { path = CatStr(WorkingDir(),"/",path); }
	return path;
}

/* ----	provide a temp file name --------------
		temp file must be renameable to 'file'.
*/
cstr TempFileName( cstr file )
{
	XXXASSERT( file!=NULL );
	
	if(file[0]!='/') file=QuickFullPath(file);
	return CatStr(file,".temp");
}


/*	create temp file in $TMPDIR or "/tmp/"
	opens file for r/w by the calling user.
	unlinks file so that it will vanish after close().
	returns fd on success.
	returns -1 if creating file fails. errno set.
*/
int NewTempFile()
{
	cstr tmpdir = getenv("TMPDIR");
  //if (!tmpdir) tmpdir = P_tmpdir;		strongly discouraged! - uses setting from compiling system - not the running one!
	
	for(;;)
	{
		cstr path = CatStr( tmpdir?tmpdir:"/tmp/", HexStr(random(),8) );
		int  fd   = open( path, O_RDWR|O_CREAT|O_EXCL, 0600 );
		if (fd>=0) { unlink(path); return fd; }		// opened ok
		if (errno==EEXIST) continue;				// exists => retry
		if (tmpdir) { tmpdir = NULL; continue; }	// maybe $TMPDIR is broken
		return -1;									// can't create temp file!
	}
}









/* ========================================================
			volume flags
   ===================================================== */
#ifndef _LINUX
uint VolumeFlags ( cstr path )
{
	ClearError();

	struct statfs fs;
	int n = statfs(FullPathToNode(path,1),&fs);
	if (n) return vol_wprot;	// error: errno set

	uint rval = 0;
	if( fs.f_flags & MNT_RDONLY								  ) rval |= vol_wprot;
	if( (fs.f_flags & MNT_NOSUID) && (fs.f_flags & MNT_NODEV) ) rval |= vol_ejectable;
	if( fs.f_blocks>0										  ) rval |= vol_mounted;	
	return rval;
}

double VolumeFree ( cstr path )
{
	ClearError();

	struct statfs fs;
	int n = statfs(FullPathToNode(path,1),&fs);
	if(n) return 0;		// errno set
	return (double)fs.f_bsize * (double)fs.f_bavail;
}
#endif












/* ---- set/clear blocking io -----------
		=> errno EAGAIN wenn input empty/output full
*/
void SetBlocking ( int fd, bool onoff )
{
	int arg = fcntl(fd,F_GETFL,&arg);
	if (arg==-1) return; // errno set
	if (onoff) arg &= ~O_NONBLOCK; else arg |= O_NONBLOCK;
	fcntl(fd,F_SETFL,arg);
}

/* ----	set/clear async io mode ----------
		=> signal SIGIO wenn input available/output possible
		***???*** lt. dt. man page geht das mit fcntl() nicht!
		***!!!*** lt. engl. man page geht es.
*/
void SetAsync ( int fd, bool onoff )
{
	int arg = fcntl(fd,F_GETFL,&arg);
	if (arg==-1) return; // errno set
	if (onoff) arg |= O_ASYNC; else arg &= ~O_ASYNC;
	fcntl(fd,F_SETFL,arg);
}




/* ---- stat() file --------------------------------
*/
static int stat ( cstr path, struct stat* buf, bool follow_symlink )
{
	return follow_symlink ? stat(path,buf) : lstat(path,buf);
}


/* ---- modification date of file ------------------
*/
time_t FileMTime ( cstr path, bool follow_symlink )
{
	struct stat fs;
	stat(path,&fs,follow_symlink);
	return M_TIME(fs);
}


/* ---- last access date of file ------------------
*/
time_t FileATime ( cstr path, bool follow_symlink )
{
	struct stat fs;
	stat(path,&fs,follow_symlink);
	return A_TIME(fs);
}


/* ---- last status change time of file ------------------
*/
time_t FileCTime ( cstr path, bool follow_symlink )
{
	struct stat fs;
	stat(path,&fs,follow_symlink);
	return C_TIME(fs);
}


/* ---- modification date of file ------------------
*/
time_t FileMTime ( int fd )
{
	struct stat fs;
	fstat(fd,&fs);
	return M_TIME(fs);
}


/* ---- last access date of file ------------------
*/
time_t FileATime ( int fd )
{
	struct stat fs;
	fstat(fd,&fs);
	return A_TIME(fs);
}


/* ---- last status change time of file ------------------
*/
time_t FileCTime ( int fd )
{
	struct stat fs;
	fstat(fd,&fs);
	return C_TIME(fs);
}



s_type ClassifyFile ( cstr path, bool follow_symlink )
{
	if (!path) path="";		// --> ENOENT
	struct stat fs;
	if( stat(path,&fs,follow_symlink) ) return s_none;		// errno set!
	else return ClassifyFile(fs.st_mode);
}


s_type ClassifyFile ( int fd )
{
//	if (fd<0) return s_none;	--> EBADF
	struct stat data;
	if (fstat(fd, &data)) return s_none;
	else return ClassifyFile(data.st_mode);
}


off_t FileLength ( cstr path, bool follow_symlink )
{
	struct stat fs;
	if (!path||!*path) return -1;
	if (stat(path,&fs,follow_symlink)) return -1;	// error
	return fs.st_size;
}

off_t FileLength ( int fd )
{
	struct stat fs;
	if (fstat(fd,&fs)) return -1;			// error
	return fs.st_size;
}



/* ---- real path ----------------------------------
		resolve partial paths
		resolve stuff like "//" and "./" and "../"
		resolve home directory
		resolve symbolic links
		resolve broken utf-8 filenames  ((option))
		no error for not present final path component
		=> assume directory/file will be created
		returned path has a trailing "/" for an existing, deref'ed directory
		errno: clears or sets errno, prepends offending subpath to errormsg

		returned path is temp only, allocated in tempmem pool (--> cstrings.cp)

		2004-05-07 kio	added buffer overflow check for initial rpath assembly
*/
cstr FullPath( cstr path, bool follow_symlink )
{
	const int bu_size = MAXPATHLEN+255;
	char bu[bu_size+1];

	int lc = 33;				// link counter -> detect recursion

	ptr k1, lpath, l_end, rpath, r_end;
	lpath = l_end = bu;
	rpath = r_end = bu +bu_size;

	// sanity check:
	if (!path||!*path) path = ".";

	// copy path to right side of buffer:
	rpath -= strlen(path);
	if ( rpath <= l_end ) { ForceError(ENAMETOOLONG); goto x; }
	memcpy ( rpath, path, r_end-rpath );

	// path starts with '~'  -->  prepend home directory
	if( rpath[0]=='~' && (r_end-rpath==1||rpath[1]=='/') && (k1=getenv("HOME")) && k1[0]=='/' )
	{
		rpath++;				// discard "~".
								// after that a "/" or str_end is assured by above tests
		int n = strlen(k1);
		rpath -= n;
		if ( rpath <= l_end ) { ForceError(ENAMETOOLONG); goto x; }
		memcpy ( rpath, k1, n );
	}

	// not an absolute path  -->  prepend local directory
	else if( rpath[0]!='/' )
	{
		k1 = getcwd(bu,bu_size);
		XXTRAP(k1!=bu);
		XXTRAP(k1[0]!='/');

		memcpy ( rpath, path, r_end-rpath );	// <-- copy again: MacOSX/Darwin garbages whole buffer!
		*--rpath = '/';
		int n = strlen(k1);
		rpath -= n;
		if ( rpath <= l_end ) { ForceError(ENAMETOOLONG); goto x; }
		memmove( rpath, k1, n );
	}


// *** doit ***

/*	note:

	bu: [==================================================================]
	    [lpath........l_end        ..unused..         rpath...........r_end]

		lpath  is already checked & deref'ed
		rpath  is not yet checked & deref'ed
*/

	for(;;)
	{
		ClearError();

	// left side path _is_ a checked & deref'ed directory path:
		if( l_end==lpath || l_end[-1]!='/' ) *l_end++ = '/';

	// finished ?
		if( rpath>=r_end )  break;

	// split k1 from rpath
		k1 = l_end;					// move current component w/o trailing '/' from rpath to lpath
		while(rpath<r_end&&*rpath!='/') { *l_end++ = *rpath++; }
		if(rpath<r_end) rpath++; 	// rpath = "remaining/rpath"

	// handle k1:

	// discard "//"
		if (k1+0==l_end) continue;

	// discard "./"
		if (k1+1==l_end&&k1[0]=='.') { l_end = k1; continue; }

	// "../" -> backup one directory
		if( k1+2==l_end && k1[0]=='.' && k1[1]=='.' )
		{
			for( l_end=k1-1; l_end>lpath&&l_end[-1]!='/'; ) { l_end--; }
			continue;
		}

	// does path component exist?
		struct stat statdata;
		*l_end=0;
		lstat(lpath,&statdata);
		if(errno)
		{
			#ifdef USE_LATIN1_PATH
				if ( errno==ENOENT )
				{
					cstr k2 = Latin1(k1);	// try iso-latin-1
					if (k2)
					{
						XXASSERT(strlen(k2) < size_t(l_end-k1)); 	// strlen(latin1) < strlen(utf8)
						str latin1path = new char[l_end-lpath];
						memcpy(latin1path,lpath,k1-lpath);
						strcpy(latin1path+(k1-lpath),k2);
						ClearError();
						lstat(latin1path,&statdata);
						if (NoError())	// success! => latin1 übernehmen
						{				// copy text & update l_end
							for( l_end=k1; *k2; ) { *l_end++ = *k2++; }
						}
						delete[] latin1path;
					}
				}
			#endif
			if(errno)
			{
				if( errno==ENOENT && rpath==r_end )
				{
					ClearError();		// no error if final path component not found
				}
				break;
			}
		}

	// handle directory:
		if( S_ISDIR(statdata.st_mode) )
		{
			continue;
		}

	// handle link:
		if( S_ISLNK(statdata.st_mode) && (rpath<r_end || follow_symlink) )
		{
			if (--lc==0) { ForceError(ELOOP); break; }
			int n = readlink( lpath, l_end, rpath-l_end-1 );
			if (n<0) { ForceError(ENAMETOOLONG); break; }
			if (n==0) { l_end = k1; continue; }
			if (rpath<r_end) *--rpath='/';
			rpath -= n;
			XXTRAP(rpath<l_end);
			memmove( rpath, l_end, n );
			l_end = *rpath=='/' ? lpath : k1;
			continue;
		}

	// handle regular file ((or pipe et.al.))
		if( rpath<r_end ) ForceError(ENOTDIR);
		break;
	}


	XXTRAP( l_end == lpath );
	path = SubStr(lpath,l_end);
x:	if (errno) ForceError( Using("%s: %s",Quoted(path),ErrorStr()) );
	return path;
}


// ioctl -> tty control
// tcgetattr/tcsetattr -> tty control

int TerminalSize ( int tty, int& rows, int& cols )
{
	struct winsize data;
	data.ws_row = (short)-1;
	data.ws_col = (short)-1;
	int r = ioctl ( tty, TIOCGWINSZ, &data );
	rows = (short)data.ws_row;
	cols = (short)data.ws_col;
	return r;
}

int TerminalRows ( int tty )
{
	struct winsize data;
	data.ws_row = (short)-1;
	ioctl ( tty, TIOCGWINSZ, &data );
	return (short)data.ws_row;
}

int TerminalCols ( int tty )
{
	struct winsize data;
	data.ws_col = (short)-1;
	ioctl ( tty, TIOCGWINSZ, &data );
	return (short)data.ws_col;
}

int TerminalWidth ( int tty )
{
	struct winsize data;
	data.ws_xpixel = (short)-1;
	ioctl ( tty, TIOCGWINSZ, &data );
	return (short)data.ws_xpixel;
}

int TerminalHeight ( int tty )
{
	struct winsize data;
	data.ws_ypixel = (short)-1;
	ioctl ( tty, TIOCGWINSZ, &data );
	return (short)data.ws_ypixel;
}


/* note: does not work.
*/
int SetTerminalSize(int tty, int rows, int cols )
{
	struct winsize data;
	int r = ioctl ( tty, TIOCGWINSZ, &data ); 
	if(r!=-1)
	{
		data.ws_xpixel = data.ws_xpixel/data.ws_col*cols;		// superfluxous
		data.ws_ypixel = data.ws_ypixel/data.ws_row*rows;		// superfluxous
		data.ws_row    = rows;
		data.ws_col    = cols;
		r = ioctl ( tty, TIOCSWINSZ, &data );
	}
	return r;
}






/* ---- real path ----------------------------------

		resolve partial paths
		resolve "//" and "./" and "../"
		resolve ~
		resolve symbolic links
		resolve non-utf-8 filenames

		returns temp str in tempmem pool 
		errno: cleared or set to error

	on success:		
		if the input path ends with "/", then the returned path always refers to a directory.
		if the returned path refers (not) to a directory it always ends (not) on a "/".

	on error:
		ENOTDIR		encountered non-directory:		path -> node (file, symlink, ...)
		ELOOP		infinite symlink loop:			path -> symlink
		ENOENT		last component does not exist	path = path suitable for creation.
*/
str FullPathToNode( str path, bool resolve_last_symlink, bool auto_create_path )
{
	ClearError();

	// sanity:
	if (!path||!*path) { errno=ENOTDIR; return DupStr(""); }

	// path starts with '~'  -->  prepend home directory
	if( path[0]=='~' && (path[1]==0||path[1]=='/') )
	{
		cstr home = getenv("HOME");
		if(home) path = CatStr(home,path+1);
	}

	// not an absolute path  -->  prepend local directory
	if( path[0]!='/' )
	{
		char bu[MAXPATHLEN];
		cstr wd = getcwd(bu,MAXPATHLEN);
		if(!wd) { if(errno==ENOENT) errno=ENOTDIR; return path; }	// failed. errno set
		XXXASSERT(wd[0]=='/');
		path = LastChar(wd)!='/' ? CatStr(wd,"/",path) : CatStr(wd,path);
	}

	int lc = 33;		// link counter -> detect recursion
	int i  = 0;			// path[i] = "/";  path[0..i] = checked
	int j;				// path[j] = next "/"
	ptr p;				// p -> next "/"
	char c;				// c = *p
	
// loop over existing directories:

	for(;;)
	{
		p = strchr(path+i+1,'/');
 
		if(p)		// path component:		check for // ./ and ../
		{
			j = p-path;		// j=index of next '/'
			
		// discard "//"
			if(j==i+1) { memmove(p,p+1,strlen(p)); continue; }
			
		// discard "./"
			if(j==i+2 && path[i+1]=='.') { memmove(p-1,p+1,strlen(p)); continue; }

		// "../" -> backup one directory
			if( j==i+3 && path[i+1]=='.' && path[i+2]=='.' )
			{
				if(i==0) { errno=ENOTDIR; return path; }	// for security reasons: fail!
				do{i--;}while(path[i]!='/');
				memmove(path+i,p,strlen(p)+1); continue; 
			}
		}
		else		// final component:		check for . and ..
		{
			p = strchr(path+i,0);
			j = p-path;
			if(j==i+1) return path;							// path ends on "/"
			if(j==i+2 && path[i+1]=='.') { path[i+1]=0; return path; }	// path ended on "/."
			if(j==i+3 && path[i+1]=='.' && path[i+2]=='.')	// path ended on "/.."
			{
				if(i==0) { errno=ENOTDIR; return path; }	// for security reasons: fail!
				do{i--;}while(path[i]!='/');
				path[i+1]=0; return path; 
			}
		}
		
	// temporarily truncate path at "/" (or final 0):
		c = *p;		// c = 0 or '/'	
		*p = 0;
		
	// does path component exist?		
		struct stat statdata;
		errno = ok;
		lstat(path,&statdata); 

		if(errno)
		{
			if(errno!=ENOENT) return path;			// other error

#ifdef USE_LATIN1_PATH
			cstr l1path = Latin1(path+i);			// try iso-latin-1
			if (l1path)								// second chance:
			{
				path[i]=0; l1path = CatStr(path,l1path); path[i]='/'; 
				errno=ok; lstat(l1path,&statdata);	// success? => use latin1 path
				if(errno==ok) { *p=c; path = CatStr(l1path,p); continue; }
			}
			if(errno==ENOENT) 
#endif
			{
				if(c==0) return path;				// final component
				if(!auto_create_path) { errno=ENOTDIR; return path; }	
				errno=ok; mkdir(path,0777);
				if(errno) { if(errno==ENOENT) errno=ENOTDIR; return path; }
				i=j; *p=c; continue;
			}
		}

	// handle directory:
		if(S_ISDIR(statdata.st_mode)) if(c) { i=j; *p=c; continue; } else { return CatStr(path,"/"); }

	// handle link:
		if(S_ISLNK(statdata.st_mode))
		{
			if(c==0 && !resolve_last_symlink) return path;	// path resolves to symlink
			if (--lc==0) { errno=ELOOP; return path; }		// too many recursions
			char bu[MAXPATHLEN+1];
			int n = readlink( path, bu, MAXPATHLEN ); 
			if (n<0) { if(errno==ENOENT) errno=ENOTDIR; return path; }	// error
			bu[n]=0; *p=c;
			if(bu[0]=='/') { path=CatStr(bu,p); i=0; continue; }
			else { path[i+1]=0; path=CatStr(path,bu,p); continue; }
		}

	// handle regular file ((or pipe et.al.))
		if(c) errno=ENOTDIR; 
		return path;
	}	
}

str FullPathToNode( cstr path, bool resolve_last_symlink, bool auto_create_path )
{
	return FullPathToNode( DupStr(path), resolve_last_symlink, auto_create_path );
}


/* ----	rename link, file or folder -----------------------------------------
		auto-creates newpath
		if oldpath is a symlink, then the link is renamed
		if newpath exists
			it will be atomically replaced
			if it is a dir, then it must be empty
			if it is a symlink, then the link will be overwritten
*/
void RenameNode( cstr oldpath, cstr newpath, bool overwrite )
{
	oldpath = FullPathToNode(oldpath,no/*!follow_symlink*/); 
		if(errno) return;

	newpath = FullPathToNode(newpath,no/*!follow_symlink*/,/*create_path*/yes); 
		if(errno==ok && !overwrite) { errno=EEXIST; }
		if(errno && errno!=ENOENT)  { return; }
			
	rename(oldpath,newpath);			// renames files, dirs and symlinks!
}




/* ----	delete file or folder -----------------------------------------
		in: does nothing if errno already set
*/
void DeleteNode( cstr path, bool follow_symlink, s_type typ )
{
	if(errno) return;
	path = FullPathToNode(path,follow_symlink);
	if(errno) return;
	
	if(typ!=s_any)
	{
		s_type t = ClassifyFile(path,no);
		if(t==s_none) return;			// error
		if(t!=typ) { errno=wrongfiletype; return; }
	}
	if(remove(path)==0) errno=ok;		// remove() sets error for dirs even on success!
}


/*	remove directory and all contents
	does not follow symlinks
	returns: 0 = ok,    errno void
			-1 = error, errno set
	TODO: determine whether a final symlink in dpath is resolved by opendir()
	uses tempmem
*/
static int remove_tree( cstr dpath )
{
	DIR* dir = opendir(dpath);
	if (!dir) return -1;

	struct dirent* direntry;
	int rval = 0;

	while( (direntry=readdir(dir)) )
	{
		cstr fname = direntry->d_name;
		cptr p = fname; if(*p++=='.') { if(p[*p=='.']==0) continue; }	// skip "." and ".."

		struct stat fstat;
		cstr fpath = CatStr(dpath,fname);
		if( lstat(fpath,&fstat) ) { rval=-1; continue; }
		rval |= S_ISDIR(fstat.st_mode) ? remove_tree(fpath) : remove(fpath);
	}
	closedir(dir);
	if(rval==0) rval = rmdir(dpath);
	return rval;
}


/* ----	delete directory / tree -----------------------------------------
		in: does nothing if errno already set
		out: errno set/cleared
*/
void DeleteDir( cstr path, bool fulltree )
{
	if(errno) return;
	TempMemPool t;
	path = FullPathToNode(path,yes/*follow_symlink*/); 
	if(errno) return;
	if(path[0]=='/'&&path[1]==0) { errno=EPERM; return; }
	if(rmdir(path)==0 || (errno==ENOTEMPTY && fulltree && remove_tree(path)==0) ) errno=ok;
}


/* ----	swap two files ------------------------------------------
*/
void SwapFiles ( cstr path1, cstr path2 )
{
	path1 = FullPathToNode(path1,1);	if(errno) return;
	path2 = FullPathToNode(path2,1);	if(errno) return;

	cstr zpath = TempFileName(path2); assert(errno==ok);	// must work
	rename(path1,zpath);	if(errno) return;				//failed
	rename(path2,path1);	if(errno) { int e=errno; rename(zpath,path1); errno=e; return; }	// failed
	rename(zpath,path2);    assert(errno==ok);				// must work
}









/* ----	get absolute, deref'ed path -------------------------------
		resolve things like partial path, ~, ./ and ../
*/
static
cstr MyFullPath ( cstr path, bool follow_symlink )
{
	return errno ? "" : FullPath(path,follow_symlink);
}


/* ----	check file type -----------------------------------------
		errno:	set if path is invalid
				no error if file does not exist
		out: errno 
*/
static
s_type MyClassifyFile ( cstr path, bool follow_symlink )
{
	path = MyFullPath(path,follow_symlink);
	if (errno) return s_none;

	s_type r = ClassifyFile(path,no);
	ClearError();		// if s_none
	return r;
}



/* ----	create directory -------------------------------------
		in:	 mode = filemode
		out: errno cleared/set:
			 EEXIST		Directory already exists
			 ENOTDIR	encountered non-directory
			 ELOOP		infinite symlink loop
*/
void CreateDir( cstr path, int mode )
{
	path = FullPathToNode(path,yes/*follow_symlink*/);

	if(errno==ok || errno==ENOENT) 
	{ 
		if(mkdir(path,mode)==0) errno=ok; 
	}
}

/* ----	create pipe -------------------------------------
		in:	 mode = filemode
		out: errno cleared/set:
			 EEXIST		Directory already exists
			 ENOTDIR	encountered non-directory
			 ELOOP		infinite symlink loop
*/
void CreatePipe( cstr path, int mode )
{
	path = FullPathToNode(path,yes/*follow_symlink*/);

	if(errno==ok || errno==ENOENT) 
	{ 
		if(mkfifo(path,mode)==0) errno=ok; 
	}
}

/* ---- create symbolic link ------------------------------------------
		create a symbolic link to 'dest' at position 'path'
		overwrites old link, if present
		in:	 path, dest
		out: errno set
*/
void CreateLink( cstr path, cstr dest )
{
	path = FullPathToNode(path,no);
	if(errno)
	{
		if(errno!=ENOENT) return;
		//else errno == ENOENT -> free to create
	}
	else
	{
		struct stat fs;
		if( lstat(path,&fs)==0 && S_ISLNK(fs.st_mode) )
		{
			if(unlink(path)) return;	// failed: errno set
		}
	}
	errno = ok; symlink(dest,path);		// may set errno
}





/* ----	create regular file ---------------------------------------
		in: mode = "new", "write" or "append"
			does nothing if errno is already set
		out: errno 
*/
void CreateFile( cstr path, int8 const* data, uint32 cnt, int how, int mode )	
{
	assert( how=='n' || how=='a' || how=='w' );			// new, append, overwrite

	path = FullPathToNode(path,yes);
	if(errno && errno!=ENOENT) return;					// error

	how = how=='n' ? O_WRONLY|O_CREAT|O_EXCL : how=='a' ? O_WRONLY|O_CREAT|O_APPEND : O_WRONLY|O_CREAT|O_TRUNC;
	int fd = open(path,how,mode); if (fd==-1) return;
	int rv; do { rv = write(fd,data,cnt); } while(rv==-1 && errno==EINTR); if(rv==0) errno=ok;
	close(fd); 
}



/* ----	get link target ----------------------------------------
		in: does nothing if errno already set
			except clearing the result string
*/
void ReadLink ( cstr path, str& data )
{
	data=NULL;

	if (errno) return;
	path = FullPath(path,no);
	if(errno) return;
	
	if(IsLink(path))
	{
		char bu[MAXPATHLEN];
		int n = readlink( path, bu, MAXPATHLEN );
		if(n>=0) { data=new char[n+1]; memcpy(data,bu,n); data[n]=0; }	// filesystem encoding
	}
	else
	{
		SetError(EINVAL);
	}
}














































