/*	Copyright  (c)	Günter Woigk 2001 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	2003-08-08 kio	enhanced SysLoad() for all (?) platforms
	2003-08-09 kio	ExecCmd()
	2003-11-25 kio	save&restore stdin/stderr settings
	2011-01-17 kio	rewritten some procs for sysctl()
*/


#define	SAFE	2
#define	LOG		1

#include	"kio/kio.h"

#include	<time.h>
#include	<sys/time.h>
#include	<unistd.h>
#include	<sys/param.h>
#include	<sys/resource.h>
#include	<stdlib.h>
#include	<termios.h>
#include	<pwd.h>

#ifdef HAVE_MACHINE_VMPARAM_H
#include	<machine/vmparam.h>
#endif

#ifdef HAVE_NETDB_H
#include	<netdb.h>
#endif

#ifdef HAVE_SYS_SYSCTL_H
#include	<sys/sysctl.h>
#endif

#ifdef HAVE_SYS_LOADAVG_H
#include	<sys/loadavg.h>
#endif

#ifdef HAVE_SYS_WAIT_H
#include	<sys/wait.h>
#endif

#include	"os_utilities.h"

INIT_MSG


extern char **environ;					// was required by: Mac OSX (pre 10.5 ?)


cstr GetUser()
{
	struct passwd* p;
	getpwuid(getuid());
	return p ? p->pw_name : NULL;
}

cstr GetEffUser()
{
	struct passwd* p;
	getpwuid(geteuid());
	return p ? p->pw_name : NULL;
}


/* ===========================================================
		machine information
			for more sysctl calls see:
			<sys/sysctl.h>
			man sysctl
   ========================================================= */


cstr HostName()
{
#ifdef _BSD
	char s[MAXHOSTNAMELEN];
	size_t size = MAXHOSTNAMELEN;
	int mib[4] = { CTL_KERN, KERN_HOSTNAME };
	sysctl( mib, 2, s, &size, NULL, 0);
	return DupStr(s);
	
#else
  #if !defined(MAXHOSTNAMELEN)
	#define MAXHOSTNAMELEN 256
  #endif
	char s[MAXHOSTNAMELEN];
	gethostname(s,MAXHOSTNAMELEN);
	return DupStr(s);
#endif
}

int NumCPUs()
{
#ifdef _BSD
	int    n;
	size_t size = sizeof(n);
	int mib[4] = { CTL_HW, HW_AVAILCPU };
	sysctl( mib, 2, &n, &size, NULL, 0);
	if(n>=1) return n;

	mib[1] = HW_NCPU;
	sysctl( mib, NELEM(mib), &n, &size, NULL, 0 );

	return n>=1 ? n : 1;

#elif defined(_LINUX)||defined(_SOLARIS)
	return sysconf(_SC_NPROCESSORS_ONLN);
#else
	#fixme!
#endif
}

void SysLoad ( double load[3] )			// ranges: 1, 5, and 15 minutes
{
#ifdef _BSD
	int mib[4] = { CTL_VM, VM_LOADAVG };
	struct loadavg data;
	size_t size = sizeof(data);
	sysctl ( mib, 2, &data, &size, NULL, 0 );

	load[0] = double(data.ldavg[0])/data.fscale;
	load[1] = double(data.ldavg[1])/data.fscale;
	load[2] = double(data.ldavg[2])/data.fscale;

#elif defined(_LINUX)||defined(_SOLARIS)
	// new: 2003-08-08 kio
	// new: 2004-06-09 thor	now also for Solaris.
	int n = getloadavg ( load, 3 );
	if(n!=3)
	{
		LogLine("SysLoad(): getloadavg() returned %i",n);
		if(n<1)load[0]=1.0;
		if(n<2)load[1]=load[0];
		load[2]=load[1];
	}
#else
	#fixme!
#endif
}


time_t IntCurrentTime()
{
	struct timeval tv;
	gettimeofday ( &tv, NULL );
	return tv.tv_sec;
}

double FloatCurrentTime()
{
	struct timeval tv;
	gettimeofday ( &tv, NULL );
	return tv.tv_sec + tv.tv_usec/1000000.0;
}


time_t BootTime ( )
{
#ifdef _BSD
	int mib[4] = { CTL_KERN, KERN_BOOTTIME };
	struct timeval data;
	size_t size = sizeof(data);
	sysctl ( mib, 2, &data, &size, NULL, 0 );

	return data.tv_sec;

#elif defined(_LINUX)
	// Better way to do is use jiffies or get_cycles function
	// time being will read /proc/uptime
	FILE *fp;
	long ut;
	if((fp=fopen("/proc/uptime","r"))==NULL)
	{
		printf("Cannot open file /proc/uptime\n");
		return(-1);
	}
	fscanf(fp,"%ld",&ut);
	fclose(fp);
	return IntCurrentTime()-ut;
#else
	#fixme!
#endif
}







/* ==== Execute External Command File ===========================
*/
/* ----	execute external command ----------------------------
		argv[]  must be a 0-terminated list
		argv[0]	hard path to command
		envv[]  is either NULL or a 0-terminated list of environment variables
		        in case of NULL the current global environ[] list is passed
		returns	stdout output of command called
				returned string must be delete[]ed
				output to stderr is still printed to stderr
				return code is passed implicitely in errno
		returns NULL if exec failed
				then errno is set
		errno:	noerr: ok
				errno: exec() failed
				childreturnederror:		 returned error code is part of custom ErrorText()
				childterminatedbysignal: signal number is part of custom ErrorText()
*/
str ExecCmd ( str const argv[], str const envv[] )
{
	XXTRAP(!argv||!argv[0]||!*argv[0]);

	const int R=0,W=1;
	int pipout[2];
	if ( pipe(pipout) != 0 )
	{
		XXXTRAP(NoError());
		return NULL;
	}

// preset result to "nothing"
	char* result = NULL;

// it seems, that the child can mess up the stdin stream settings
// (and maybe stderr too) especially if execve() fails
// so save them here and restore them afterwards							kio 2003-11-25
	struct termios old_stderr_termios;
	struct termios old_stdin_termios;
	bool restore_stdin  = tcgetattr(0,&old_stdin_termios ) != -1;
	bool restore_stderr = tcgetattr(2,&old_stderr_termios) != -1;

	// TODO: ExecCmd() should search for cmd file prior to spawning

// *** DOIT ***
	pid_t child_id = fork();
	switch ( child_id )
	{
	case -1:// error happened:
			close(pipout[R]);
			close(pipout[W]);
			XXXTRAP(NoError());
			break;

	case 0:	// child process:
		{
			close(pipout[R]);	// close unused fd
			close(1);			// close stdout
			dup(pipout[W]);		// becomes lowest unused fileid: stdout
			close(pipout[W]);	// close unused dup

			// call cmd:
			execve(argv[0],argv,envv?envv:(str const *)environ);

			// call failed. try path completion
			str path = getenv("PATH");
			if (path&&*argv[0]!='/')
			{
				for(;;)
				{
					while(*path==':') path++;
					char* dp = strchr(path,':');
					if (!dp) dp = strchr(path,0);
					if(dp==path) break;						// end of env.PATH reached: finally no success

					str cmd = CatStr(SubStr(path,dp),"/",argv[0]);
					execve(cmd,argv,envv?envv:(str const *)environ);	// no return if success
					path = dp;
				}
			}
			XXLogLine( "ExecCmd(%s) failed: %s", Quoted(argv[0]), ErrorStr() );
			exit(errno);
  		}

	default:// parent process
		{
			close(pipout[W]);	// close unused fd

			ssize_t result_size = 0;
			ssize_t result_used = 0;
			int		status;

			for(;;)
			{
				if (result_used+100>result_size)
				{
					result_size += result_size/8 + 4000;
					char* newbu = NewStr(result_size);
					memcpy ( newbu,result,result_used );
					delete[] result;
					result = newbu;
				}

				ssize_t n = read ( pipout[R], result+result_used, result_size-result_used-1 ); //Log("[%i]",(int)n);

				if(n>0)		  { result_used += n; }
				else if(n==0) { if(waitpid(child_id,&status,0)==child_id) {ClearError();break;} }
				else		  { if (errno!=EINTR&&errno!=EAGAIN) break; }
			}

			close(pipout[R]);	// close fd

			if (NoError())
			{
				if ( WIFEXITED(status) )			// child process returned normally
				{
					if ( WEXITSTATUS(status)!=0 )	// child process returned error code
					{
						SetError
						(	childreturnederror,
							Using( "%s returned exit code %i", Quoted(argv[0]), (int)WEXITSTATUS(status) )
						);
					}
				}
				else if ( WIFSIGNALED(status) )		// child process terminated by signal
				{
						SetError
						(	childterminatedbysignal,
							Using( "%s terminated by signal %i", Quoted(argv[0]), (int)WTERMSIG(status) )
						);
				}
				else IERR();
			}

			result[result_used] = 0;
		}
	}

// restore stream settings
	if (restore_stderr) { tcsetattr(2,TCSADRAIN,&old_stderr_termios); XXLogLine("ExecCmd(): restored stderr"); }
	if (restore_stdin)  { tcsetattr(0,TCSADRAIN,&old_stdin_termios);  XXLogLine("ExecCmd(): restored stdin");  }

// return result
	return result;
}

str ExecCmd ( cstr cmd, ... )
{
	cstr* argv = new cstr[100];
	argv[0] = cmd;
	int argc = 1;

	va_list va;
	va_start(va,cmd);

	cstr arg;
	do
	{
		if ((argc%100)==0)
		{
			cstr* newargv = new cstr[argc+100];
			memcpy(newargv,argv,argc*sizeof(cstr));
			delete[]argv;
			argv=newargv;
		}

		arg = va_arg(va,cstr);
		argv[argc++] = arg;
	}
	while (arg);

	va_end(va);

	str result = ExecCmd((char*const*)argv);
	delete[]argv;
	return result;
}












