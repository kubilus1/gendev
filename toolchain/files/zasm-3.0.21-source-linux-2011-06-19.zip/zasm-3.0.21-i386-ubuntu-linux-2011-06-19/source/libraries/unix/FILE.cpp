/*	Copyright  (c)	Günter Woigk 2001 - 2011
  					mailto:kio@little-bat.de

	This file is free software

 	This program is distributed in the hope that it will be useful,
 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

	Redistribution and use in source and binary forms, with or without 
	modification, are permitted provided that the following conditions are met:

	• Redistributions of source code must retain the above copyright notice, 
	  this list of conditions and the following disclaimer.
	• Redistributions in binary form must reproduce the above copyright notice, 
	  this list of conditions and the following disclaimer in the documentation 
	  and/or other materials provided with the distribution.

	THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
	AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
	PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
	CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
	EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
	PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
	OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
	WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
	OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
	ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

	2003-08-15 kio	fixed buggy call to ioctl() in SetBlocking() and SetAsync()
	2003-10-09 kio	FullPath(): enhanced to match broken utf-8 filenames
	2004-05-07 kio	FullPath(): added buffer overflow check for initial rpath assembly
	2004-05-08 kio	FullPath(): returned path now has a trailing "/" for a deref'ed, existing directory
	2004-06-11 kio	FullPath(): Bug: always overwrote n.ex. path components with latin1
	2007-02-14 kio	NewTempFile(), DupFile(), filecopy(), lots of new file i/o functions.
*/

#define	SAFE	2
#define	LOG		1

#include	<unistd.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	<sys/stat.h>
#include	<sys/param.h>
#include	<fcntl.h>
#include	<sys/ioctl.h>
#include	<termios.h>
#include	<new>
#include	"FILE.h"
INIT_MSG


void SetBlocking ( FILE* file, bool onoff )	{ SetBlocking(fileno(file), onoff); }
void SetAsync    ( FILE* file, bool onoff )	{ SetAsync   (fileno(file), onoff); }

s_type ClassifyFile( FILE* file )
{
	if (file) return ClassifyFile(fileno(file));
	else { SetError(EBADF); return s_none; }
}

off_t FileLength ( FILE* file )
{
	struct stat fs;
	if (!file) return -1;
	if (fstat(fileno(file),&fs)) return -1;	// error
	return fs.st_size;
}

/* ----	read line from file ----------------------------------------- [kio 2004-04-30]
		read text up to \0, \n, \r, \n\r or \r\n
		returns string allocated with new[]  (( up to 100 char / 50% over-allocated! ***TODO*** ))
		returns NULL at EOF/Error => check ferror(f)
*/
str NewReadStr ( FILE* f ) throw(bad_alloc)
{
	TRAP(EOF>=0);			// should be ok  =>  nop

	int sz = 100;			// initial max. size
	str s  = NewStr(sz);
	int n  = 0;

// read character-by-character and break on linebreak
	for(;;)
	{
		int c = getc(f);

		if(c<=13)
		{
			if (c==EOF) { if(n) break; delete[] s; return NULL; }	// EOF/Error
			if (c==0) break;
			if (c==10||c==13)
			{
				int c2 = getc(f);
				if (c2!=EOF && c+c2!=23) ungetc(c2,f);
				break;
			}
		}

		if(n==sz)		// s[] full => need more!
		{
			char* z = NewStr( sz+=sz/2 );
			memcpy(z,s,n);
			delete[] s;
			s = z;
		}

		s[n++] = c;
	}

	s[n] = 0;		// string delimiter
	return s;		// allocated with new[]
}










